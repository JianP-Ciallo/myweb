from __future__ import annotations

from pathlib import Path

from .config import DEFAULT_UNIT_SYSTEM, JSONDict, MATERIALS_DIR
from .io import read_json


MATERIAL_NUMERIC_KEYS = ["density_kg_per_m3", "youngs_pa", "poisson"]
OPTIONAL_NUMERIC_KEYS = ["yield_strength_pa"]


def _material_files() -> list[Path]:
    if not MATERIALS_DIR.exists():
        return []
    return sorted(MATERIALS_DIR.glob("*.json"), key=lambda item: item.name.lower())


def load_materials() -> dict[str, JSONDict]:
    materials: dict[str, JSONDict] = {}
    for path in _material_files():
        data = read_json(path)
        material_id = str(data.get("id") or data.get("name") or path.stem)
        normalized = dict(data)
        normalized["id"] = material_id
        normalized.setdefault("name", material_id)
        normalized["_path"] = str(path)
        materials[material_id] = normalized
    return materials


def list_materials() -> list[JSONDict]:
    rows = []
    for material in load_materials().values():
        rows.append(
            {
                "id": material["id"],
                "name": material.get("name", material["id"]),
                "display_name": material.get("display_name", material["id"]),
                "category": material.get("category", "unknown"),
                "type": material.get("type", "unknown"),
                "unit_system": material.get("unit_system", "unknown"),
                "density_kg_per_m3": material.get("density_kg_per_m3"),
                "youngs_pa": material.get("youngs_pa"),
                "poisson": material.get("poisson"),
                "yield_strength_pa": material.get("yield_strength_pa"),
                "source": material.get("source", ""),
                "version": material.get("version", "unknown"),
                "requires_project_review": bool(material.get("requires_project_review", True)),
            }
        )
    return rows


def get_material(material_id: str) -> JSONDict:
    key = str(material_id).strip()
    if not key:
        raise ValueError("material_id is required")
    materials = load_materials()
    if key not in materials:
        known = ", ".join(sorted(materials)) or "<none>"
        raise ValueError(f"unknown material '{key}'. Known materials: {known}")
    material = dict(materials[key])
    material.pop("_path", None)
    return material


def resolve_material(material: JSONDict) -> JSONDict:
    raw = dict(material)
    name = str(raw.get("name", "mild_steel")).strip() or "mild_steel"
    materials = load_materials()
    if name in materials:
        resolved = material_from_library(materials[name], raw)
    else:
        resolved = material_from_confirmed_custom(raw, name)
    validate_material(resolved)
    return resolved


def material_from_library(library_material: JSONDict, overrides: JSONDict) -> JSONDict:
    resolved = {
        "name": library_material["id"],
        "display_name": library_material.get("display_name", library_material["id"]),
        "type": library_material.get("type", "elastic"),
        "density_kg_per_m3": float(library_material["density_kg_per_m3"]),
        "youngs_pa": float(library_material["youngs_pa"]),
        "poisson": float(library_material["poisson"]),
        "unit_system": library_material.get("unit_system", DEFAULT_UNIT_SYSTEM),
        "source": library_material.get("source", ""),
        "source_url": library_material.get("source_url", ""),
        "version": library_material.get("version", "unknown"),
        "library_id": library_material["id"],
        "source_type": "material_library",
        "requires_project_review": bool(library_material.get("requires_project_review", True)),
    }
    if library_material.get("yield_strength_pa") is not None:
        resolved["yield_strength_pa"] = float(library_material["yield_strength_pa"])
    for key in ["display_name"]:
        if key in overrides:
            resolved[key] = overrides[key]
    return resolved


def material_from_confirmed_custom(raw: JSONDict, name: str) -> JSONDict:
    if raw.get("confirmed_by_user") is not True:
        raise ValueError(
            f"unknown material '{name}'. Use list_materials/get_material, or provide confirmed_by_user=true with full custom material parameters and source."
        )
    missing = [key for key in MATERIAL_NUMERIC_KEYS if key not in raw]
    if missing:
        raise ValueError(f"custom material '{name}' is missing required fields: {', '.join(missing)}")
    if not str(raw.get("source", "")).strip():
        raise ValueError(f"custom material '{name}' must include material.source")
    resolved = dict(raw)
    resolved["name"] = name
    resolved.setdefault("type", "elastic")
    resolved.setdefault("unit_system", DEFAULT_UNIT_SYSTEM)
    resolved.setdefault("version", "user-confirmed")
    resolved["source_type"] = "user_confirmed_custom"
    resolved["requires_project_review"] = True
    return resolved


def validate_material(material: JSONDict) -> None:
    if material.get("unit_system") != DEFAULT_UNIT_SYSTEM:
        raise ValueError(f"material.unit_system must be '{DEFAULT_UNIT_SYSTEM}'")
    if material.get("type", "elastic") != "elastic":
        raise ValueError("only material.type='elastic' is supported")
    for key in ["density_kg_per_m3", "youngs_pa"]:
        if float(material.get(key, 0)) <= 0:
            raise ValueError(f"material.{key} must be positive")
    poisson = float(material.get("poisson", 0))
    if not 0.0 < poisson < 0.5:
        raise ValueError("material.poisson must be between 0 and 0.5")
    if "yield_strength_pa" in material and material["yield_strength_pa"] is not None:
        if float(material["yield_strength_pa"]) <= 0:
            raise ValueError("material.yield_strength_pa must be positive when provided")
