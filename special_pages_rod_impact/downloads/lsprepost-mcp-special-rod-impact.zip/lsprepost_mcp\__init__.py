"""Local LS-PrePost MCP server package."""
