@echo off
setlocal
set "ROOT=%~dp0.."
set "PYTHONDONTWRITEBYTECODE=1"
python "%ROOT%\lsprepost_mcp\server.py"
