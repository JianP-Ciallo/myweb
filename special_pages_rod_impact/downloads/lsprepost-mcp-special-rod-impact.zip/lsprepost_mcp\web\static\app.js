"use strict";

let sceneCatalog = [];
let lastProjectName = "";
let promptEdited = false;
let lsppConfigured = false;
const viewer = {
  mesh: null,
  yaw: -0.65,
  pitch: 0.55,
  zoom: 1,
  panX: 0,
  panY: 0,
  projectName: "",
  hiddenParts: new Set(),
  dragging: false,
  dragButton: 0,
  lastX: 0,
  lastY: 0
};

const scenePrompts = {
  rebar_drop_on_helmet: "生成钢筋自由落体冲击头盔的受控场景。",
  rod_impact_plate: "生成圆柱杆冲击固定板的受控场景。",
  cube_top_corner_load: "生成立方体顶面四角向下受载的受控场景。",
  plate_pressure: "生成壳板受均布压力的受控场景。"
};
const controlledScenePrefix = "web_";

function byId(id) {
  return document.getElementById(id);
}

function setBusy(isBusy) {
  for (const button of document.querySelectorAll("button")) {
    button.disabled = isBusy;
  }
}

function showResult(value) {
  byId("result").textContent = JSON.stringify(value, null, 2);
}

function summaryRow(label, value) {
  if (value === undefined || value === null || value === "") return null;
  const row = document.createElement("div");
  row.className = "summary-row";
  const labelNode = document.createElement("span");
  labelNode.className = "summary-label";
  labelNode.textContent = label;
  const valueNode = document.createElement("span");
  valueNode.className = "summary-value";
  valueNode.textContent = Array.isArray(value) ? value.join("、") : String(value);
  row.appendChild(labelNode);
  row.appendChild(valueNode);
  return row;
}

function summarizeResult(label, result) {
  const rows = [["操作", label], ["状态", "完成"]];
  const writeResult = result && result.write_result ? result.write_result : {};
  const projectName = result.project_name || result.project || writeResult.project || "";
  const projectDir = result.project_dir || writeResult.project_dir || "";

  if (result.operation === "import_project_package") {
    rows.push(["项目名称", result.project_name]);
    rows.push(["导入来源", result.source_dir]);
    rows.push(["模型文件", "已导入 model.k"]);
    rows.push(["附带信息", result.copied_files]);
    rows.push(["检查结果", result.checks_ok ? "通过" : "需要复核"]);
    rows.push(["保存位置", result.project_dir]);
    return rows;
  }

  if (projectName) rows.push(["项目名称", projectName]);
  if (projectDir) rows.push(["保存位置", projectDir]);
  if (result.output_path) rows.push(["输出文件", result.output_path]);
  if (result.user_export && result.user_export.project_export_dir) {
    rows.push(["额外保存位置", result.user_export.project_export_dir]);
  }
  if (result.message) rows.push(["说明", result.message]);
  if (result.parts && result.nodes !== undefined) {
    rows.push(["模型内容", `${result.parts.length} 个部件，${result.nodes} 个节点，${result.faces} 个面`]);
  }
  return rows;
}

function showOperationSummary(label, result) {
  const box = byId("result");
  box.innerHTML = "";

  const wrapper = document.createElement("div");
  wrapper.className = "operation-summary";
  const title = document.createElement("h3");
  title.textContent = "操作结果";
  wrapper.appendChild(title);

  const list = document.createElement("div");
  list.className = "summary-list";
  for (const [rowLabel, rowValue] of summarizeResult(label, result || {})) {
    const row = summaryRow(rowLabel, rowValue);
    if (row) list.appendChild(row);
  }
  wrapper.appendChild(list);

  const details = document.createElement("details");
  const summary = document.createElement("summary");
  summary.textContent = "查看详细信息";
  const pre = document.createElement("pre");
  pre.className = "detail-json";
  pre.textContent = JSON.stringify(result, null, 2);
  details.appendChild(summary);
  details.appendChild(pre);
  wrapper.appendChild(details);

  box.appendChild(wrapper);
}

function showStatus(message) {
  byId("result").innerHTML = "";
  const span = document.createElement("span");
  span.className = "status";
  span.textContent = message;
  byId("result").appendChild(span);
}

function showError(error) {
  const message = error && error.message ? error.message : String(error);
  showOperationSummary("操作失败", { operation: "error", message });
}

function setLsppStatus(config) {
  const doctor = config.doctor || {};
  lsppConfigured = Boolean(config.configured && doctor.ok);
  byId("lsppExe").value = config.lspp_exe || "";
  byId("lsppStatus").textContent = lsppConfigured
    ? `LS-PrePost 已配置：${config.lspp_exe}`
    : "尚未配置 LS-PrePost。生成 K 文件仍可使用，预览和打开功能需要导入有效的 lsprepost*.exe。";
  setExportDirStatus(config);
}

function setExportDirStatus(config) {
  const exportDir = config.export_dir || "";
  byId("exportDir").value = exportDir;
  byId("exportDirStatus").textContent = config.export_dir_configured
    ? `模型会额外保存到：${exportDir}`
    : "未配置自定义保存路径。模型仍会保存在项目 workspace 中。";
}

async function api(path, options) {
  const request = Object.assign({ headers: { Accept: "application/json" } }, options || {});
  if (request.body) {
    request.headers = Object.assign({}, request.headers, { "Content-Type": "application/json" });
  }

  const response = await fetch(path, request);
  const payload = await response.json();
  if (!response.ok || !payload.ok) {
    const error = payload.error || { message: `请求失败：${response.status}` };
    throw new Error(error.message || error.code || "请求失败");
  }
  return payload.result;
}

async function loadConfig() {
  const config = await api("/api/config");
  setLsppStatus(config);
  return config;
}

async function importLsppPath() {
  return runAction("正在导入 LS-PrePost", async () => {
    const result = await api("/api/config/select-lsprepost", {
      method: "POST",
      body: JSON.stringify({})
    });
    setLsppStatus(result);
    return result;
  });
}

async function checkLsppPath() {
  return runAction("正在检测 LS-PrePost 路径", async () => {
    const result = await api("/api/config/check-lsprepost", {
      method: "POST",
      body: JSON.stringify({ lspp_exe: byId("lsppExe").value.trim() })
    });
    byId("lsppStatus").textContent = result.doctor && result.doctor.ok
      ? `路径有效：${result.lspp_exe}`
      : "路径无效。请选择真实存在的 lsprepost*.exe 文件。";
    return result;
  });
}

async function saveLsppPath() {
  return runAction("正在保存 LS-PrePost 路径", async () => {
    const result = await api("/api/config/lsprepost", {
      method: "POST",
      body: JSON.stringify({ lspp_exe: byId("lsppExe").value.trim() })
    });
    setLsppStatus(result);
    return result;
  });
}

async function selectExportDir() {
  return runAction("正在选择模型保存路径", async () => {
    const result = await api("/api/config/select-export-dir", {
      method: "POST",
      body: JSON.stringify({})
    });
    setExportDirStatus(result);
    return result;
  });
}

async function saveExportDir() {
  return runAction("正在保存模型保存路径", async () => {
    const result = await api("/api/config/export-dir", {
      method: "POST",
      body: JSON.stringify({ export_dir: byId("exportDir").value.trim() })
    });
    setExportDirStatus(result);
    return result;
  });
}

function importProjectNameValue() {
  return byId("importPackageProjectName").value.trim();
}

async function finishImportedProject(result) {
  lastProjectName = result.project_name || "";
  if (lastProjectName) {
    byId("projectName").value = lastProjectName;
    if (!byId("importPackageProjectName").value.trim()) {
      byId("importPackageProjectName").value = lastProjectName;
    }
  }
  if (result.source_dir) {
    byId("importPackageDir").value = result.source_dir;
  }
  byId("importPackageStatus").textContent = result.project_name
    ? `已导入模型：${result.project_name}`
    : "模型已导入。";
  updateContextStatus();
  await loadProjects();
  if (lastProjectName) {
    await loadInteractiveMesh(lastProjectName);
  }
}

async function selectImportPackageDir() {
  return runAction("正在导入完整模型文件夹", async () => {
    const result = await api("/api/project/select-import-package", {
      method: "POST",
      body: JSON.stringify({
        project_name: importProjectNameValue(),
        if_exists: "versioned"
      })
    });
    await finishImportedProject(result);
    return result;
  });
}

async function importPackage() {
  return runAction("正在导入完整模型文件夹", async () => {
    const result = await api("/api/project/import-package", {
      method: "POST",
      body: JSON.stringify({
        source_dir: byId("importPackageDir").value.trim(),
        project_name: importProjectNameValue(),
        if_exists: "versioned"
      })
    });
    await finishImportedProject(result);
    return result;
  });
}

function selectedScene() {
  const id = byId("scene").value;
  return sceneCatalog.find((scene) => scene.id === id) || sceneCatalog[0] || null;
}

function defaultPrompt(scene) {
  if (!scene) return "";
  return scenePrompts[scene.id] || `生成${scene.title}。`;
}

function currentProjectName() {
  return byId("projectName").value.trim();
}

function currentSceneLabel() {
  const scene = selectedScene();
  return scene ? scene.title : "未选择";
}

function updateContextStatus() {
  const box = byId("contextStatus");
  if (!box) return;
  const sceneName = currentSceneLabel();
  const projectName = currentProjectName();
  const previewProject = viewer.projectName || "";
  const isStalePreview = Boolean(projectName && previewProject && projectName !== previewProject);
  box.classList.toggle("warning", isStalePreview);
  if (isStalePreview) {
    box.textContent = `当前场景：${sceneName}；当前项目：${projectName}；视窗显示：${previewProject}。注意：视窗仍是旧项目，请重新生成或刷新预览。`;
    return;
  }
  box.textContent = `当前场景：${sceneName}；当前项目：${projectName || "未填写"}；视窗显示：${previewProject || "尚未加载模型"}。`;
}

function buildGenerationConfirmationSummary() {
  const scene = selectedScene();
  const parameters = collectParameters();
  const lines = [
    "请确认即将生成模型：",
    `场景：${scene ? scene.title : "未选择"}`,
    `项目名称：${currentProjectName() || "未填写"}`,
    `需求描述：${byId("prompt").value.trim() || "未填写"}`,
    "参数："
  ];
  for (const [key, value] of Object.entries(parameters)) {
    lines.push(`- ${key}: ${value}`);
  }
  return lines.join("\n");
}

function confirmGeneration() {
  return window.confirm(buildGenerationConfirmationSummary());
}

function updatePromptForScene(scene) {
  if (!promptEdited || !byId("prompt").value.trim()) {
    byId("prompt").value = defaultPrompt(scene);
    promptEdited = false;
  }
}

function updateProjectNameForScene(scene) {
  if (!scene) return;
  const input = byId("projectName");
  const current = input.value.trim();
  const currentStartsWithControlledPrefix = sceneCatalog.some(
    (item) => current === `${controlledScenePrefix}${item.id}` || current.startsWith(`${controlledScenePrefix}${item.id}_`)
  );
  if (!current || current === "web_scene_demo" || currentStartsWithControlledPrefix) {
    input.value = `web_${scene.id}`;
  }
  updateContextStatus();
}

function renderFields() {
  const scene = selectedScene();
  const fields = byId("fields");
  fields.innerHTML = "";
  if (!scene) {
    byId("sceneSummary").textContent = "服务端没有返回可用场景模板。";
    updateContextStatus();
    return;
  }

  byId("sceneSummary").textContent = scene.summary || "";
  updatePromptForScene(scene);
  updateProjectNameForScene(scene);

  for (const field of scene.fields || []) {
    const label = document.createElement("label");
    label.className = "field";

    const title = document.createElement("span");
    title.textContent = `${field.label}${field.unit ? ` (${field.unit})` : ""}`;
    label.appendChild(title);

    let input;
    if (field.kind === "select") {
      input = document.createElement("select");
      for (const option of field.options || []) {
        const item = document.createElement("option");
        item.value = option;
        item.textContent = option;
        input.appendChild(item);
      }
    } else if (field.kind === "boolean") {
      input = document.createElement("select");
      for (const option of ["true", "false"]) {
        const item = document.createElement("option");
        item.value = option;
        item.textContent = option === "true" ? "是" : "否";
        input.appendChild(item);
      }
    } else {
      input = document.createElement("input");
      input.type = field.kind === "number" ? "number" : "text";
      if (field.kind === "number") input.step = "any";
    }

    input.value = String(field.default);
    input.dataset.param = field.name;
    input.dataset.kind = field.kind;
    label.appendChild(input);
    fields.appendChild(label);
  }
  updateContextStatus();
}

function collectParameters() {
  const parameters = {};
  for (const input of byId("fields").querySelectorAll("[data-param]")) {
    const key = input.dataset.param;
    if (!key) continue;
    if (input.dataset.kind === "number") {
      const value = Number(input.value);
      if (Number.isFinite(value)) parameters[key] = value;
    } else if (input.dataset.kind === "boolean") {
      parameters[key] = input.value === "true";
    } else {
      parameters[key] = input.value;
    }
  }
  return parameters;
}

function scenePayload(extra) {
  const scene = selectedScene();
  const projectName = byId("projectName").value.trim();
  lastProjectName = projectName;
  return Object.assign(
    {
      scene_id: scene ? scene.id : "",
      project_name: projectName,
      prompt: byId("prompt").value.trim(),
      parameters: collectParameters(),
      allow_defaults: true
    },
    extra || {}
  );
}

function rememberGeneratedProjectName(result) {
  const generatedProjectName =
    (result.write_result && result.write_result.project) || result.project_name || "";
  if (typeof generatedProjectName === "string" && generatedProjectName.trim()) {
    lastProjectName = generatedProjectName;
    byId("projectName").value = generatedProjectName;
  }
  updateContextStatus();
}

function normalizePath(value) {
  return String(value || "").replace(/\\/g, "/").replace(/\/+/g, "/").replace(/\/$/, "");
}

function relativeArtifactPath(projectDir, outputPath) {
  const root = normalizePath(projectDir);
  const output = normalizePath(outputPath);
  if (!root || !output) {
    throw new Error("预览结果缺少 project_dir 或 output_path。");
  }

  const rootWithSlash = `${root}/`;
  if (output.toLowerCase().indexOf(rootWithSlash.toLowerCase()) !== 0) {
    throw new Error("预览输出路径不在项目目录内。");
  }

  const relative = output.slice(rootWithSlash.length);
  const parts = relative.split("/");
  if (!relative || relative.startsWith("/") || parts.some((part) => part === ".." || part.includes(":"))) {
    throw new Error("预览输出路径不是安全的项目相对路径。");
  }
  return relative;
}

function renderPreviewArtifact(result) {
  const relativePath = relativeArtifactPath(result.project_dir, result.output_path);
  const projectName = result.project_name || lastProjectName || byId("projectName").value.trim();
  const url = `/api/artifact?project_name=${encodeURIComponent(projectName)}&relative_path=${encodeURIComponent(relativePath)}`;
  const img = document.createElement("img");
  img.alt = "LS-PrePost 预览";
  img.src = url;

  const box = byId("previewBox");
  box.innerHTML = "";
  box.classList.remove("hidden");
  byId("viewerHint").classList.add("hidden");
  box.appendChild(img);
}

async function loadInteractiveMesh(projectName) {
  if (!projectName) return null;
  const mesh = await api(`/api/project/preview-mesh?project_name=${encodeURIComponent(projectName)}`);
  if (mesh && !mesh.project_name) {
    mesh.project_name = projectName;
  }
  renderInteractiveMesh(mesh);
  return mesh;
}

function renderInteractiveMesh(mesh) {
  viewer.mesh = mesh;
  viewer.projectName = mesh && mesh.project_name ? mesh.project_name : "";
  viewer.hiddenParts = new Set();
  viewer.zoom = 1;
  viewer.panX = 0;
  viewer.panY = 0;
  byId("previewBox").classList.add("hidden");
  byId("viewerHint").classList.add("hidden");
  renderPartLegend(mesh);
  updateContextStatus();
  drawViewer();
}

function renderPartLegend(mesh) {
  const box = byId("partLegend");
  if (!box) return;
  const parts = mesh && Array.isArray(mesh.parts) ? mesh.parts : [];
  box.innerHTML = "";
  if (!parts.length) {
    box.classList.add("hidden");
    return;
  }

  box.classList.remove("hidden");
  const title = document.createElement("div");
  title.className = "part-legend-title";
  title.textContent = "部件显示";
  box.appendChild(title);

  for (const part of parts) {
    const partId = String(part.part_id);
    const label = document.createElement("label");
    label.className = "part-legend-item";

    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.checked = !viewer.hiddenParts.has(partId);
    checkbox.addEventListener("change", () => togglePartVisibility(partId, checkbox.checked));

    const swatch = document.createElement("span");
    swatch.className = "part-swatch";
    swatch.style.background = part.color || "#d94157";

    const name = document.createElement("span");
    name.className = "part-name";
    name.textContent = part.name || `Part ${partId}`;

    label.appendChild(checkbox);
    label.appendChild(swatch);
    label.appendChild(name);
    box.appendChild(label);
  }
}

function togglePartVisibility(partId, visible) {
  const id = String(partId);
  if (visible) {
    viewer.hiddenParts.delete(id);
  } else {
    viewer.hiddenParts.add(id);
  }
  drawViewer();
  updateContextStatus();
}

function canvasContext() {
  const canvas = byId("modelCanvas");
  const rect = canvas.getBoundingClientRect();
  const ratio = window.devicePixelRatio || 1;
  const width = Math.max(1, Math.floor(rect.width * ratio));
  const height = Math.max(1, Math.floor(rect.height * ratio));
  if (canvas.width !== width || canvas.height !== height) {
    canvas.width = width;
    canvas.height = height;
  }
  const ctx = canvas.getContext("2d");
  ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
  return { canvas, ctx, width: rect.width, height: rect.height };
}

function drawViewer() {
  const { ctx, width, height } = canvasContext();
  ctx.clearRect(0, 0, width, height);
  drawWorldGrid(ctx, width, height);
  if (!viewer.mesh) {
    drawRotatingAxes(ctx, width, height);
    return;
  }
  const projected = collectProjectedFaces(width, height);
  projected.sort((a, b) => a.depth - b.depth);
  for (const item of projected) {
    drawFace(ctx, item);
  }
  drawRotatingAxes(ctx, width, height);
}

function viewTransform(width, height) {
  const bounds = viewer.mesh && viewer.mesh.bounds
    ? viewer.mesh.bounds
    : { min: [-0.5, -0.5, 0], max: [0.5, 0.5, 0.05], center: [0, 0, 0] };
  const span = Math.max(
    Math.abs(bounds.max[0] - bounds.min[0]),
    Math.abs(bounds.max[1] - bounds.min[1]),
    Math.abs(bounds.max[2] - bounds.min[2]),
    1e-9
  );
  const scale = (0.72 * Math.min(width, height) * viewer.zoom) / span;
  const center = bounds.center || [
    (bounds.min[0] + bounds.max[0]) * 0.5,
    (bounds.min[1] + bounds.max[1]) * 0.5,
    (bounds.min[2] + bounds.max[2]) * 0.5
  ];
  return { bounds, span, scale, center, width, height };
}

function collectProjectedFaces(width, height) {
  const transform = viewTransform(width, height);
  const items = [];
  for (const part of viewer.mesh.parts || []) {
    if (viewer.hiddenParts.has(String(part.part_id))) continue;
    const projectedNodes = (part.nodes || []).map((node) => projectWorldPoint(node, transform));
    for (const face of part.faces || []) {
      const points = face.map((index) => projectedNodes[index]).filter(Boolean);
      if (points.length < 3) continue;
      const depth = points.reduce((sum, point) => sum + point.depth, 0) / points.length;
      items.push({ points, depth, fill: part.color || "#d94157" });
    }
  }
  return items;
}

function rotateViewVector(vector) {
  const x = Number(vector[0]);
  const y = Number(vector[1]);
  const z = Number(vector[2]);
  const cy = Math.cos(viewer.yaw);
  const sy = Math.sin(viewer.yaw);
  const cp = Math.cos(viewer.pitch);
  const sp = Math.sin(viewer.pitch);
  const x1 = x * cy - y * sy;
  const y1 = x * sy + y * cy;
  const z1 = z;
  const y2 = y1 * cp - z1 * sp;
  const z2 = y1 * sp + z1 * cp;
  return { x: x1, y: y2, z: z2 };
}

function projectWorldPoint(node, transform) {
  const local = [
    Number(node[0]) - transform.center[0],
    Number(node[1]) - transform.center[1],
    Number(node[2]) - transform.center[2]
  ];
  const rotated = rotateViewVector(local);
  return {
    x: transform.width * 0.5 + viewer.panX + rotated.x * transform.scale,
    y: transform.height * 0.5 + viewer.panY - rotated.z * transform.scale,
    depth: rotated.y
  };
}

function projectNode(node, center, scale, width, height) {
  return projectWorldPoint(node, { center, scale, width, height });
}

function drawFace(ctx, item) {
  ctx.beginPath();
  ctx.moveTo(item.points[0].x, item.points[0].y);
  for (const point of item.points.slice(1)) {
    ctx.lineTo(point.x, point.y);
  }
  ctx.closePath();
  ctx.fillStyle = item.fill;
  ctx.globalAlpha = 0.9;
  ctx.fill();
  ctx.globalAlpha = 1;
  ctx.strokeStyle = "rgba(10, 18, 22, 0.72)";
  ctx.lineWidth = 1;
  ctx.stroke();
}

function niceGridStep(span) {
  const raw = Math.max(span / 10, 1e-6);
  const exponent = Math.floor(Math.log10(raw));
  const base = raw / 10 ** exponent;
  const rounded = base <= 1 ? 1 : base <= 2 ? 2 : base <= 5 ? 5 : 10;
  return rounded * 10 ** exponent;
}

function drawWorldGrid(ctx, width, height) {
  const transform = viewTransform(width, height);
  const center = transform.center;
  const floorZ = Math.min(0, transform.bounds.min[2]);
  const step = niceGridStep(transform.span);
  const count = 18;
  const startX = center[0] - count * step;
  const endX = center[0] + count * step;
  const startY = center[1] - count * step;
  const endY = center[1] + count * step;
  ctx.save();
  ctx.lineWidth = 1;
  for (let index = -count; index <= count; index += 1) {
    const y = center[1] + index * step;
    const a = projectWorldPoint([startX, y, floorZ], transform);
    const b = projectWorldPoint([endX, y, floorZ], transform);
    ctx.strokeStyle = index === 0 ? "rgba(91, 190, 156, 0.35)" : "rgba(255,255,255,0.08)";
    ctx.beginPath();
    ctx.moveTo(a.x, a.y);
    ctx.lineTo(b.x, b.y);
    ctx.stroke();
  }
  for (let index = -count; index <= count; index += 1) {
    const x = center[0] + index * step;
    const a = projectWorldPoint([x, startY, floorZ], transform);
    const b = projectWorldPoint([x, endY, floorZ], transform);
    ctx.strokeStyle = index === 0 ? "rgba(91, 190, 156, 0.35)" : "rgba(255,255,255,0.08)";
    ctx.beginPath();
    ctx.moveTo(a.x, a.y);
    ctx.lineTo(b.x, b.y);
    ctx.stroke();
  }
  ctx.restore();
}

function drawRotatingAxes(ctx, width, height) {
  const origin = { x: 36, y: height - 38 };
  const axes = [
    { label: "X", color: "#ff6f61", vector: [1, 0, 0] },
    { label: "Y", color: "#67d77f", vector: [0, 1, 0] },
    { label: "Z", color: "#74a7ff", vector: [0, 0, 1] }
  ];
  ctx.save();
  ctx.font = "700 13px Microsoft YaHei, Arial";
  ctx.lineCap = "round";
  for (const axis of axes) {
    const rotated = rotateViewVector(axis.vector);
    const dx = rotated.x * 44;
    const dy = -rotated.z * 44;
    ctx.strokeStyle = axis.color;
    ctx.fillStyle = axis.color;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(origin.x, origin.y);
    ctx.lineTo(origin.x + dx, origin.y + dy);
    ctx.stroke();
    ctx.fillText(axis.label, origin.x + dx + 5, origin.y + dy + 4);
  }
  ctx.restore();
}

function setView(yaw, pitch) {
  viewer.yaw = yaw;
  viewer.pitch = pitch;
  viewer.panX = 0;
  viewer.panY = 0;
  drawViewer();
}

function fitView() {
  viewer.zoom = 1;
  viewer.panX = 0;
  viewer.panY = 0;
  drawViewer();
}

async function loadScenes() {
  const catalog = await api("/api/scenes");
  sceneCatalog = catalog.scenes || [];
  const select = byId("scene");
  select.innerHTML = "";
  for (const scene of sceneCatalog) {
    const option = document.createElement("option");
    option.value = scene.id;
    option.textContent = scene.title;
    select.appendChild(option);
  }
  renderFields();
}

function renderProjects(projects) {
  const box = byId("projects");
  box.innerHTML = "";
  const 有效项目 = projects
    .filter((project) => typeof project.name === "string" && project.name.trim())
    .slice(0, 5);
  if (!有效项目.length) {
    box.textContent = "暂无项目。";
    return;
  }

  for (const project of 有效项目) {
    const row = document.createElement("div");
    row.className = "project-item";

    const text = document.createElement("div");
    const name = document.createElement("div");
    name.className = "project-name";
    name.textContent = project.name;
    const source = document.createElement("div");
    source.className = "project-source";
    source.textContent = project.source || "workspace";
    text.appendChild(name);
    text.appendChild(source);

    const button = document.createElement("button");
    button.type = "button";
    button.textContent = "使用";
    button.addEventListener("click", () => {
      byId("projectName").value = project.name || "";
      lastProjectName = project.name || "";
      updateContextStatus();
    });

    row.appendChild(text);
    row.appendChild(button);
    box.appendChild(row);
  }
}

async function loadProjects() {
  const result = await api("/api/projects");
  renderProjects(result.projects || []);
}

async function runAction(label, action) {
  try {
    setBusy(true);
    showStatus(`${label}...`);
    const result = await action();
    showOperationSummary(label, result);
    return result;
  } catch (error) {
    showError(error);
    return null;
  } finally {
    setBusy(false);
  }
}

async function resolveScene() {
  return runAction("正在解析参数", () =>
    api("/api/scene/resolve", {
      method: "POST",
      body: JSON.stringify(scenePayload())
    })
  );
}

async function generateScene() {
  if (!confirmGeneration()) return null;
  return runAction("正在生成模型", async () => {
    const result = await api("/api/scene/generate", {
      method: "POST",
      body: JSON.stringify(scenePayload({ if_exists: "versioned" }))
    });
    rememberGeneratedProjectName(result);
    await loadProjects();
    await loadInteractiveMesh(lastProjectName);
    return result;
  });
}

async function previewInteractiveModel() {
  const projectName = byId("projectName").value.trim() || lastProjectName;
  return runAction("正在刷新三维预览", () => loadInteractiveMesh(projectName));
}

async function openLsPrePost() {
  const projectName = byId("projectName").value.trim() || lastProjectName;
  return runAction("正在打开 LS-PrePost", () =>
    api("/api/project/open-lsprepost", {
      method: "POST",
      body: JSON.stringify({ project_name: projectName })
    })
  );
}

async function boot() {
  byId("prompt").addEventListener("input", () => {
    promptEdited = true;
  });
  byId("projectName").addEventListener("input", updateContextStatus);
  byId("scene").addEventListener("change", () => {
    renderFields();
  });
  byId("refresh").addEventListener("click", () => runAction("正在刷新项目", loadProjects));
  byId("importLspp").addEventListener("click", importLsppPath);
  byId("checkLspp").addEventListener("click", checkLsppPath);
  byId("saveLspp").addEventListener("click", saveLsppPath);
  byId("selectExportDir").addEventListener("click", selectExportDir);
  byId("saveExportDir").addEventListener("click", saveExportDir);
  byId("selectImportPackageDir").addEventListener("click", selectImportPackageDir);
  byId("importPackage").addEventListener("click", importPackage);
  byId("resolve").addEventListener("click", resolveScene);
  byId("generate").addEventListener("click", generateScene);
  byId("preview").addEventListener("click", previewInteractiveModel);
  byId("openLspp").addEventListener("click", openLsPrePost);
  byId("fitView").addEventListener("click", fitView);
  byId("isoView").addEventListener("click", () => setView(-0.65, 0.55));
  byId("topView").addEventListener("click", () => setView(0, 0));
  byId("frontView").addEventListener("click", () => setView(0, Math.PI / 2));
  setupViewerInput();

  await loadConfig();
  await loadScenes();
  await loadProjects();
  updateContextStatus();
  drawViewer();
}

boot().catch(showError);

function setupViewerInput() {
  const canvas = byId("modelCanvas");
  canvas.addEventListener("pointerdown", (event) => {
    viewer.dragging = true;
    viewer.dragButton = event.button;
    viewer.lastX = event.clientX;
    viewer.lastY = event.clientY;
    canvas.setPointerCapture(event.pointerId);
  });
  canvas.addEventListener("pointermove", (event) => {
    if (!viewer.dragging) return;
    const dx = event.clientX - viewer.lastX;
    const dy = event.clientY - viewer.lastY;
    viewer.lastX = event.clientX;
    viewer.lastY = event.clientY;
    if (viewer.dragButton === 2 || event.buttons === 4) {
      viewer.panX += dx;
      viewer.panY += dy;
    } else {
      viewer.yaw += dx * 0.01;
      viewer.pitch = Math.max(-1.45, Math.min(1.45, viewer.pitch + dy * 0.01));
    }
    drawViewer();
  });
  canvas.addEventListener("pointerup", (event) => {
    viewer.dragging = false;
    canvas.releasePointerCapture(event.pointerId);
  });
  canvas.addEventListener("pointerleave", () => {
    viewer.dragging = false;
  });
  canvas.addEventListener("contextmenu", (event) => event.preventDefault());
  canvas.addEventListener("wheel", (event) => {
    event.preventDefault();
    const factor = event.deltaY < 0 ? 1.1 : 0.9;
    viewer.zoom = Math.max(0.12, Math.min(30, viewer.zoom * factor));
    drawViewer();
  }, { passive: false });
  window.addEventListener("resize", drawViewer);
}
