from __future__ import annotations

import json
import shutil
from datetime import datetime, timezone
from pathlib import Path

from lsprepost_mcp.config import JSONDict


CORE_PROJECT_FILES = ("model.k", "model.json", "checks.json")


def export_project_copy(project_path: Path, export_dir: Path) -> JSONDict:
    if not project_path.is_dir():
        raise FileNotFoundError(f"project directory not found: {project_path}")
    export_dir.mkdir(parents=True, exist_ok=True)
    destination = export_dir / project_path.name
    destination.mkdir(parents=True, exist_ok=True)

    copied: list[str] = []
    for name in CORE_PROJECT_FILES:
        source = project_path / name
        if source.is_file():
            shutil.copy2(source, destination / name)
            copied.append(name)

    manifest = {
        "source_project_dir": str(project_path),
        "project_export_dir": str(destination),
        "files": copied,
        "saved_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    (destination / "export_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return {
        "enabled": True,
        "export_dir": str(export_dir),
        "project_export_dir": str(destination),
        "files": copied,
    }
