from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Optional

from lsprepost_mcp.config import JSONDict
from lsprepost_mcp.locks import ProjectLock
from lsprepost_mcp.paths import project_dir, safe_project_name
from lsprepost_mcp.project_store import ensure_no_active_runtime, next_versioned_project_dir
from lsprepost_mcp.web.http_utils import ApiError


REQUIRED_IMPORT_FILES = ("model.k", "model.json", "checks.json", "export_manifest.json")
JSON_IMPORT_FILES = ("model.json", "checks.json", "export_manifest.json")
ALLOWED_IF_EXISTS = {"error", "overwrite", "versioned"}


def inspect_project_package(source_dir: Path) -> JSONDict:
    source = source_dir.resolve()
    if not source.is_dir():
        raise ApiError(400, "invalid_import_package", "请选择一个模型文件夹")

    missing = [name for name in REQUIRED_IMPORT_FILES if not (source / name).is_file()]
    if missing:
        raise ApiError(
            400,
            "invalid_import_package",
            "模型文件夹不完整，缺少：" + "、".join(missing),
        )

    decoded: JSONDict = {}
    for name in JSON_IMPORT_FILES:
        try:
            decoded[name] = json.loads((source / name).read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise ApiError(400, "invalid_import_package", f"{name} 不是有效的模型信息文件") from exc

    return {
        "source_dir": str(source),
        "required_files": list(REQUIRED_IMPORT_FILES),
        "checks_ok": bool(decoded.get("checks.json", {}).get("ok")) if isinstance(decoded.get("checks.json"), dict) else False,
    }


def import_project_package(source_dir: Path, project_name: str = "", if_exists: str = "versioned") -> JSONDict:
    package = inspect_project_package(source_dir)
    if if_exists not in ALLOWED_IF_EXISTS:
        raise ApiError(400, "invalid_import_package", "if_exists must be error, overwrite, or versioned")

    source = Path(package["source_dir"])
    base_name = safe_project_name(project_name.strip() if project_name.strip() else source.name)
    with ProjectLock(base_name):
        target = project_dir(base_name)
        if target.exists():
            if if_exists == "error":
                raise ApiError(409, "project_exists", "项目已存在，请换一个项目名称")
            if if_exists == "versioned":
                target = next_versioned_project_dir(base_name)
            else:
                ensure_no_active_runtime(target)
                shutil.rmtree(target)
        target.mkdir(parents=True, exist_ok=True)

        copied: list[str] = []
        for name in REQUIRED_IMPORT_FILES:
            shutil.copy2(source / name, target / name)
            copied.append(name)

    return {
        "operation": "import_project_package",
        "project_name": target.name,
        "project_dir": str(target),
        "source_dir": str(source),
        "copied_files": copied,
        "checks_ok": package["checks_ok"],
    }


def import_project_package_payload(payload: JSONDict) -> JSONDict:
    raw_source = payload.get("source_dir")
    if not isinstance(raw_source, str) or not raw_source.strip():
        raise ApiError(400, "invalid_import_package", "source_dir must be a non-empty string")
    project_name = str(payload.get("project_name", "") or "")
    if_exists = str(payload.get("if_exists", "versioned") or "versioned")
    return import_project_package(Path(raw_source.strip()), project_name, if_exists=if_exists)


def select_import_project_package_payload(payload: JSONDict) -> JSONDict:
    selected = choose_import_package_dir()
    if selected is None:
        raise ApiError(400, "selection_cancelled", "模型文件夹选择已取消")
    project_name = str(payload.get("project_name", "") or "")
    if_exists = str(payload.get("if_exists", "versioned") or "versioned")
    return import_project_package(selected, project_name, if_exists=if_exists)


def choose_import_package_dir() -> Optional[Path]:
    try:
        import tkinter as tk
        from tkinter import filedialog
    except Exception:
        return None

    root = tk.Tk()
    root.withdraw()
    try:
        root.attributes("-topmost", True)
        selected = filedialog.askdirectory(title="选择完整模型文件夹")
    finally:
        root.destroy()
    return Path(selected) if selected else None
