from __future__ import annotations

from .config import JSONDict
from .paths import find_project_dir
from .project_store import write_model_project
from .scene_prompts import resolve_scene_prompt
from .schema import default_model_spec, parse_model_spec
from .tool_helpers import automation_timeout, bool_arg
from .tool_lsprepost import tool_export_preview_gif, tool_export_preview_images, tool_validate_lsprepost_import


def tool_generate_model(args: JSONDict) -> JSONDict:
    raw = args.get("spec") or default_model_spec()
    if not isinstance(raw, dict):
        raise ValueError("spec must be an object")
    return write_model_project(parse_model_spec(raw), if_exists=str(args.get("if_exists", "error")))


def tool_create_plate_demo(args: JSONDict) -> JSONDict:
    spec = default_model_spec(str(args.get("project_name", "plate_demo")), "shell_plate")
    geometry = spec["geometry"]
    mesh = spec["mesh"]
    material = spec["material"]
    if "length_m" in args:
        geometry["length_m"] = float(args["length_m"])
    if "width_m" in args:
        geometry["width_m"] = float(args["width_m"])
    if "thickness_m" in args:
        geometry["thickness_m"] = float(args["thickness_m"])
    if "mesh_size_m" in args:
        mesh["size_m"] = float(args["mesh_size_m"])
    if "material_name" in args:
        material["name"] = str(args["material_name"])
    return write_model_project(parse_model_spec(spec), if_exists=str(args.get("if_exists", "error")))


def tool_generate_scene_from_prompt(args: JSONDict) -> JSONDict:
    prompt = args.get("prompt")
    if not isinstance(prompt, str) or not prompt.strip():
        raise ValueError("prompt must be a non-empty string")
    project_name = str(args.get("project_name", "scene_from_prompt"))
    parameters = args.get("parameters") or {}
    if not isinstance(parameters, dict):
        raise ValueError("parameters must be an object")
    raw_scene_id = args.get("scene_id")
    scene_template = None
    if raw_scene_id is not None:
        if not isinstance(raw_scene_id, str) or not raw_scene_id.strip():
            raise ValueError("scene_id must be a non-empty string")
        scene_template = raw_scene_id.strip()
    allow_defaults = bool_arg(args, "allow_defaults", False)
    dry_run = bool_arg(args, "dry_run", False)
    run_lsprepost_validation = bool_arg(args, "run_lsprepost_validation", False)
    export_previews = bool_arg(args, "export_previews", False)
    export_preview_gif = bool_arg(args, "export_preview_gif", False)
    timeout_s = automation_timeout(args, default=45.0)
    resolved = resolve_scene_prompt(
        prompt,
        project_name,
        parameters=parameters,
        allow_defaults=allow_defaults,
        scene_template=scene_template,
    )
    if not resolved.get("ok"):
        return resolved
    if dry_run:
        parse_model_spec(resolved["resolved_spec"])
        return {
            "ok": True,
            "status": "resolved_only",
            "intent": resolved["intent"],
            "scene_template": resolved["scene_template"],
            "project_name": project_name,
            "resolved_parameters": resolved["resolved_parameters"],
            "defaulted_parameters": resolved["defaulted_parameters"],
            "risk_notes": resolved.get("risk_notes", []),
            "summary": resolved["summary"],
            "resolved_spec": resolved["resolved_spec"],
        }

    write_result = write_model_project(
        parse_model_spec(resolved["resolved_spec"]),
        if_exists=str(args.get("if_exists", "error")),
    )
    path = find_project_dir(write_result["project"])
    result: JSONDict = {
        "ok": True,
        "intent": resolved["intent"],
        "scene_template": resolved["scene_template"],
        "project_name": write_result["project"],
        "project_dir": str(path),
        "keyword_path": str(path / "model.k"),
        "resolved_parameters": resolved["resolved_parameters"],
        "defaulted_parameters": resolved["defaulted_parameters"],
        "risk_notes": resolved.get("risk_notes", []),
        "summary": resolved["summary"],
        "write_result": write_result,
        "checks": write_result["checks"],
    }
    if run_lsprepost_validation:
        result["lsprepost_import"] = tool_validate_lsprepost_import(
            {
                "project_name": write_result["project"],
                "timeout_s": timeout_s,
                "if_exists": "overwrite",
            }
        )
    if export_previews:
        result["preview_images"] = tool_export_preview_images(
            {
                "project_name": write_result["project"],
                "timeout_s": timeout_s,
                "display_mode": "geometry",
                "if_exists": "overwrite",
            }
        )
    if export_preview_gif:
        result["preview_gif"] = tool_export_preview_gif(
            {
                "project_name": write_result["project"],
                "timeout_s": timeout_s,
                "display_mode": "geometry",
                "if_exists": "overwrite",
            }
        )
    return result
