# 第五阶段模型校验说明

第五阶段目标是把 `checks.json` 从“必要文件和必要卡片检查”推进到“可发现常见 keyword 结构错误、网格质量风险和求解前预检查风险”。

当前实现仍是静态校验，不依赖 LS-DYNA 求解器，也不启动 LS-PrePost GUI。它用于生成后预检查，不能替代求解器检查和人工工程复核。

## 已实现检查项

- `quality.id.*`
  - 检查 node、shell element、solid element、part、material、section 的 ID 是否重复。

- `quality.ref.*`
  - 检查 element 是否引用存在的 node。
  - 检查 element 是否引用存在的 part。
  - 检查 part 是否引用存在的 section 和 material。
  - 检查 node set 是否引用存在的 node。
  - 检查 segment set 是否引用存在的 node。
  - 检查直接 `*LOAD_SEGMENT` 是否引用存在的 node。
  - 检查 `*LOAD_SEGMENT_SET` 是否引用存在的 segment set。

- `quality.geometry.*`
  - 检查 shell 单元面积是否大于零。
  - 检查 shell 单元 warpage 是否超过保守阈值。
  - 检查 shell 单元边长长宽比是否超过保守阈值。
  - 检查 solid 单元 8 个 Gauss 点 Jacobian 是否为正。
  - 检查 solid 单元积分体积是否为正。
  - 检查 solid 单元 Jacobian 比值是否过低。
  - 检查 solid 单元边长长宽比是否超过保守阈值。
  - 对 `shell_plate` 检查壳单元全局法向一致性。
  - 对载荷 segment 检查局部法向是否与来源单元面方向一致。

- `quality.keyword.*`
  - 检查 keyword deck 是否只有一个 `*KEYWORD`，并以最终 `*END` 结束。
  - 检查 keyword 卡片是否左对齐。
  - 检查大 ID 是否需要 `*KEYWORD long=yes`。
  - 对 `*INCLUDE` 的路径做基础存在性检查。
  - 对 `*PARAMETER` 与 `&name` 引用做基础定义检查。

- `quality.unsupported.*`
  - 如果发现 `*CONTACT_*`，当前标记为 warning，并阻断 `ok_for_solver_draft`。
  - 原因是接触仍未进入受控生成路径，尚缺 contact pair、segment/part 集合、初始穿透和摩擦参数来源校验。

- `quality.topology.*`
  - 检查孤立节点。
  - 检查未引用有效 part 的孤立单元。
  - 检查直接载荷 segment 是否真实匹配 shell 单元面或 solid 外表面。
  - 检查 segment set 内每个 segment 是否真实匹配 shell 单元面或 solid 外表面。

- `quality.shell.thickness_mesh_ratio`
  - 检查壳厚与网格尺寸比例。
  - 当前保守阈值为 `thickness / mesh_size <= 0.25`。

- `quality.material.*`
  - 检查材料密度是否处于宽泛工程范围。
  - 对 `*MAT_ELASTIC` 检查弹性模量和泊松比范围。

- `quality.estimate.mass`
  - 估算模型总质量。
  - shell 模型按 `area * thickness * density` 估算。
  - solid 模型按 8 点 Gauss 积分体积乘密度估算。

- `quality.estimate.stable_timestep`
  - 对弹性材料或提供波速/剪切模量/体积模量的材料估算显式稳定时间步。
  - 当前近似使用 `characteristic_length / wave_speed`。
  - 如果高级材料缺少可用波速信息，则以 warning 形式标记为 skipped。

## 新增状态分级

`checks.json` 现在除 `ok` 外，还提供 `readiness`：

- `ok_for_gui_preview`：适合进入 LS-PrePost 可视化导入预览。
- `ok_for_solver_draft`：适合进入初步求解草稿检查。
- `ok_for_production_review`：没有 error，也没有 warning，才可视为进入正式工程复核前的干净状态。

该分级避免把“LS-PrePost 能打开”和“模型已经工程可用”混为一谈。

注意：`checks.ok` 和 readiness 均来自本项目的本地静态检查，不是完整 LS-DYNA 求解器语义验证。第六阶段及之后的自动化工具如果面向求解草稿，应使用 `ok_for_solver_draft` 作为门槛；`ok_for_gui_preview` 只代表可以尝试进入 LS-PrePost 预览。

## 当前限制

- solid 单元体积已改为 8 点 Gauss Jacobian 检查；仍不能替代 LS-DYNA 求解器的完整网格质量和接触初始化检查。
- shell 全局法向一致性目前只对 `shell_plate` 启用；圆柱壳、壳盒等非平面壳结构主要依赖局部 segment 方向检查。
- 质量和稳定时间步估算用于工程预检查，不替代 LS-DYNA 求解器输出。
- import keyword 已进入基础质量校验，并增加 include、parameter、long format 的基础检查；但完整 LS-DYNA keyword 语义和复杂材料多行卡仍未完全解析。
- 接触卡会被识别和阻断求解草稿状态，但接触生成能力仍未开放。

## 验证状态

当前应通过：

```text
python -m unittest discover -s tests
scripts\smoke_test_generate_model.ps1
scripts\smoke_test_fourth_phase.ps1
examples\uuc_like_single_element.jsonl
```
