from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Callable

from .config import JSONDict

Segment = tuple[int, int, int, int]


@dataclass(frozen=True)
class KeywordModel:
    nodes: dict[int, tuple[float, float, float]]
    node_ids: list[int]
    shell_elements: list[tuple[int, int, int, int, int, int]]
    solid_elements: list[tuple[int, int, int, int, int, int, int, int, int, int]]
    parts: list[tuple[int, int | None, int | None]]
    section_id_list: list[int]
    material_id_list: list[int]
    material_density: dict[int, float]
    elastic_materials: dict[int, tuple[float, float, float]]
    section_ids: set[int]
    material_ids: set[int]
    shell_section_thickness: dict[int, float]
    node_sets: dict[int, list[int]]
    segment_sets: dict[int, list[Segment]]
    segment_loads: list[Segment]
    load_segment_set_ids: list[int]


def keyword_quality_checks(keyword: str, spec: JSONDict, metadata: JSONDict) -> list[JSONDict]:
    model = parse_keyword_model(keyword)
    checks: list[JSONDict] = []

    def add(check_id: str, ok: bool, message: str, severity: str = "error", actual: object | None = None) -> None:
        item: JSONDict = {"id": check_id, "ok": ok, "severity": "info" if ok else severity, "message": message}
        if actual is not None:
            item["actual"] = actual
        checks.append(item)

    check_keyword_structure(keyword, metadata, model, add)
    check_duplicate_ids(model, add)
    check_references(model, add)
    quality = check_element_quality(model, spec, add)
    check_orphans(model, add)
    check_shell_thickness_ratio(spec, model, add)
    check_material_ranges(model, add)
    estimate_mass_and_timestep(model, spec, quality, add)
    return checks


def check_keyword_structure(keyword: str, metadata: JSONDict, model: KeywordModel, add: Callable[..., None]) -> None:
    raw_lines = keyword.splitlines()
    stripped_nonempty = [line.strip() for line in raw_lines if line.strip()]
    card_tokens = [keyword_card_token(line) for line in stripped_nonempty]
    keyword_cards = [token for token in card_tokens if token in {"*KEYWORD"} or token.startswith("*KEYWORD_")]
    unsupported_keyword_cards = [token for token in keyword_cards if token not in {"*KEYWORD", "*KEYWORD_ID"}]
    end_indices = [index for index, token in enumerate(card_tokens) if token == "*END"]
    indented_cards = [
        index + 1
        for index, line in enumerate(raw_lines)
        if line.lstrip().startswith("*") and not line.startswith("*")
    ]
    add(
        "quality.keyword.boundary",
        len(keyword_cards) == 1
        and not unsupported_keyword_cards
        and len(end_indices) == 1
        and end_indices[0] == len(stripped_nonempty) - 1,
        "keyword deck has exactly one *KEYWORD card and exactly one final *END",
        actual={
            "keyword_cards": keyword_cards,
            "unsupported_keyword_cards": unsupported_keyword_cards,
            "end_positions": end_indices[-3:],
        },
    )
    add(
        "quality.keyword.card_alignment",
        not indented_cards,
        "keyword cards are left-aligned",
        actual=indented_cards or "ok",
    )
    long_format = any("LONG" in line.upper() and "YES" in line.upper() for line in stripped_nonempty if keyword_card_token(line) in keyword_cards)
    ids = [
        *model.node_ids,
        *[element[0] for element in model.shell_elements],
        *[element[0] for element in model.solid_elements],
        *[part[0] for part in model.parts],
        *model.material_id_list,
        *model.section_id_list,
    ]
    max_id = max(ids) if ids else 0
    add(
        "quality.keyword.long_format_id_range",
        long_format or max_id <= 9_999_999,
        "standard ID range fits fixed keyword fields" if max_id <= 9_999_999 else "large IDs should use *KEYWORD long=yes",
        severity="warning",
        actual={"max_id": max_id, "long_format": long_format},
    )
    check_include_paths(raw_lines, metadata, add)
    check_parameters(keyword, add)
    contact_cards = sorted({line.strip().split()[0].split(",")[0] for line in raw_lines if line.strip().upper().startswith("*CONTACT_")})
    controlled_contact_cards = {str(card).upper() for card in metadata.get("controlled_contact_cards", []) if str(card).strip()}
    unsupported_contact_cards = [card for card in contact_cards if card.upper() not in controlled_contact_cards]
    add(
        "quality.unsupported.contact_cards",
        not unsupported_contact_cards,
        "no contact cards found"
        if not contact_cards
        else "all contact cards are controlled by this generator"
        if not unsupported_contact_cards
        else "contact cards are not yet controlled by this generator",
        severity="warning",
        actual={"contact_cards": contact_cards, "unsupported": unsupported_contact_cards} if contact_cards else "ok",
    )


def keyword_card_token(line: str) -> str:
    item = line.strip()
    if not item.startswith("*"):
        return ""
    return item.replace(",", " ", 1).split()[0].upper()


def check_include_paths(raw_lines: list[str], metadata: JSONDict, add: Callable[..., None]) -> None:
    include_paths: list[str] = []
    for index, line in enumerate(raw_lines):
        upper = line.strip().upper()
        if not upper.startswith("*INCLUDE"):
            continue
        for next_line in raw_lines[index + 1 :]:
            item = next_line.strip()
            if not item or item.startswith("$"):
                continue
            if item.startswith("*"):
                break
            include_paths.append(item.split(",")[0].strip())
            break
    if not include_paths:
        add("quality.keyword.include_paths", True, "no include paths found", actual="none")
        return
    base = str(metadata.get("keyword_dir", "") or metadata.get("_project_dir", "") or "").strip()
    if not base:
        add(
            "quality.keyword.include_paths",
            False,
            "include paths found but no base directory is available for static path checks",
            severity="warning",
            actual=include_paths,
        )
        return
    from pathlib import Path

    base_path = Path(base)
    missing = []
    for include_path in include_paths:
        path = Path(include_path)
        resolved = path if path.is_absolute() else base_path / path
        if not resolved.exists():
            missing.append(include_path)
    add(
        "quality.keyword.include_paths",
        not missing,
        "all include paths exist",
        actual=missing or include_paths,
    )


def check_parameters(keyword: str, add: Callable[..., None]) -> None:
    tokens = keyword.replace(",", " ").replace("=", " ").split()
    defined: set[str] = set()
    used: set[str] = set()
    lines = [line.strip() for line in keyword.splitlines()]
    in_parameter = False
    for line in lines:
        upper = line.upper()
        if upper.startswith("*"):
            in_parameter = upper.startswith("*PARAMETER")
            continue
        if not in_parameter or not line or line.startswith("$"):
            continue
        fields = [field.strip() for field in line.replace(",", " ").split() if field.strip()]
        if len(fields) >= 2:
            defined.add(fields[1].lstrip("&"))
    for token in tokens:
        if token.startswith("&") and len(token) > 1:
            used.add(token[1:].strip())
    missing = sorted(used - defined)
    add(
        "quality.keyword.parameters",
        not missing,
        "all parameter references are defined",
        actual={"defined": sorted(defined), "missing": missing} if defined or missing else "none",
    )


def parse_keyword_model(keyword: str) -> KeywordModel:
    lines = [line.strip() for line in keyword.splitlines()]
    nodes: dict[int, tuple[float, float, float]] = {}
    node_ids: list[int] = []
    node_sets: dict[int, list[int]] = {}
    shell_elements: list[tuple[int, int, int, int, int, int]] = []
    solid_elements: list[tuple[int, int, int, int, int, int, int, int, int, int]] = []
    parts: list[tuple[int, int | None, int | None]] = []
    material_density: dict[int, float] = {}
    elastic_materials: dict[int, tuple[float, float, float]] = {}
    section_ids: set[int] = set()
    section_id_list: list[int] = []
    material_ids: set[int] = set()
    material_id_list: list[int] = []
    shell_section_thickness: dict[int, float] = {}
    segment_sets: dict[int, list[Segment]] = {}
    segment_loads: list[Segment] = []
    load_segment_set_ids: list[int] = []

    index = 0
    while index < len(lines):
        line = lines[index]
        upper = line.upper()
        if not upper.startswith("*"):
            index += 1
            continue
        if upper == "*NODE":
            index += 1
            while index < len(lines) and not lines[index].startswith("*"):
                fields = numeric_fields(lines[index])
                if len(fields) >= 4:
                    nid = int(fields[0])
                    node_ids.append(nid)
                    nodes[nid] = (float(fields[1]), float(fields[2]), float(fields[3]))
                index += 1
            continue
        if upper.startswith("*ELEMENT_SHELL"):
            index += 1
            while index < len(lines) and not lines[index].startswith("*"):
                fields = int_fields(lines[index])
                if len(fields) >= 6:
                    shell_elements.append((fields[0], fields[1], fields[2], fields[3], fields[4], fields[5]))
                index += 1
            continue
        if upper.startswith("*ELEMENT_SOLID"):
            index += 1
            while index < len(lines) and not lines[index].startswith("*"):
                fields = int_fields(lines[index])
                if len(fields) >= 10:
                    solid_elements.append((fields[0], fields[1], *fields[2:10]))
                index += 1
            continue
        if upper.startswith("*SET_NODE"):
            sid, ids, index = parse_node_set(lines, index)
            if sid is not None:
                node_sets[sid] = ids
            continue
        if upper.startswith("*SET_SEGMENT"):
            sid, segments, index = parse_segment_set(lines, index)
            if sid is not None:
                segment_sets[sid] = segments
            continue
        if upper.startswith("*LOAD_SEGMENT_SET"):
            index += 1
            while index < len(lines) and not lines[index].startswith("*"):
                fields = int_fields(lines[index])
                if fields:
                    load_segment_set_ids.append(fields[0])
                index += 1
            continue
        if upper.startswith("*LOAD_SEGMENT") and not upper.startswith("*LOAD_SEGMENT_SET"):
            index += 1
            while index < len(lines) and not lines[index].startswith("*"):
                fields = int_fields(lines[index])
                if len(fields) >= 7:
                    segment_loads.append((fields[3], fields[4], fields[5], fields[6]))
                index += 1
            continue
        if upper.startswith("*PART"):
            fields, next_index = next_numeric_fields(lines, index)
            if fields:
                pid = int(fields[0])
                secid = int(fields[1]) if len(fields) > 1 else None
                mid = int(fields[2]) if len(fields) > 2 else None
                parts.append((pid, secid, mid))
            index = max(next_index, index + 1)
            continue
        if upper.startswith("*SECTION_SHELL"):
            section_id, thickness, next_index = parse_shell_section(lines, index)
            if section_id is not None:
                section_ids.add(section_id)
                section_id_list.append(section_id)
                if thickness is not None:
                    shell_section_thickness[section_id] = thickness
            index = next_index
            continue
        if upper.startswith("*SECTION_"):
            fields, next_index = next_numeric_fields(lines, index)
            if fields:
                section_id = int(fields[0])
                section_ids.add(section_id)
                section_id_list.append(section_id)
            index = max(next_index, index + 1)
            continue
        if upper.startswith("*MAT_"):
            fields, next_index = next_numeric_fields(lines, index)
            if fields:
                mid = int(fields[0])
                material_ids.add(mid)
                material_id_list.append(mid)
                if len(fields) >= 2:
                    material_density[mid] = float(fields[1])
                if upper.startswith("*MAT_ELASTIC") and len(fields) >= 4:
                    elastic_materials[mid] = (float(fields[1]), float(fields[2]), float(fields[3]))
            index = max(next_index, index + 1)
            continue
        index += 1

    return KeywordModel(
        nodes=nodes,
        node_ids=node_ids,
        shell_elements=shell_elements,
        solid_elements=solid_elements,
        parts=parts,
        section_id_list=section_id_list,
        material_id_list=material_id_list,
        material_density=material_density,
        elastic_materials=elastic_materials,
        section_ids=section_ids,
        material_ids=material_ids,
        shell_section_thickness=shell_section_thickness,
        node_sets=node_sets,
        segment_sets=segment_sets,
        segment_loads=segment_loads,
        load_segment_set_ids=load_segment_set_ids,
    )


def parse_node_set(lines: list[str], start: int) -> tuple[int | None, list[int], int]:
    sid: int | None = None
    ids: list[int] = []
    index = start + 1
    while index < len(lines) and not lines[index].startswith("*"):
        fields = int_fields(lines[index])
        if fields:
            if sid is None:
                sid = fields[0]
            else:
                ids.extend(fields)
        index += 1
    return sid, ids, index


def parse_segment_set(lines: list[str], start: int) -> tuple[int | None, list[Segment], int]:
    sid: int | None = None
    segments: list[Segment] = []
    index = start + 1
    while index < len(lines) and not lines[index].startswith("*"):
        fields = int_fields(lines[index])
        if fields:
            if sid is None:
                sid = fields[0]
            elif len(fields) >= 4:
                segments.append((fields[0], fields[1], fields[2], fields[3]))
        index += 1
    return sid, segments, index


def parse_shell_section(lines: list[str], start: int) -> tuple[int | None, float | None, int]:
    fields, first_index = next_numeric_fields(lines, start)
    if not fields:
        return None, None, max(first_index, start + 1)
    section_id = int(fields[0])
    thickness: float | None = None
    index = first_index + 1
    while index < len(lines) and not lines[index].startswith("*"):
        t_fields = numeric_fields(lines[index])
        if len(t_fields) >= 4:
            thickness = sum(float(value) for value in t_fields[:4]) / 4.0
            return section_id, thickness, index + 1
        index += 1
    return section_id, thickness, index


def next_numeric_fields(lines: list[str], start: int) -> tuple[list[float], int]:
    for index in range(start + 1, len(lines)):
        if lines[index].startswith("*"):
            return [], index
        fields = numeric_fields(lines[index])
        if fields:
            return fields, index
    return [], len(lines)


def numeric_fields(line: str) -> list[float]:
    if not line or line.startswith("$"):
        return []
    chunks = line.split(",") if "," in line else line.split()
    values: list[float] = []
    for chunk in chunks:
        token = chunk.strip()
        if not token:
            continue
        try:
            values.append(float(token))
        except ValueError:
            return []
    return values


def int_fields(line: str) -> list[int]:
    return [int(value) for value in numeric_fields(line)]


def check_duplicate_ids(model: KeywordModel, add: Callable[..., None]) -> None:
    duplicate_checks = {
        "quality.id.nodes_unique": model.node_ids,
        "quality.id.shell_elements_unique": [element[0] for element in model.shell_elements],
        "quality.id.solid_elements_unique": [element[0] for element in model.solid_elements],
        "quality.id.parts_unique": [part[0] for part in model.parts],
        "quality.id.materials_unique": model.material_id_list,
        "quality.id.sections_unique": model.section_id_list,
    }
    for check_id, ids in duplicate_checks.items():
        duplicates = duplicate_ids(ids)
        add(check_id, not duplicates, "IDs are unique" if not duplicates else f"duplicate IDs found: {duplicates}", actual=duplicates or len(ids))


def duplicate_ids(ids: list[int]) -> list[int]:
    seen: set[int] = set()
    duplicates: set[int] = set()
    for value in ids:
        if value in seen:
            duplicates.add(value)
        seen.add(value)
    return sorted(duplicates)


def check_references(model: KeywordModel, add: Callable[..., None]) -> None:
    node_ids = set(model.nodes)
    part_ids = {part[0] for part in model.parts}
    missing_element_nodes = sorted(element[0] for element in all_elements(model) if not set(element[2:]).issubset(node_ids))
    missing_element_parts = sorted(element[0] for element in all_elements(model) if element[1] not in part_ids)
    missing_part_sections = sorted(pid for pid, secid, _ in model.parts if secid is None or secid not in model.section_ids)
    missing_part_materials = sorted(pid for pid, _, mid in model.parts if mid is None or mid not in model.material_ids)
    missing_set_nodes = sorted(sid for sid, ids in model.node_sets.items() if not set(ids).issubset(node_ids))
    missing_segment_set_nodes = sorted(
        sid
        for sid, segments in model.segment_sets.items()
        if any(not set(segment).issubset(node_ids) for segment in segments)
    )
    missing_segment_nodes = sorted(index + 1 for index, segment in enumerate(model.segment_loads) if not set(segment).issubset(node_ids))
    missing_load_segment_sets = sorted(set(model.load_segment_set_ids) - set(model.segment_sets))
    add("quality.ref.element_nodes", not missing_element_nodes, "all elements reference existing nodes", actual=missing_element_nodes or "ok")
    add("quality.ref.element_parts", not missing_element_parts, "all elements reference existing parts", actual=missing_element_parts or "ok")
    add("quality.ref.part_sections", not missing_part_sections, "all parts reference existing sections", actual=missing_part_sections or "ok")
    add("quality.ref.part_materials", not missing_part_materials, "all parts reference existing materials", actual=missing_part_materials or "ok")
    add("quality.ref.node_sets", not missing_set_nodes, "all node sets reference existing nodes", actual=missing_set_nodes or "ok")
    add("quality.ref.segment_sets", not missing_segment_set_nodes, "all segment sets reference existing nodes", actual=missing_segment_set_nodes or "ok")
    add("quality.ref.load_segments", not missing_segment_nodes, "all direct load segments reference existing nodes", actual=missing_segment_nodes or "ok")
    add(
        "quality.ref.load_segment_sets",
        not missing_load_segment_sets,
        "all segment-set pressure loads reference existing segment sets",
        actual=missing_load_segment_sets or "ok",
    )


def check_element_quality(model: KeywordModel, spec: JSONDict, add: Callable[..., None]) -> JSONDict:
    shell_areas: list[float] = []
    zero_shells: list[int] = []
    shell_warp_angles: list[float] = []
    shell_aspect_ratios: list[float] = []
    for element in model.shell_elements:
        if not all(nid in model.nodes for nid in element[2:6]):
            continue
        area = quad_area(model.nodes, element[2:6])
        shell_areas.append(area)
        shell_warp_angles.append(quad_warpage_degrees(model.nodes, element[2:6]))
        shell_aspect_ratios.append(quad_aspect_ratio(model.nodes, element[2:6]))
        if area <= 1.0e-18:
            zero_shells.append(element[0])
    solid_volumes: list[float] = []
    inverted_solids: list[int] = []
    poor_jacobian_solids: list[int] = []
    solid_aspect_ratios: list[float] = []
    for element in model.solid_elements:
        if not all(nid in model.nodes for nid in element[2:10]):
            continue
        jacobians = hexa_gauss_jacobians(model.nodes, element[2:10])
        signed_volume = sum(jacobians)
        min_jacobian = min(jacobians) if jacobians else 0.0
        max_jacobian = max(jacobians) if jacobians else 0.0
        if min_jacobian <= 1.0e-24 or signed_volume <= 1.0e-24:
            inverted_solids.append(element[0])
        elif min_jacobian / max_jacobian < 0.2:
            poor_jacobian_solids.append(element[0])
        solid_volumes.append(max(signed_volume, 0.0))
        solid_aspect_ratios.append(hexa_aspect_ratio(model.nodes, element[2:10]))
    if model.shell_elements:
        add("quality.geometry.shell_area", not zero_shells, "shell element areas are positive", actual={"zero_area_elements": zero_shells, "min_area_m2": min(shell_areas) if shell_areas else 0.0})
        warped_shells = [
            model.shell_elements[index][0]
            for index, angle in enumerate(shell_warp_angles)
            if angle > 15.0
        ]
        high_aspect_shells = [
            model.shell_elements[index][0]
            for index, ratio in enumerate(shell_aspect_ratios)
            if ratio > 10.0
        ]
        add(
            "quality.geometry.shell_warpage",
            not warped_shells,
            "shell element warpage is within conservative limit",
            severity="warning",
            actual={"warped_elements": warped_shells, "max_warpage_deg": max(shell_warp_angles) if shell_warp_angles else 0.0},
        )
        add(
            "quality.geometry.shell_aspect_ratio",
            not high_aspect_shells,
            "shell element aspect ratios are within conservative limit",
            severity="warning",
            actual={"high_aspect_elements": high_aspect_shells, "max_aspect_ratio": max(shell_aspect_ratios) if shell_aspect_ratios else 0.0},
        )
        check_shell_normals(model, spec, add)
    if model.solid_elements:
        add(
            "quality.geometry.solid_volume",
            not inverted_solids,
            "solid element Gauss-point Jacobians and integrated volumes are positive",
            actual={"non_positive_volume_elements": inverted_solids, "min_volume_m3": min(solid_volumes) if solid_volumes else 0.0},
        )
        add(
            "quality.geometry.solid_jacobian_ratio",
            not poor_jacobian_solids,
            "solid element Jacobian ratios are within conservative limit",
            severity="warning",
            actual={"poor_jacobian_elements": poor_jacobian_solids},
        )
        high_aspect_solids = [
            model.solid_elements[index][0]
            for index, ratio in enumerate(solid_aspect_ratios)
            if ratio > 10.0
        ]
        add(
            "quality.geometry.solid_aspect_ratio",
            not high_aspect_solids,
            "solid element aspect ratios are within conservative limit",
            severity="warning",
            actual={"high_aspect_elements": high_aspect_solids, "max_aspect_ratio": max(solid_aspect_ratios) if solid_aspect_ratios else 0.0},
        )
    check_segment_topology(model, add)
    return {"shell_areas": shell_areas, "solid_volumes": solid_volumes}


def check_segment_topology(model: KeywordModel, add: Callable[..., None]) -> None:
    if not model.segment_loads and not model.segment_sets:
        return
    surface_faces = surface_face_map(model)
    invalid_direct = [
        index + 1
        for index, segment in enumerate(model.segment_loads)
        if set(segment).issubset(model.nodes) and canonical_segment(segment) not in surface_faces
    ]
    invalid_sets: dict[int, list[int]] = {}
    for sid, segments in model.segment_sets.items():
        bad_indices = [
            index + 1
            for index, segment in enumerate(segments)
            if set(segment).issubset(model.nodes) and canonical_segment(segment) not in surface_faces
        ]
        if bad_indices:
            invalid_sets[sid] = bad_indices
    add(
        "quality.topology.load_segments_on_faces",
        not invalid_direct,
        "direct load segments match existing shell or exterior solid faces",
        actual=invalid_direct or "ok",
    )
    add(
        "quality.topology.segment_sets_on_faces",
        not invalid_sets,
        "segment-set entries match existing shell or exterior solid faces",
        actual=invalid_sets or "ok",
    )
    check_loaded_segment_orientation(model, surface_faces, add)


def check_loaded_segment_orientation(
    model: KeywordModel,
    surface_faces: dict[tuple[int, int, int, int], Segment],
    add: Callable[..., None],
) -> None:
    reversed_direct = [
        index + 1
        for index, segment in enumerate(model.segment_loads)
        if segment_orientation_dot(model, segment, surface_faces) < 0.0
    ]
    reversed_sets: dict[int, list[int]] = {}
    for sid in model.load_segment_set_ids:
        bad_indices = [
            index + 1
            for index, segment in enumerate(model.segment_sets.get(sid, []))
            if segment_orientation_dot(model, segment, surface_faces) < 0.0
        ]
        if bad_indices:
            reversed_sets[sid] = bad_indices
    add(
        "quality.geometry.load_segment_orientation",
        not reversed_direct and not reversed_sets,
        "loaded segment orientations match their source element faces",
        severity="warning",
        actual={"direct": reversed_direct, "sets": reversed_sets} if reversed_direct or reversed_sets else "ok",
    )


def check_shell_normals(model: KeywordModel, spec: JSONDict, add: Callable[..., None]) -> None:
    if spec.get("model_type") != "shell_plate":
        add("quality.geometry.shell_normals", True, "global shell normal consistency check skipped for non-planar shell model", actual=spec.get("model_type"))
        return
    normals = [quad_normal(model.nodes, element[2:6]) for element in model.shell_elements if all(nid in model.nodes for nid in element[2:6])]
    reference = next((normal for normal in normals if norm(normal) > 0.0), None)
    if reference is None:
        add("quality.geometry.shell_normals", False, "no valid shell normal could be computed")
        return
    inverted = [model.shell_elements[index][0] for index, normal in enumerate(normals) if dot(reference, normal) < 0.0]
    add("quality.geometry.shell_normals", not inverted, "shell normals are consistently oriented", actual=inverted or "ok", severity="warning")


def check_orphans(model: KeywordModel, add: Callable[..., None]) -> None:
    referenced_nodes: set[int] = set()
    for element in all_elements(model):
        referenced_nodes.update(element[2:])
    orphan_nodes = sorted(set(model.nodes) - referenced_nodes)
    orphan_elements = sorted(element[0] for element in all_elements(model) if element[1] not in {part[0] for part in model.parts})
    add("quality.topology.orphan_nodes", not orphan_nodes, "no orphan nodes found", severity="warning", actual=orphan_nodes or "ok")
    add("quality.topology.orphan_elements", not orphan_elements, "no orphan elements found", actual=orphan_elements or "ok")


def check_shell_thickness_ratio(spec: JSONDict, model: KeywordModel, add: Callable[..., None]) -> None:
    if not model.shell_elements:
        return
    mesh_size = float((spec.get("mesh") or {}).get("size_m", 0.0))
    thicknesses = list(model.shell_section_thickness.values())
    if mesh_size <= 0.0 or not thicknesses:
        add("quality.shell.thickness_mesh_ratio", True, "shell thickness/mesh ratio check skipped; mesh size or thickness unavailable", actual="skipped")
        return
    ratio = max(thicknesses) / mesh_size
    add(
        "quality.shell.thickness_mesh_ratio",
        ratio <= 0.25,
        "shell thickness is within a conservative mesh-size ratio" if ratio <= 0.25 else "shell thickness is large relative to mesh size",
        severity="warning",
        actual=ratio,
    )


def check_material_ranges(model: KeywordModel, add: Callable[..., None]) -> None:
    for mid, density in model.material_density.items():
        add(
            f"quality.material.{mid}.density_range",
            1.0 <= density <= 30000.0,
            "material density is within broad engineering range",
            severity="warning",
            actual=density,
        )
    for mid, (density, youngs, poisson) in model.elastic_materials.items():
        add(
            f"quality.material.{mid}.youngs_range",
            1.0e5 <= youngs <= 1.0e13,
            "elastic modulus is within broad engineering range",
            severity="warning",
            actual=youngs,
        )
        add(
            f"quality.material.{mid}.poisson_range",
            0.0 < poisson < 0.5,
            "Poisson ratio is within valid isotropic elastic range",
            severity="warning",
            actual=poisson,
        )
        add(
            f"quality.material.{mid}.wave_speed",
            density > 0.0 and youngs > 0.0,
            "elastic wave speed inputs are available",
            severity="warning",
            actual={"density_kg_per_m3": density, "youngs_pa": youngs},
        )


def estimate_mass_and_timestep(model: KeywordModel, spec: JSONDict, quality: JSONDict, add: Callable[..., None]) -> None:
    part_material = {pid: mid for pid, _, mid in model.parts if mid is not None}
    mass = 0.0
    for element in model.solid_elements:
        mid = part_material.get(element[1])
        density = model.material_density.get(mid or -1)
        if density is not None and all(nid in model.nodes for nid in element[2:10]):
            mass += density * max(sum(hexa_gauss_jacobians(model.nodes, element[2:10])), 0.0)
    for element in model.shell_elements:
        mid = part_material.get(element[1])
        density = model.material_density.get(mid or -1)
        thickness = first_shell_thickness(model, element[1])
        if density is not None and thickness is not None and all(nid in model.nodes for nid in element[2:6]):
            mass += density * quad_area(model.nodes, element[2:6]) * thickness
    add("quality.estimate.mass", mass > 0.0, "model mass estimate is available", severity="warning", actual={"mass_kg": mass})

    stable_dt = estimate_stable_timestep(model, spec, quality)
    if stable_dt is None:
        add("quality.estimate.stable_timestep", False, "stable time step estimate skipped; wave speed unavailable", severity="warning", actual="skipped")
    else:
        add("quality.estimate.stable_timestep", True, "estimated explicit stable time step", actual={"stable_dt_s": stable_dt})


def estimate_stable_timestep(model: KeywordModel, spec: JSONDict, quality: JSONDict) -> float | None:
    wave_speeds = material_wave_speeds(model, spec)
    if not wave_speeds:
        return None
    lengths: list[float] = []
    lengths.extend(math.sqrt(area) for area in quality.get("shell_areas", []) if area > 0.0)
    lengths.extend(volume ** (1.0 / 3.0) for volume in quality.get("solid_volumes", []) if volume > 0.0)
    if not lengths:
        return None
    return min(lengths) / max(wave_speeds)


def material_wave_speeds(model: KeywordModel, spec: JSONDict) -> list[float]:
    speeds = [math.sqrt(youngs / density) for density, youngs, _ in model.elastic_materials.values() if density > 0.0 and youngs > 0.0]
    material = spec.get("material", {}) if isinstance(spec, dict) else {}
    density = float(material.get("density_kg_per_m3", 0.0) or 0.0)
    explicit_speed = float(material.get("wave_speed_m_per_s", 0.0) or 0.0)
    if explicit_speed > 0.0:
        speeds.append(explicit_speed)
    if density > 0.0:
        bulk = float(material.get("bulk_modulus_pa", 0.0) or 0.0)
        shear = float(material.get("shear_modulus_pa", 0.0) or 0.0)
        youngs = float(material.get("youngs_pa", 0.0) or 0.0)
        if bulk > 0.0 and shear > 0.0:
            speeds.append(math.sqrt((bulk + 4.0 * shear / 3.0) / density))
        elif shear > 0.0:
            speeds.append(math.sqrt(shear / density))
        elif youngs > 0.0:
            speeds.append(math.sqrt(youngs / density))
    return [speed for speed in speeds if math.isfinite(speed) and speed > 0.0]


def first_shell_thickness(model: KeywordModel, part_id: int) -> float | None:
    section_by_part = {pid: secid for pid, secid, _ in model.parts}
    section_id = section_by_part.get(part_id)
    if section_id is None:
        return None
    return model.shell_section_thickness.get(section_id)


def all_elements(model: KeywordModel) -> list[tuple[int, ...]]:
    return [*model.shell_elements, *model.solid_elements]


def quad_area(nodes: dict[int, tuple[float, float, float]], node_ids: tuple[int, int, int, int]) -> float:
    if is_triangle_shell(node_ids):
        p1, p2, p3 = [nodes[nid] for nid in triangle_node_ids(node_ids)]
        return 0.5 * norm(cross(sub(p2, p1), sub(p3, p1)))
    p1, p2, p3, p4 = [nodes[nid] for nid in node_ids]
    return 0.5 * norm(cross(sub(p2, p1), sub(p3, p1))) + 0.5 * norm(cross(sub(p3, p1), sub(p4, p1)))


def quad_normal(nodes: dict[int, tuple[float, float, float]], node_ids: tuple[int, int, int, int]) -> tuple[float, float, float]:
    if is_triangle_shell(node_ids):
        p1, p2, p3 = [nodes[nid] for nid in triangle_node_ids(node_ids)]
        return cross(sub(p2, p1), sub(p3, p1))
    p1, p2, p3, p4 = [nodes[nid] for nid in node_ids]
    n1 = cross(sub(p2, p1), sub(p3, p1))
    n2 = cross(sub(p3, p1), sub(p4, p1))
    return (n1[0] + n2[0], n1[1] + n2[1], n1[2] + n2[2])


def quad_warpage_degrees(nodes: dict[int, tuple[float, float, float]], node_ids: tuple[int, int, int, int]) -> float:
    if is_triangle_shell(node_ids):
        return 0.0
    p1, p2, p3, p4 = [nodes[nid] for nid in node_ids]
    normal_123 = cross(sub(p2, p1), sub(p3, p1))
    normal_134 = cross(sub(p3, p1), sub(p4, p1))
    n1 = norm(normal_123)
    n2 = norm(normal_134)
    if n1 <= 0.0 or n2 <= 0.0:
        return 180.0
    cosine = max(-1.0, min(1.0, dot(normal_123, normal_134) / (n1 * n2)))
    return math.degrees(math.acos(cosine))


def quad_aspect_ratio(nodes: dict[int, tuple[float, float, float]], node_ids: tuple[int, int, int, int]) -> float:
    if is_triangle_shell(node_ids):
        p1, p2, p3 = [nodes[nid] for nid in triangle_node_ids(node_ids)]
        lengths = [distance(p1, p2), distance(p2, p3), distance(p3, p1)]
        positive = [value for value in lengths if value > 0.0]
        if not positive:
            return math.inf
        return max(positive) / min(positive)
    p1, p2, p3, p4 = [nodes[nid] for nid in node_ids]
    lengths = [distance(p1, p2), distance(p2, p3), distance(p3, p4), distance(p4, p1)]
    positive = [value for value in lengths if value > 0.0]
    if not positive:
        return math.inf
    return max(positive) / min(positive)


def is_triangle_shell(node_ids: tuple[int, int, int, int]) -> bool:
    return node_ids[2] == node_ids[3] or node_ids[3] == 0


def triangle_node_ids(node_ids: tuple[int, int, int, int]) -> tuple[int, int, int]:
    return node_ids[0], node_ids[1], node_ids[2]


def hexa_aspect_ratio(nodes: dict[int, tuple[float, float, float]], node_ids: tuple[int, ...]) -> float:
    coords = [nodes[nid] for nid in node_ids]
    edge_pairs = [
        (0, 1),
        (1, 2),
        (2, 3),
        (3, 0),
        (4, 5),
        (5, 6),
        (6, 7),
        (7, 4),
        (0, 4),
        (1, 5),
        (2, 6),
        (3, 7),
    ]
    lengths = [distance(coords[i], coords[j]) for i, j in edge_pairs]
    positive = [value for value in lengths if value > 0.0]
    if not positive:
        return math.inf
    return max(positive) / min(positive)


def distance(a: tuple[float, float, float], b: tuple[float, float, float]) -> float:
    return norm(sub(a, b))


def hexa_gauss_jacobians(nodes: dict[int, tuple[float, float, float]], node_ids: tuple[int, ...]) -> list[float]:
    gauss = 1.0 / math.sqrt(3.0)
    return [
        hexa_jacobian_determinant(nodes, node_ids, xi, eta, zeta)
        for xi in (-gauss, gauss)
        for eta in (-gauss, gauss)
        for zeta in (-gauss, gauss)
    ]


def hexa_jacobian_determinant(
    nodes: dict[int, tuple[float, float, float]],
    node_ids: tuple[int, ...],
    xi: float,
    eta: float,
    zeta: float,
) -> float:
    coords = [nodes[nid] for nid in node_ids]
    signs = [
        (-1.0, -1.0, -1.0),
        (1.0, -1.0, -1.0),
        (1.0, 1.0, -1.0),
        (-1.0, 1.0, -1.0),
        (-1.0, -1.0, 1.0),
        (1.0, -1.0, 1.0),
        (1.0, 1.0, 1.0),
        (-1.0, 1.0, 1.0),
    ]
    dxi = [0.125 * sx * (1.0 + sy * eta) * (1.0 + sz * zeta) for sx, sy, sz in signs]
    deta = [0.125 * sy * (1.0 + sx * xi) * (1.0 + sz * zeta) for sx, sy, sz in signs]
    dzeta = [0.125 * sz * (1.0 + sx * xi) * (1.0 + sy * eta) for sx, sy, sz in signs]
    j1 = tuple(sum(coords[i][axis] * dxi[i] for i in range(8)) for axis in range(3))
    j2 = tuple(sum(coords[i][axis] * deta[i] for i in range(8)) for axis in range(3))
    j3 = tuple(sum(coords[i][axis] * dzeta[i] for i in range(8)) for axis in range(3))
    return dot(j1, cross(j2, j3))


def hexa_center_signed_volume(nodes: dict[int, tuple[float, float, float]], node_ids: tuple[int, ...]) -> float:
    return 8.0 * hexa_jacobian_determinant(nodes, node_ids, 0.0, 0.0, 0.0)


def surface_face_map(model: KeywordModel) -> dict[tuple[int, int, int, int], Segment]:
    faces: dict[tuple[int, int, int, int], Segment] = {}
    solid_counts: dict[tuple[int, int, int, int], int] = {}
    solid_refs: dict[tuple[int, int, int, int], Segment] = {}
    for element in model.shell_elements:
        segment = (element[2], element[3], element[4], element[5])
        faces[canonical_segment(segment)] = segment
    for element in model.solid_elements:
        for segment in solid_face_segments(element):
            key = canonical_segment(segment)
            solid_counts[key] = solid_counts.get(key, 0) + 1
            solid_refs[key] = segment
    for key, count in solid_counts.items():
        if count == 1:
            faces[key] = solid_refs[key]
    return faces


def solid_face_segments(element: tuple[int, int, int, int, int, int, int, int, int, int]) -> list[Segment]:
    _, _, n1, n2, n3, n4, n5, n6, n7, n8 = element
    return [
        (n1, n4, n3, n2),
        (n5, n6, n7, n8),
        (n1, n2, n6, n5),
        (n2, n3, n7, n6),
        (n3, n4, n8, n7),
        (n4, n1, n5, n8),
    ]


def canonical_segment(segment: Segment) -> tuple[int, int, int, int]:
    return tuple(sorted(segment))


def segment_orientation_dot(
    model: KeywordModel,
    segment: Segment,
    surface_faces: dict[tuple[int, int, int, int], Segment],
) -> float:
    key = canonical_segment(segment)
    reference = surface_faces.get(key)
    if reference is None:
        return 0.0
    if not set(segment).issubset(model.nodes) or not set(reference).issubset(model.nodes):
        return 0.0
    return dot(quad_normal(model.nodes, segment), quad_normal(model.nodes, reference))


def sub(a: tuple[float, float, float], b: tuple[float, float, float]) -> tuple[float, float, float]:
    return a[0] - b[0], a[1] - b[1], a[2] - b[2]


def cross(a: tuple[float, float, float], b: tuple[float, float, float]) -> tuple[float, float, float]:
    return a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]


def dot(a: tuple[float, float, float], b: tuple[float, float, float]) -> float:
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def norm(a: tuple[float, float, float]) -> float:
    return math.sqrt(dot(a, a))
