from __future__ import annotations

import subprocess
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
START_SCRIPT = ROOT / "scripts" / "start_web_app.ps1"
ROOT_LAUNCHER = ROOT / "start_web_app.cmd"


class WebStartupTests(unittest.TestCase):
    def test_web_module_help_runs(self) -> None:
        result = subprocess.run(
            ["python", "-m", "lsprepost_mcp.web.app", "--help"],
            cwd=str(ROOT),
            text=True,
            capture_output=True,
            timeout=30,
        )
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("--port", result.stdout)
        self.assertIn("--lspp-exe", result.stdout)

    def test_start_web_app_script_exists_and_mentions_module(self) -> None:
        self.assertTrue(START_SCRIPT.exists())
        text = START_SCRIPT.read_text(encoding="utf-8")
        self.assertIn("lsprepost_mcp.web.app", text)
        self.assertIn("LsppExe", text)

    def test_start_web_app_script_forwards_open_browser_flag(self) -> None:
        self.assertTrue(START_SCRIPT.exists())
        text = START_SCRIPT.read_text(encoding="utf-8")
        self.assertIn("--open-browser", text)

    def test_root_one_click_launcher_exists_and_opens_browser(self) -> None:
        self.assertTrue(ROOT_LAUNCHER.exists())
        text = ROOT_LAUNCHER.read_text(encoding="utf-8")
        self.assertIn("scripts\\start_web_app.ps1", text)
        self.assertIn("-OpenBrowser", text)
        self.assertIn("-SkipDoctor", text)

    def test_root_one_click_launcher_pauses_on_startup_failure(self) -> None:
        self.assertTrue(ROOT_LAUNCHER.exists())
        text = ROOT_LAUNCHER.read_text(encoding="utf-8").lower()
        self.assertIn("if errorlevel 1", text)
        self.assertIn("pause", text)

    def test_start_web_app_script_forwards_open_browser_and_exits_on_invalid_port(self) -> None:
        fake_lspp_exe = ROOT / "tmp path with spaces" / "ls prepost.exe"
        result = subprocess.run(
            [
                "powershell",
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-File",
                str(START_SCRIPT),
                "-SkipDoctor",
                "-OpenBrowser",
                "-LsppExe",
                str(fake_lspp_exe),
                "-Port",
                "-1",
            ],
            cwd=str(ROOT),
            text=True,
            capture_output=True,
            timeout=30,
        )
        output = result.stdout + result.stderr
        self.assertNotEqual(result.returncode, 0, output)
        self.assertRegex(output.lower(), r"invalid|port|bind|argument")
        self.assertNotIn("lsprepost-mcp web app:", output)
        self.assertNotIn("unrecognized arguments", output.lower())

    def test_start_web_app_script_rejects_non_local_host(self) -> None:
        result = subprocess.run(
            [
                "powershell",
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-File",
                str(START_SCRIPT),
                "-SkipDoctor",
                "-HostName",
                "0.0.0.0",
                "-Port",
                "0",
            ],
            cwd=str(ROOT),
            text=True,
            capture_output=True,
            encoding="utf-8",
            errors="replace",
            timeout=30,
        )
        output = result.stdout + result.stderr
        self.assertNotEqual(result.returncode, 0, output)
        self.assertIn("host must be localhost or 127.0.0.1", output)


if __name__ == "__main__":
    unittest.main()
