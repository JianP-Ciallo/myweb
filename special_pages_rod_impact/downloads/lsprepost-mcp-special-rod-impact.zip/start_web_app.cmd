@echo off
setlocal
set "ROOT=%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%ROOT%scripts\start_web_app.ps1" -OpenBrowser -SkipDoctor
if errorlevel 1 (
  echo.
  echo lsprepost-mcp Web App failed to start. Check the error above.
  pause
)
exit /b %ERRORLEVEL%
