from __future__ import annotations

import argparse
import mimetypes
import os
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

from lsprepost_mcp.config import JSONDict, ROOT
from lsprepost_mcp.paths import find_project_dir
from lsprepost_mcp.tool_generation import tool_generate_model, tool_generate_scene_from_prompt
from lsprepost_mcp.tool_lsprepost import tool_export_preview_gif, tool_open_in_lsprepost
from lsprepost_mcp.tool_project import tool_list_projects, tool_read_project, tool_validate_model
from lsprepost_mcp.tool_server import tool_server_info
from lsprepost_mcp.web.config_api import (
    check_lsprepost_payload,
    configured_export_dir,
    save_lsprepost_payload,
    save_export_dir_payload,
    select_export_dir_payload,
    select_lsprepost_payload,
    web_config_status,
)
from lsprepost_mcp.web.http_utils import ApiError, json_error, json_ok, parse_json_body, safe_relative_path
from lsprepost_mcp.web.preview_mesh import build_preview_mesh
from lsprepost_mcp.web.project_export import export_project_copy
from lsprepost_mcp.web.project_import import import_project_package_payload, select_import_project_package_payload
from lsprepost_mcp.web.scenes import web_scene_catalog


LOCAL_HOSTS = {"127.0.0.1", "localhost"}


class WebAppServer(ThreadingHTTPServer):
    allow_reuse_address = True


def static_root() -> Path:
    built = ROOT / "web" / "dist"
    if (built / "index.html").exists():
        return built
    return Path(__file__).resolve().parent / "static"


def read_request_body(handler: BaseHTTPRequestHandler) -> bytes:
    raw_length = handler.headers.get("Content-Length", "0") or "0"
    try:
        length = int(raw_length)
    except ValueError as exc:
        raise ApiError(400, "invalid_request", "Content-Length must be an integer") from exc
    if length < 0:
        raise ApiError(400, "invalid_request", "Content-Length must not be negative")
    return handler.rfile.read(length) if length > 0 else b"{}"


def send_tuple(handler: BaseHTTPRequestHandler, response: tuple[int, dict[str, str], bytes]) -> None:
    status, headers, body = response
    handler.send_response(status)
    for key, value in headers.items():
        handler.send_header(key, value)
    handler.send_header("Content-Length", str(len(body)))
    handler.end_headers()
    if handler.command != "HEAD":
        handler.wfile.write(body)


def query_value(query: dict[str, list[str]], name: str) -> str:
    values = query.get(name) or []
    return values[0] if values else ""


def require_json_content_type(handler: BaseHTTPRequestHandler) -> None:
    media_type = (handler.headers.get("Content-Type") or "").split(";", 1)[0].strip().lower()
    if media_type != "application/json":
        raise ApiError(415, "unsupported_media_type", "Content-Type must be application/json")


def parsed_host_port(raw: str) -> tuple[str, int]:
    parsed = urlparse(f"//{raw}")
    if not parsed.hostname:
        raise ValueError("host is required")
    return parsed.hostname.lower(), parsed.port or 80


def parsed_url_origin(raw: str) -> tuple[str, str, int | None]:
    parsed = urlparse(raw)
    if not parsed.scheme or not parsed.hostname:
        raise ValueError("absolute URL is required")
    scheme = parsed.scheme.lower()
    return scheme, parsed.hostname.lower(), parsed.port or (80 if scheme == "http" else None)


def require_same_local_origin(handler: BaseHTTPRequestHandler) -> None:
    source = handler.headers.get("Origin")
    if not source:
        source = handler.headers.get("Referer")
    if not source:
        return

    try:
        request_host, request_port = parsed_host_port(handler.headers.get("Host") or "")
        source_scheme, source_host, source_port = parsed_url_origin(source)
    except ValueError as exc:
        raise ApiError(403, "forbidden_origin", "browser request origin is not allowed") from exc
    if source_scheme != "http" or source_host != request_host or source_port != request_port:
        raise ApiError(403, "forbidden_origin", "browser request origin is not allowed")


def attach_user_export(result: JSONDict) -> JSONDict:
    export_dir = configured_export_dir()
    if export_dir is None:
        return result

    raw_project_dir = (
        result.get("project_dir")
        or (result.get("write_result") if isinstance(result.get("write_result"), dict) else {}).get("project_dir")
    )
    if not isinstance(raw_project_dir, str) or not raw_project_dir.strip():
        return result

    project_path = Path(raw_project_dir)
    result["user_export"] = export_project_copy(project_path, export_dir)
    return result


class WebAppHandler(BaseHTTPRequestHandler):
    server_version = "lsprepost-mcp-web/0.1"

    def log_message(self, format: str, *args: object) -> None:
        return

    def do_GET(self) -> None:
        self.handle_request("GET")

    def do_HEAD(self) -> None:
        self.handle_request("HEAD")

    def do_POST(self) -> None:
        self.handle_request("POST")

    def handle_request(self, method: str) -> None:
        parsed = urlparse(self.path)
        query = parse_qs(parsed.query, keep_blank_values=True)
        response: tuple[int, dict[str, str], bytes] | None
        try:
            if parsed.path == "/api" or parsed.path.startswith("/api/"):
                response = self.handle_api(method, parsed.path, query)
            elif method in {"GET", "HEAD"}:
                response = self.handle_static(parsed.path)
            else:
                raise ApiError(405, "method_not_allowed", "method is not allowed")
        except ApiError as exc:
            response = json_error(exc.status, exc.code, exc.message)
        except FileNotFoundError as exc:
            response = json_error(404, "not_found", str(exc))
        except ValueError as exc:
            response = json_error(400, "invalid_request", str(exc))
        except Exception as exc:
            response = json_error(500, "internal_error", str(exc))
        if response is not None:
            send_tuple(self, response)

    def handle_api(
        self,
        method: str,
        path: str,
        query: dict[str, list[str]],
    ) -> tuple[int, dict[str, str], bytes] | None:
        if method in {"GET", "HEAD"}:
            return self.handle_api_get(path, query)
        if method == "POST":
            return self.handle_api_post(path)
        raise ApiError(405, "method_not_allowed", "method is not allowed")

    def handle_api_get(self, path: str, query: dict[str, list[str]]) -> tuple[int, dict[str, str], bytes] | None:
        if path == "/api/server-info":
            return json_ok(tool_server_info({}))
        if path == "/api/config":
            return json_ok(web_config_status())
        if path == "/api/scenes":
            return json_ok(web_scene_catalog())
        if path == "/api/projects":
            return json_ok(tool_list_projects({"include_archived": True}))
        if path == "/api/project":
            return json_ok(tool_read_project({"project_name": query_value(query, "project_name")}))
        if path == "/api/project/preview-mesh":
            project = find_project_dir(query_value(query, "project_name"))
            return json_ok(build_preview_mesh(project))
        if path == "/api/artifact":
            self.serve_artifact(query)
            return None
        raise ApiError(404, "not_found", f"route not found: {path}")

    def handle_api_post(self, path: str) -> tuple[int, dict[str, str], bytes]:
        body = read_request_body(self)
        require_json_content_type(self)
        require_same_local_origin(self)
        payload = parse_json_body(body)
        if path == "/api/scene/resolve":
            args: JSONDict = {**payload, "dry_run": True}
            return json_ok(tool_generate_scene_from_prompt(args))
        if path == "/api/scene/generate":
            return json_ok(attach_user_export(tool_generate_scene_from_prompt(payload)))
        if path == "/api/model/generate":
            return json_ok(attach_user_export(tool_generate_model(payload)))
        if path == "/api/project/validate":
            return json_ok(tool_validate_model(payload))
        if path == "/api/project/preview-gif":
            return json_ok(tool_export_preview_gif(payload))
        if path == "/api/project/open-lsprepost":
            return json_ok(tool_open_in_lsprepost(payload))
        if path == "/api/project/import-package":
            return json_ok(import_project_package_payload(payload))
        if path == "/api/project/select-import-package":
            return json_ok(select_import_project_package_payload(payload))
        if path == "/api/config/select-lsprepost":
            return json_ok(select_lsprepost_payload(payload))
        if path == "/api/config/check-lsprepost":
            return json_ok(check_lsprepost_payload(payload))
        if path == "/api/config/lsprepost":
            return json_ok(save_lsprepost_payload(payload))
        if path == "/api/config/select-export-dir":
            return json_ok(select_export_dir_payload(payload))
        if path == "/api/config/export-dir":
            return json_ok(save_export_dir_payload(payload))
        raise ApiError(404, "not_found", f"route not found: {path}")

    def serve_artifact(self, query: dict[str, list[str]]) -> None:
        project_name = query_value(query, "project_name")
        relative = safe_relative_path(query_value(query, "relative_path"))
        if relative.suffix.lower() not in {".png", ".gif", ".json", ".txt", ".xml"}:
            raise ApiError(400, "invalid_path", "artifact suffix is not allowed")

        project = find_project_dir(project_name)
        root = project.resolve()
        target = (project / relative).resolve()
        if root != target and root not in target.parents:
            raise ApiError(400, "invalid_path", "artifact path escaped project")
        if not target.is_file():
            raise ApiError(404, "not_found", "artifact not found")

        data = target.read_bytes()
        content_type = mimetypes.guess_type(str(target))[0] or "application/octet-stream"
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(data)

    def handle_static(self, raw_path: str) -> tuple[int, dict[str, str], bytes]:
        root = static_root().resolve()
        if raw_path in {"", "/"}:
            relative = Path("index.html")
        else:
            decoded = unquote(raw_path).replace("\\", "/").lstrip("/")
            relative = Path(decoded)
        if relative.is_absolute() or ".." in relative.parts:
            raise ApiError(404, "not_found", "static file not found")
        path = (root / relative).resolve()
        if root != path and root not in path.parents:
            raise ApiError(404, "not_found", "static file not found")
        if not path.is_file():
            if relative.suffix:
                raise ApiError(404, "not_found", "static file not found")
            path = root / "index.html"
        if not path.is_file():
            raise ApiError(404, "not_found", "static file not found")
        content_type = mimetypes.guess_type(str(path))[0] or "application/octet-stream"
        return 200, {"Content-Type": content_type}, path.read_bytes()


def create_server(host: str = "127.0.0.1", port: int = 8765, open_browser: bool = False) -> WebAppServer:
    if host.lower() not in LOCAL_HOSTS:
        raise ValueError("host must be localhost or 127.0.0.1")
    server = WebAppServer((host, port), WebAppHandler)
    url = f"http://{server.server_address[0]}:{server.server_address[1]}"
    if open_browser:
        webbrowser.open(url)
    return server


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run the lsprepost-mcp local Web App.")
    parser.add_argument("--host", default="127.0.0.1", help="Host interface to bind.")
    parser.add_argument("--port", type=int, default=8765, help="TCP port to bind.")
    parser.add_argument("--lspp-exe", default="", help="Optional LS-PrePost executable path.")
    parser.add_argument("--open-browser", action="store_true", help="Open the Web App URL in a browser.")
    args = parser.parse_args(argv)

    if args.lspp_exe:
        os.environ["LSPP_EXE"] = args.lspp_exe

    server = create_server(args.host, args.port, open_browser=args.open_browser)
    url = f"http://{server.server_address[0]}:{server.server_address[1]}"
    print(f"lsprepost-mcp web app: {url}", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        return 0
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
