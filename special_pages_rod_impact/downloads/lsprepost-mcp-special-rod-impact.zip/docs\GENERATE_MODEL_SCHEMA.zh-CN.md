# generate_model 输入 Schema

本文档说明 `generate_model` 当前支持的结构化输入。当前单位制已切换为国际单位制：

```text
SI_m_s_kg_N_Pa
```

含义：

```text
长度: m
时间: s
质量: kg
力: N
应力/弹性模量: Pa
密度: kg/m^3
```

## 支持的模型类型

当前支持：

- `shell_plate`：矩形壳单元板
- `solid_block`：矩形实体块，六面体实体单元
- `shell_box`：封闭矩形壳盒
- `cylinder_shell`：圆柱壳
- `cylinder_solid`：实体圆柱，采用规则六面体体素化近似
- `beam_bar`：细长实体杆，采用规则六面体实体近似
- `single_solid_element_test`：UUC 类 8 节点单实体单元测试模型

## 工具调用结构

```json
{
  "spec": {
    "project_name": "generic_plate_demo",
    "model_type": "shell_plate",
    "unit_system": "SI_m_s_kg_N_Pa",
    "geometry": {},
    "mesh": {},
    "material": {},
    "sets": [],
    "boundary_conditions": []
  }
}
```

## 通用字段

兼容性说明：为了适配不同 AI IDE 的自然语言生成，`generate_model` 对未知字段不做立即拒绝；但未知字段不会参与 keyword 编译，并会写入 `model.json` 的 `spec.warnings`，同时在 `checks.json` 中以 `schema.unknown_field.*` warning 形式出现。正式分析前应处理这些 warning。

覆盖策略：`generate_model` 顶层支持 `if_exists`，可选值为 `error`、`overwrite`、`archive_then_write`、`versioned`。默认 `error`，即同名项目存在时拒绝覆盖。示例 smoke test 为了可重复运行会显式使用 `overwrite`。

规模预检：生成 keyword 前会估算网格维度、节点数、单元数和 keyword 文件大小。超出安全上限时会拒绝生成，并返回建议的 `mesh.size_m`。

| 字段 | 类型 | 默认值 | 限制 | 说明 |
| --- | --- | --- | --- | --- |
| `project_name` | string | `plate_demo` | 只能使用安全项目名字符，其他字符会被替换为 `_` | 生成项目名称 |
| `model_type` | string | `shell_plate` | `shell_plate`、`solid_block`、`shell_box`、`cylinder_shell`、`cylinder_solid`、`beam_bar` | 模型类型 |
| `unit_system` | string | `SI_m_s_kg_N_Pa` | 当前只允许 `SI_m_s_kg_N_Pa` | 国际单位制 |
| `mesh.size_m` | number | `0.01` | `> 0` | 目标网格尺寸，单位 m |
| `material.name` | string | `mild_steel` | 非空建议 | 材料名称 |
| `material.type` | string | `elastic` | `elastic`、`cscm_concrete`、`johnson_holmquist_concrete`、`rht`、`concrete_damage_rel3`、`user_defined_material_models`、`user_defined_material` | 材料类型 |
| `material.density_kg_per_m3` | number | `7850` | `> 0` | 密度，单位 kg/m^3 |
| `material.youngs_pa` | number | `210000000000` | `> 0` | 弹性模量，单位 Pa |
| `material.poisson` | number | `0.3` | `0 < poisson < 0.5` | 泊松比 |
| `material.wave_speed_m_per_s` | number | 无 | `> 0` | 高级材料可选波速，用于显式稳定时间步预估 |
| `material.bulk_modulus_pa` / `material.shear_modulus_pa` | number | 无 | `> 0` | 高级材料可选体积/剪切模量，用于波速和时间步预估 |
| `material.confirmed_by_user` | boolean | `false` | 自定义未知材料时必须为 `true` | 表示用户已明确确认自定义材料参数 |
| `material.source` | string | 材料库内置 | 自定义未知材料时必须提供 | 材料参数来源 |
| `sets[].type` | string | 无 | `node_set`、`part_set`、`segment_set` | 命名集合类型 |
| `sets[].name` | string | 无 | 字母、数字、`_`、`-` | 命名集合名称 |
| `boundary_conditions[].type` | string | `fixed_edge` | 当前必须包含 `fixed_edge` | 边界条件类型 |
| `boundary_conditions[].edge` | string | `x_min` | `x_min`、`x_max`、`y_min`、`y_max`、`z_min`、`z_max` | 目标边界 |
| `loads[].type` | string | 无 | `nodal_force`、`gravity`、`pressure_on_segment_set`、`pressure_on_segment`、`initial_velocity` | 载荷类型 |

## 约束和载荷

第四阶段已支持受控的固定边界、位移边界、速度边界、节点力、重力、面压力和初速度。接触仍未开放。

`phase4_plate_load_demo/model.k` 已完成 LS-PrePost 2025 R1 GUI 导入截图验证，界面树可识别 `Prescribed_Motion`、`Spc`、`Curve`、`Load Body Z` 和 `Load Node Set`。

`phase4_remaining_load_demo/model.k` 已完成 LS-PrePost 2025 R1 GUI 导入截图验证，界面树可识别 `Prescribed_Motion`、`Initial Velocity`、`Load Segment`、`Node Set`、`Part Set`、`Segment Set` 和两条 `Curve`。

### 曲线策略

所有随时间变化的位移、速度、节点力、重力和压力都支持 `curve` 字段。未提供 `curve` 时，旧写法 `value + end_time_s` 会被编译为 `0 -> value` 的线性 ramp。

恒值曲线：

```json
{
  "curve": {
    "type": "constant",
    "value": 0.02,
    "end_time_s": 0.5
  }
}
```

线性 ramp：

```json
{
  "curve": {
    "type": "ramp",
    "start_time_s": 0.0,
    "start_value": 0.0,
    "end_time_s": 1.0,
    "end_value": 100.0
  }
}
```

用户自定义表格曲线：

```json
{
  "curve": {
    "type": "table",
    "points": [
      [0.0, 0.0],
      [0.2, 1000.0],
      [0.5, 500.0]
    ]
  }
}
```

表格曲线要求时间严格递增，且至少包含一个非零值。

### 命名集合和目标选择

第四阶段新增 `sets` 字段，用于把几何选择结果命名后复用。当前受控支持三类：

```json
{
  "sets": [
    {
      "type": "node_set",
      "name": "left_edge",
      "selector": {
        "type": "edge",
        "edge": "x_min"
      }
    },
    {
      "type": "segment_set",
      "name": "plate_surface",
      "selector": {
        "type": "face",
        "face": "z_max"
      }
    },
    {
      "type": "part_set",
      "name": "main_part",
      "part_ids": [1]
    }
  ]
}
```

载荷和约束可以通过 `target` 引用命名集合：

```json
{
  "target": {
    "type": "node_set",
    "name": "left_edge"
  }
}
```

旧写法仍兼容，例如直接写 `"edge": "x_min"`。

固定边界：

```json
{
  "type": "fixed_edge",
  "edge": "x_min"
}
```

生成：

```text
*SET_NODE_LIST
*BOUNDARY_SPC_SET
```

位移边界：

```json
{
  "type": "prescribed_displacement",
  "edge": "x_max",
  "dof": "x",
  "value_m": 0.001,
  "end_time_s": 1.0
}
```

生成：

```text
*SET_NODE_LIST
*DEFINE_CURVE
*BOUNDARY_PRESCRIBED_MOTION_SET
```

速度边界：

```json
{
  "type": "prescribed_velocity",
  "target": {
    "type": "node_set",
    "name": "right_edge"
  },
  "dof": "x",
  "value_m_per_s": 0.02,
  "curve": {
    "type": "constant",
    "value": 0.02,
    "end_time_s": 0.5
  }
}
```

生成：

```text
*SET_NODE_LIST
*DEFINE_CURVE
*BOUNDARY_PRESCRIBED_MOTION_SET
```

节点力：

```json
{
  "type": "nodal_force",
  "edge": "y_max",
  "dof": "y",
  "value_n": 100.0,
  "end_time_s": 1.0
}
```

生成：

```text
*SET_NODE_LIST
*DEFINE_CURVE
*LOAD_NODE_SET
```

重力：

```json
{
  "type": "gravity",
  "direction": "z",
  "acceleration_m_per_s2": -9.81,
  "end_time_s": 1.0
}
```

生成：

```text
*DEFINE_CURVE
*LOAD_BODY_Z
```

面压力：

```json
{
  "type": "pressure_on_segment_set",
  "target": {
    "type": "segment_set",
    "name": "plate_surface"
  },
  "pressure_pa": 1000.0,
  "curve": {
    "type": "table",
    "points": [
      [0.0, 0.0],
      [0.2, 1000.0],
      [0.5, 500.0]
    ]
  }
}
```

生成：

```text
*SET_SEGMENT
*DEFINE_CURVE
*LOAD_SEGMENT_SET
```

初速度：

```json
{
  "type": "initial_velocity",
  "target": {
    "type": "part_set",
    "name": "main_part"
  },
  "vector_m_per_s": [1.0, 0.0, 0.0]
}
```

生成：

```text
*SET_PART_LIST
*INITIAL_VELOCITY_NODE
```

说明：

- `dof` 和 `direction` 只允许 `x`、`y`、`z`。
- 位移单位为 m，速度单位为 m/s，节点力单位为 N，重力加速度单位为 m/s^2，压力单位为 Pa。
- `node_set` 当前通过边界选择器生成；`segment_set` 当前通过面选择器生成；`part_set` 当前只支持生成模型内的单一 part id `1`。
- 压力方向与壳单元法向有关，正式分析前需要在 LS-PrePost 中复核。
- 对 `cylinder_shell` 和 `cylinder_solid`，为了兼容早期模型，`x_min` / `x_max` 会作为轴向端部 `z_min` / `z_max` 的别名处理。

## 材料库规则

第三阶段开始，`material.name` 会优先解析内置材料库：

- `mild_steel`
- `aluminum_6061_t6`
- `rubber_generic`

推荐先调用：

```text
list_materials
get_material
```

然后在 `generate_model` 中只传入材料名：

```json
{
  "material": {
    "name": "aluminum_6061_t6"
  }
}
```

Server 会把材料库中的 `density_kg_per_m3`、`youngs_pa`、`poisson`、`yield_strength_pa`、`source`、`version`、`source_type` 写入 `model.json`。

未知材料不会被自动接受。如果确实要使用用户自定义材料，必须显式提供完整参数、来源，并设置：

```json
{
  "material": {
    "name": "lab_coupon_material",
    "type": "elastic",
    "density_kg_per_m3": 7800,
    "youngs_pa": 200000000000,
    "poisson": 0.29,
    "source": "user lab measurement report ABC-001",
    "confirmed_by_user": true
  }
}
```

这条规则用于避免 AI IDE 编造材料参数。

## UUC 类单元测试扩展

当前新增了面向 `UUC.k` 类文件的受控扩展，详见：

```text
docs/UUC_LIKE_SINGLE_ELEMENT.zh-CN.md
```

主要新增字段包括：
- `model_type: single_solid_element_test`
- 顶层 `curves`，用于生成可复用的 `*DEFINE_CURVE`
- 顶层 `hourglass`，用于生成 `*HOURGLASS_TITLE` 并由 `*PART` 引用
- 顶层 `analysis_control`，用于生成 `CONTROL_*`
- 顶层 `database`，用于生成 `DATABASE_*`
- 边界条件 `spc_node_set`，用于节点级自由度约束
- 载荷 `pressure_on_segment`，用于直接生成 `*LOAD_SEGMENT`

混凝土材料卡包括 `cscm_concrete`、`johnson_holmquist_concrete`、`rht`、`concrete_damage_rel3`。用户材料子程序卡可用 `user_defined_material_models` 结构化输出 `*MAT_USER_DEFINED_MATERIAL_MODELS`。这些材料都必须由用户显式确认参数来源：

```json
{
  "material": {
    "name": "confirmed_cscm_concrete",
    "type": "cscm_concrete",
    "density_kg_per_m3": 2300,
    "fpc_pa": 50000000,
    "wave_speed_m_per_s": 4200,
    "source": "user supplied lab calibration or reference keyword",
    "confirmed_by_user": true
  }
}
```

UUC 类用户材料子程序卡示例：

```json
{
  "material": {
    "name": "uuc_user_subroutine_material",
    "type": "user_defined_material_models",
    "id": 2,
    "density_kg_per_m3": 2300,
    "mt": 41,
    "lmc": 44,
    "nhv": 60,
    "iortho": 0,
    "ibulk": 3,
    "ig": 4,
    "ivect": 0,
    "ifail": 0,
    "constants": [-50000000, null, 17900000000, 14060000000, null, 0.5, -1],
    "source": "E:/Desktop/Single element/UUC/UUC.k",
    "confirmed_by_user": true
  }
}
```

`user_defined_material_models.constants` 允许使用 `null` 或空字符串保留 LS-DYNA 卡片字段占位，避免用户材料子程序参数位置被压缩。

`user_defined_material_models` 已支持通用用户材料子程序卡选项：

| 字段 | 含义 |
| --- | --- |
| `title` | 可选标题；存在时输出 `*MAT_USER_DEFINED_MATERIAL_MODELS_TITLE` |
| `mt` | 用户材料类型，例如常见 UMAT 41-50，或经模块映射后的类型号 |
| `lmc` | LMC 材料参数数量，`constants` 会按 8 个字段一行输出并补齐 |
| `nhv` | 积分点历史变量数量，当前限制 `<= 200` |
| `iortho` | 正交/各向异性相关开关，当前允许 `0/1/2/3` |
| `ibulk` / `ig` | bulk/shear 模量在参数数组中的位置 |
| `ivect` | 向量化用户材料例程开关 |
| `ifail` | 用户材料控制失效/侵蚀相关开关 |
| `itherm` | 温度传递开关 |
| `ihyper` | 变形梯度/超弹相关开关，当前允许 `-1/0/1/3` |
| `ieos` | EOS 相关开关 |
| `lmca` | 附加材料常数数组长度，`additional_constants` 会按 8 个字段一行输出并补齐 |
| `orthotropic_axes` | `iortho=1/3` 时的材料轴向定义，支持 `aopt`、`macf`、`xp/yp/zp`、`a1/a2/a3`、`v1/v2/v3`、`d1/d2/d3`、`beta`、`ievts` |

当前约束：`iortho=0/2` 时 `lmc <= 48`，`iortho=1/3` 时 `lmc <= 40`；更多参数应放入 `lmca/additional_constants`。

## geometry 字段

`shell_plate`：

```json
{
  "length_m": 0.12,
  "width_m": 0.06,
  "thickness_m": 0.0015
}
```

`solid_block`：

```json
{
  "length_m": 0.12,
  "width_m": 0.06,
  "height_m": 0.02
}
```

`shell_box`：

```json
{
  "length_m": 0.12,
  "width_m": 0.06,
  "height_m": 0.04,
  "thickness_m": 0.0015
}
```

`cylinder_shell`：

```json
{
  "radius_m": 0.03,
  "length_m": 0.12,
  "thickness_m": 0.0015
}
```

`cylinder_solid`：

```json
{
  "radius_m": 0.03,
  "length_m": 0.12
}
```

说明：当前实现是 `*ELEMENT_SOLID` 六面体体素化圆柱，圆周边界随网格尺寸呈阶梯/多面近似，不处理复杂拓扑和高质量扫掠网格。

`beam_bar`：

```json
{
  "length_m": 0.12,
  "width_m": 0.01,
  "height_m": 0.01
}
```

说明：当前实现是细长 `*ELEMENT_SOLID` 实体杆近似，不是 `*ELEMENT_BEAM` 梁单元公式。梁单元截面、局部坐标和积分格式会在后续阶段单独实现。

## 最小有效示例

```json
{
  "spec": {
    "project_name": "generic_plate_demo",
    "model_type": "shell_plate",
    "unit_system": "SI_m_s_kg_N_Pa",
    "geometry": {
      "length_m": 0.12,
      "width_m": 0.06,
      "thickness_m": 0.0015
    },
    "mesh": {
      "size_m": 0.01
    },
    "material": {
      "name": "mild_steel"
    },
    "sets": [],
    "boundary_conditions": [
      {
        "type": "fixed_edge",
        "edge": "x_min"
      }
    ],
    "loads": []
  }
}
```

## 输出文件

生成后项目位于：

```text
workspace\projects\<project_name>\
```

主要文件：

```text
model.json
model.k
open_model.cfile
checks.json
```

## 校验策略

`checks.json` 当前包含：

- `ok`：整体是否通过
- `errors`：阻止模型可靠使用的问题
- `warnings`：允许生成但需要注意的问题
- `counts`：节点数、单元数、part 数、材料数、截面数、约束数、node set 数、part set 数、segment set 数、载荷数、初始条件数、曲线数
- `checks`：逐项结构化检查结果
- `summary`：项目摘要
- 材料库来源、版本、单位制和是否需要工程复核的检查项

`import_keyword` 当前会解析基础数量统计，并额外检查 `*PART` 对 section/material 的基础引用关系。第五阶段后，导入的 keyword 也会进入 `quality.*` 静态质量校验，例如重复 ID、缺失节点引用、基础几何质量和 segment 引用检查。它仍不是完整 LS-DYNA keyword 语义解析器，暂不完整覆盖 include、parameter、long format 和复杂材料多行语义。

## 兼容说明

代码中保留了旧字段的兼容转换，例如 `length_mm` 会换算为 `length_m`，`youngs_mpa` 会换算为 `youngs_pa`。但新文档和新示例统一使用 SI 字段。后续推荐完全使用 SI 字段，避免单位混用。
