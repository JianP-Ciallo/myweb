# lsprepost-mcp

`lsprepost-mcp` 是一个本地 LS-PrePost / LS-DYNA keyword 建模工具。它把 AI IDE 或本地 Web App 的建模需求转换为受控模型文件：

```text
用户选择/描述受控场景
  -> 项目生成 model.json / model.k / checks.json
  -> Web App 中查看三维预览
  -> 必要时打开 LS-PrePost 复核
```

这个项目不是完整 LS-DYNA 前处理器，也不是开放式任意建模工具。它只支持项目内白名单场景、模板、材料和校验流程。

## 快速启动

解压项目后，在 Windows 上双击：

```text
start_web_app.cmd
```

浏览器会打开本地 Web App：

```text
http://127.0.0.1:8765/
```

首次使用时，在页面左侧导入或填写本机的 `lsprepost*.exe` 路径。路径只保存在本机 `generated_configs\web_app.local.json`，不会写入源码。

## 当前支持的受控场景

- 钢筋自由落体冲击固定椭球头盔壳
- 圆柱杆冲击固定钢板
- 立方体底部固定、顶面四角向下受载
- 壳板固定边界、承受均布压力

Web App 支持填写参数、生成模型、查看可拖拽三维预览、保存模型副本、导入完整模型文件夹，并在需要时打开 LS-PrePost。

## 生成文件

每个项目通常包含：

```text
model.k
model.json
checks.json
open_model.cfile
```

如果导出到用户自定义保存目录，还会包含：

```text
export_manifest.json
```

## AI IDE 使用

如果把项目交给 AI IDE 使用，请先让 AI IDE 阅读：

```text
AI_IDE_START_HERE.zh-CN.md
```

核心要求：

- 不要让 AI 直接手写 `.k` / `.key` / `.dyn` 文件。
- 所有 keyword 文件必须由本项目生成流程产生。
- AI IDE 只应调用受控工具、运行诊断、生成模型、校验模型、打开 LS-PrePost。

## 运行测试

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\run_tests.ps1
```

## 打包

生成纯净分发包：

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\pack.ps1 -BuildLabel "clean-release" -Pure
```

输出目录：

```text
dist\
```

## 重要限制

- `checks.ok` 是本地静态校验，不代表 LS-DYNA 求解通过。
- 内置材料参数是名义值，真实工程使用前必须复核。
- 自动 PNG/GIF 预览可能受 LS-PrePost 版本影响；预览失败不等于模型生成失败。
- 当前不运行 LS-DYNA 求解器，也不自动判断损伤、贯穿或失效结论。

更多说明见：

```text
README.zh-CN.md
docs\
```
