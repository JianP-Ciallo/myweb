# UUC 类单实体单元能力说明

本文档记录当前为 `UUC.k` 类单元测试文件补齐的受控生成能力。该能力面向材料模型验证、单元级边界条件检查和 LS-PrePost 导入预览，不等同于完整工程混凝土仿真模板。

## 新增能力

1. `single_solid_element_test` 模型类型
   - 生成 8 节点、1 个六面体实体单元。
   - 默认尺寸为 `0.01 m x 0.01 m x 0.01 m`。
   - 输出 `*SECTION_SOLID` 和 `*ELEMENT_SOLID`。

2. 混凝土材料卡
   - 支持 `cscm_concrete`，输出 `*MAT_CSCM_CONCRETE`。
   - 支持 `johnson_holmquist_concrete`，输出 `*MAT_JOHNSON_HOLMQUIST_CONCRETE`。
   - 支持 `rht`，输出 `*MAT_RHT`。
   - 支持 `concrete_damage_rel3`，输出 `*MAT_CONCRETE_DAMAGE_REL3`。
   - 支持 `user_defined_material_models`，结构化输出 `*MAT_USER_DEFINED_MATERIAL_MODELS`，用于 UUC 这类用户材料子程序卡。
   - 支持 `user_defined_material`，用于用户确认的 `*MAT_USER_DEFINED_MATERIAL_MODELS` 原始卡片行。
   - 以上高级材料必须显式提供 `confirmed_by_user: true` 和 `source`，避免 AI IDE 自动编造材料参数。

   `user_defined_material_models` 的受控输入示例：

   ```json
   {
     "material": {
       "name": "uuc_user_subroutine_material",
       "type": "user_defined_material_models",
       "id": 2,
       "density_kg_per_m3": 2300,
       "mt": 41,
       "lmc": 44,
       "nhv": 60,
       "iortho": 0,
       "ibulk": 3,
       "ig": 4,
       "ivect": 0,
       "ifail": 0,
       "constants": [-50000000, null, 17900000000, 14060000000, null, 0.5, -1],
       "source": "E:/Desktop/Single element/UUC/UUC.k",
       "confirmed_by_user": true
     }
   }
   ```

   `constants` 中允许使用 `null` 或空字符串保留 LS-DYNA 卡片字段占位，避免用户材料子程序参数位置被压缩。

   已支持的通用 `*MAT_USER_DEFINED_MATERIAL_MODELS` 选项：

   - Card 1：`id/mid`、`density_kg_per_m3`、`mt`、`lmc`、`nhv`、`iortho`、`ibulk`、`ig`。
   - Card 2：`ivect`、`ifail`、`itherm`、`ihyper`、`ieos`、`lmca`。
   - `title`：存在时输出 `*MAT_USER_DEFINED_MATERIAL_MODELS_TITLE`。
   - `constants`：输出 LMC 参数区，自动按 8 个字段一行补齐到 `lmc`。
   - `additional_constants`：输出 LMCA 附加参数区，自动按 8 个字段一行补齐到 `lmca`。
   - `orthotropic_axes`：当 `iortho` 为 `1` 或 `3` 时输出正交材料轴向卡，支持 `aopt`、`macf`、`xp/yp/zp`、`a1/a2/a3`、`v1/v2/v3`、`d1/d2/d3`、`beta`、`ievts`。

   当前校验边界：

   - `nhv <= 200`。
   - `iortho` 只能为 `0`、`1`、`2` 或 `3`。
   - `iortho` 为 `0/2` 时 `lmc <= 48`，`iortho` 为 `1/3` 时 `lmc <= 40`；更多参数应放入 `lmca/additional_constants`。
   - `ihyper` 只能为 `-1`、`0`、`1` 或 `3`。

3. 材料曲线
   - 新增顶层 `curves` 字段，输出 `*DEFINE_CURVE`。
   - 载荷和位移边界可通过 `curve_id` 引用顶层曲线。
   - 这使材料模型或工况可以共用已定义曲线。

4. Hourglass 控制
   - 新增顶层 `hourglass` 字段，输出 `*HOURGLASS_TITLE`。
   - `*PART` 的 `HGID` 会自动引用 `hourglass.id`。

5. 节点级 SPC
   - 新增边界条件 `spc_node_set`。
   - 支持直接指定 `node_ids` 和自由度列表 `dofs`。
   - 自由度支持 `x`、`y`、`z`、`rx`、`ry`、`rz`。
   - 输出 `*SET_NODE_LIST` 和 `*BOUNDARY_SPC_SET`。

6. 直接 Segment 载荷
   - 新增载荷 `pressure_on_segment`。
   - 通过四个节点 ID 直接定义 segment。
   - 输出 `*LOAD_SEGMENT`。

7. 控制与数据库输出
   - 新增 `analysis_control`，支持 `CONTROL_ENERGY`、`CONTROL_SHELL`、`CONTROL_TIMESTEP`、`CONTROL_TERMINATION`。
   - 新增 `database`，支持 `DATABASE_FORMAT`、`DATABASE_BINARY_D3PLOT`、`DATABASE_BINARY_D3THDT`、`DATABASE_EXTENT_BINARY`。

## 示例文件

新增 JSON-RPC 示例：

```text
examples\uuc_like_single_element.jsonl
```

运行：

```powershell
Get-Content .\examples\uuc_like_single_element.jsonl | python .\lsprepost_mcp\server.py
```

生成项目：

```text
workspace\projects\uuc_like_single_element_demo\
```

关键输出：

```text
model.k
model.json
checks.json
open_model.cfile
```

当前验证结果：

```text
checks.ok = true
nodes = 8
elements = 1
loads = 3
curves = 2
hourglass = 1
controls = 4
databases = 4
```

## LS-PrePost GUI 导入验证

已完成一次 LS-PrePost 2025 R1 GUI 导入截图验证：

```text
workspace\projects\uuc_like_single_element_demo\model.k
```

截图中可确认：
- 单实体六面体单元可正常显示为立方体。
- Part 树中识别到 `confirmed_cscm_concrete_single_solid_element`。
- Boundary 树中识别到 `Prescribed_Motion` 和多个 `Spc` 节点集。
- Define 树中识别到两条曲线：`LCID(1)` 和 `LCID(2)`。
- Load 树中识别到 3 个 `Segment` 载荷。
- Set 树中识别到加载节点集和各节点 SPC 集合。

该截图验证说明当前 keyword 至少可被 LS-PrePost 正常导入、显示并识别主要边界/载荷实体。材料参数、控制卡、数据库输出卡仍需结合 `model.k` 文本和后续 LS-DYNA 求解前检查确认。

## 当前限制

- 混凝土材料参数只做必要字段和数值合法性检查，不判断参数是否来自正式试验标定。
- `single_solid_element_test` 只适合单元级测试，不适合真实结构网格。
- `*LOAD_SEGMENT` 目前只检查四个节点 ID 为正整数，不做 segment 几何方向和外法向校验。
- `CONTROL_*` 和 `DATABASE_*` 当前支持常用字段，尚未覆盖 LS-DYNA 全量选项。
- 接触仍未开放，仍建议等 part/set/segment 校验机制进一步增强后再进入。
