# 第十阶段测试体系

第十阶段目标是把测试从“只有一条全量 unittest 命令”扩展为可分组、可解释、可分发使用的测试矩阵。

## 测试入口

统一入口：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\run_test_matrix.ps1 -List
```

运行默认测试：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\run_test_matrix.ps1 -Group default
```

运行关键回归测试：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\run_test_matrix.ps1 -Group critical
```

运行打包和安装边界测试：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\run_test_matrix.ps1 -Group packaging
```

运行 keyword 快照测试：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\run_test_matrix.ps1 -Group snapshots
```

运行错误输入测试：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\run_test_matrix.ps1 -Group errors
```

运行路径健壮性测试：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\run_test_matrix.ps1 -Group paths
```

运行真实 LS-PrePost GUI 集成测试：

```powershell
$env:LSPP_INTEGRATION = "1"
$env:LSPP_EXE = "<LS_PREPOST_EXE>"
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\run_test_matrix.ps1 -Group gui
```

## 分组说明

- `default`：运行 `python -m unittest discover -s tests`。真实 GUI 集成默认仍会跳过。
- `critical`：运行 JSON-RPC、工具调用、生成来源校验、第九阶段兼容入口、打包边界等关键回归测试。
- `packaging`：运行分发包、安装脚本、边界扫描相关测试。
- `snapshots`：对代表性 `model.k` 输出做 SHA256 快照测试，覆盖基础壳板、实体块和钢筋冲击头盔场景。
- `errors`：运行错误输入测试，覆盖非法数值、未知材料、错误自定义材料确认、非法接触类型。
- `paths`：运行路径健壮性测试，覆盖脚本从带空格和中文的当前目录调用时仍能定位项目。
- `gui`：运行真实 LS-PrePost GUI 集成测试，需要本机配置 `LSPP_INTEGRATION=1` 和 `LSPP_EXE`。
- `all`：运行默认测试并执行 `compileall`。

## 当前边界

- 默认测试不要求安装 LS-PrePost。
- GUI 集成测试是可选门禁，不应在没有 LS-PrePost GUI 的机器上强制运行。
- 如果 LS-PrePost 版本导致 PNG/GIF 导出失败，应按 README 说明提示用户人工打开 LS-PrePost 验证，不把导图失败直接等同于模型生成失败。
- 如果预期内修改了 keyword 输出格式，需要同步更新 `tests/snapshots/keyword_hashes.json`，并在变更说明中解释为什么快照变化合理。
- 第十阶段默认可运行测试体系已覆盖测试矩阵、关键回归、打包边界、keyword 快照、错误输入和基础路径健壮性。
