from __future__ import annotations

import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from tests.test_web_api import request_json, web_test_server

from lsprepost_mcp.config import ROOT


LOCAL_CONFIG = ROOT / "generated_configs" / "web_app.local.json"


class WebConfigRouteTests(unittest.TestCase):
    def setUp(self) -> None:
        self._old_lspp_exe = os.environ.pop("LSPP_EXE", None)
        self._old_config_text = LOCAL_CONFIG.read_text(encoding="utf-8") if LOCAL_CONFIG.exists() else None
        LOCAL_CONFIG.unlink(missing_ok=True)

    def tearDown(self) -> None:
        if self._old_lspp_exe is None:
            os.environ.pop("LSPP_EXE", None)
        else:
            os.environ["LSPP_EXE"] = self._old_lspp_exe
        if self._old_config_text is None:
            LOCAL_CONFIG.unlink(missing_ok=True)
        else:
            LOCAL_CONFIG.parent.mkdir(parents=True, exist_ok=True)
            LOCAL_CONFIG.write_text(self._old_config_text, encoding="utf-8")

    def test_config_route_reports_unconfigured_state(self) -> None:
        with web_test_server() as address:
            status, payload = request_json(address, "GET", "/api/config")

        self.assertEqual(status, 200)
        self.assertTrue(payload["ok"])
        result = payload["result"]
        self.assertFalse(result["configured"])
        self.assertEqual(result["source"], "default")
        self.assertEqual(result["lspp_exe"], "lsprepost4.12.exe")
        self.assertFalse(result["export_dir_configured"])
        self.assertEqual(result["export_dir"], "")

    def test_check_lsprepost_route_validates_without_saving(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            exe = Path(temp_dir) / "lsprepost4.12.exe"
            exe.write_text("fake exe", encoding="utf-8")
            with web_test_server() as address:
                status, payload = request_json(
                    address,
                    "POST",
                    "/api/config/check-lsprepost",
                    {"lspp_exe": str(exe)},
                )

        self.assertEqual(status, 200)
        self.assertTrue(payload["ok"])
        self.assertTrue(payload["result"]["doctor"]["ok"])
        self.assertFalse(LOCAL_CONFIG.exists())

    def test_save_lsprepost_route_persists_path_and_updates_process_env(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            exe = Path(temp_dir) / "lsprepost4.12.exe"
            exe.write_text("fake exe", encoding="utf-8")
            with web_test_server() as address:
                status, payload = request_json(
                    address,
                    "POST",
                    "/api/config/lsprepost",
                    {"lspp_exe": str(exe)},
                )

        self.assertEqual(status, 200)
        self.assertTrue(payload["ok"])
        self.assertEqual(os.environ.get("LSPP_EXE"), str(exe))
        saved = json.loads(LOCAL_CONFIG.read_text(encoding="utf-8"))
        self.assertEqual(saved["lspp_exe"], str(exe))
        self.assertTrue(payload["result"]["configured"])
        self.assertEqual(payload["result"]["source"], "local_config")

    def test_save_lsprepost_route_rejects_directory_that_looks_like_exe(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            fake_dir = Path(temp_dir) / "lsprepost4.12.exe"
            fake_dir.mkdir()
            with web_test_server() as address:
                status, payload = request_json(
                    address,
                    "POST",
                    "/api/config/lsprepost",
                    {"lspp_exe": str(fake_dir)},
                )

        self.assertEqual(status, 400)
        self.assertFalse(payload["ok"])
        self.assertEqual(payload["error"]["code"], "invalid_lsprepost_path")

    def test_select_lsprepost_route_uses_backend_file_picker_and_saves_path(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            exe = Path(temp_dir) / "lsprepost4.12.exe"
            exe.write_text("fake exe", encoding="utf-8")
            with patch("lsprepost_mcp.web.config_api.choose_lsprepost_exe", return_value=exe):
                with web_test_server() as address:
                    status, payload = request_json(address, "POST", "/api/config/select-lsprepost", {})

        self.assertEqual(status, 200)
        self.assertTrue(payload["ok"])
        self.assertTrue(payload["result"]["configured"])
        self.assertEqual(os.environ.get("LSPP_EXE"), str(exe))

    def test_select_lsprepost_route_reports_cancelled_selection(self) -> None:
        with patch("lsprepost_mcp.web.config_api.choose_lsprepost_exe", return_value=None):
            with web_test_server() as address:
                status, payload = request_json(address, "POST", "/api/config/select-lsprepost", {})

        self.assertEqual(status, 400)
        self.assertFalse(payload["ok"])
        self.assertEqual(payload["error"]["code"], "selection_cancelled")

    def test_save_export_dir_route_persists_path_without_removing_lsprepost_path(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            exe = Path(temp_dir) / "lsprepost4.12.exe"
            exe.write_text("fake exe", encoding="utf-8")
            export_dir = Path(temp_dir) / "exports"
            export_dir.mkdir()

            with web_test_server() as address:
                first_status, _first_payload = request_json(
                    address,
                    "POST",
                    "/api/config/lsprepost",
                    {"lspp_exe": str(exe)},
                )
                status, payload = request_json(
                    address,
                    "POST",
                    "/api/config/export-dir",
                    {"export_dir": str(export_dir)},
                )

        self.assertEqual(first_status, 200)
        self.assertEqual(status, 200)
        self.assertTrue(payload["ok"])
        result = payload["result"]
        self.assertTrue(result["export_dir_configured"])
        self.assertEqual(result["export_dir"], str(export_dir))
        saved = json.loads(LOCAL_CONFIG.read_text(encoding="utf-8"))
        self.assertEqual(saved["lspp_exe"], str(exe))
        self.assertEqual(saved["export_dir"], str(export_dir))

    def test_save_export_dir_route_rejects_file_path(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            file_path = Path(temp_dir) / "not_a_dir.txt"
            file_path.write_text("not a folder", encoding="utf-8")
            with web_test_server() as address:
                status, payload = request_json(
                    address,
                    "POST",
                    "/api/config/export-dir",
                    {"export_dir": str(file_path)},
                )

        self.assertEqual(status, 400)
        self.assertFalse(payload["ok"])
        self.assertEqual(payload["error"]["code"], "invalid_export_dir")

    def test_select_export_dir_route_uses_backend_folder_picker_and_saves_path(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            export_dir = Path(temp_dir)
            with patch("lsprepost_mcp.web.config_api.choose_export_dir", return_value=export_dir):
                with web_test_server() as address:
                    status, payload = request_json(address, "POST", "/api/config/select-export-dir", {})

        self.assertEqual(status, 200)
        self.assertTrue(payload["ok"])
        self.assertTrue(payload["result"]["export_dir_configured"])
        self.assertEqual(payload["result"]["export_dir"], str(export_dir))


if __name__ == "__main__":
    unittest.main()
