$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $PSScriptRoot
$messages = Join-Path $root "examples\generate_model.jsonl"
$server = Join-Path $root "lsprepost_mcp\server.py"

Get-Content -LiteralPath $messages | python $server
