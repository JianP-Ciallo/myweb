from __future__ import annotations

from .config import JSONDict
from .materials import get_material, list_materials


def tool_list_materials(_: JSONDict) -> JSONDict:
    materials = list_materials()
    return {"materials": materials, "count": len(materials)}


def tool_get_material(args: JSONDict) -> JSONDict:
    material_id = str(args.get("material_id") or args.get("name") or "")
    return {"material": get_material(material_id)}
