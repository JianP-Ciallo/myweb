from __future__ import annotations

from typing import Callable

from .config import JSONDict
from .lspp.launcher import launch_cfile, launch_keyword
from .scene_prompts import SUPPORTED_SCENE_TEMPLATES
from .schema import generate_model_input_schema
from .tool_generation import tool_create_plate_demo, tool_generate_model, tool_generate_scene_from_prompt
from .tool_materials import tool_get_material, tool_list_materials
from .tool_lsprepost import (
    tool_export_preview_gif,
    tool_export_preview_image,
    tool_export_preview_images,
    tool_open_in_lsprepost,
    tool_run_cfile,
    tool_validate_lsprepost_import,
)
from .tool_project import (
    tool_archive_project,
    tool_import_keyword,
    tool_list_projects,
    tool_model_summary,
    tool_read_project,
    tool_validate_model,
)
from .tool_server import tool_server_info
from .tool_helpers import (
    GIF_SIGNATURES,
    MAX_AUTOMATION_TIMEOUT_S,
    MAX_GUI_TIMEOUT_S,
    PHASE6_REQUIRED_KEYWORDS,
    PNG_SIGNATURE,
    PREVIEW_DISPLAY_MODES,
    PREVIEW_VIEW_COMMANDS,
    automation_timeout,
    bool_arg,
    cfile_relative_path,
    failed_lsprepost_result,
    gif_duration_arg,
    preview_cfile_filename,
    preview_display_commands,
    preview_display_mode_arg,
    preview_keyword_reader_filename,
    preview_output_prefix_arg,
    preview_view_arg,
    preview_views_arg,
    record_lsprepost_verification,
    resolve_project_cfile,
    validate_phase6_required_keywords,
    verify_gif_artifact,
    verify_keyword_reader_messages,
    verify_png_artifact,
    write_preview_gif,
)


ToolFn = Callable[[JSONDict], JSONDict]


TOOLS: dict[str, tuple[str, JSONDict, ToolFn]] = {
    "server_info": (
        "Return local LS-PrePost MCP server paths and defaults.",
        {"type": "object", "properties": {}, "additionalProperties": False},
        tool_server_info,
    ),
    "generate_model": (
        "Generate model.json, model.k, open_model.cfile, and checks.json from a structured SI model spec.",
        generate_model_input_schema(),
        tool_generate_model,
    ),
    "create_plate_demo": (
        "Compatibility helper that creates a simple SI shell plate demo.",
        {
            "type": "object",
            "properties": {
                "project_name": {"type": "string", "default": "plate_demo"},
                "length_m": {"type": "number", "default": 0.12},
                "width_m": {"type": "number", "default": 0.06},
                "thickness_m": {"type": "number", "default": 0.0015},
                "mesh_size_m": {"type": "number", "default": 0.01},
                "material_name": {"type": "string", "default": "mild_steel"},
                "if_exists": {
                    "type": "string",
                    "enum": ["error", "overwrite", "archive_then_write", "versioned"],
                    "default": "error",
                },
            },
            "additionalProperties": False,
        },
        tool_create_plate_demo,
    ),
    "generate_scene_from_prompt": (
        "Resolve a natural-language engineering scene prompt into a supported controlled scene spec, generate model.k, and optionally run LS-PrePost validation/previews.",
        {
            "type": "object",
            "properties": {
                "project_name": {"type": "string", "default": "scene_from_prompt"},
                "prompt": {"type": "string"},
                "scene_id": {
                    "type": "string",
                    "enum": SUPPORTED_SCENE_TEMPLATES,
                    "description": "Optional controlled scene template id. When provided, this overrides prompt classification.",
                },
                "parameters": {
                    "type": "object",
                    "properties": {
                        "rebar_length_m": {"type": "number"},
                        "rebar_radius_m": {"type": "number"},
                        "rebar_diameter_m": {"type": "number"},
                        "drop_height_m": {"type": "number"},
                        "rod_length_m": {"type": "number"},
                        "rod_radius_m": {"type": "number"},
                        "rod_diameter_m": {"type": "number"},
                        "impact_velocity_m_per_s": {"type": "number"},
                        "plate_length_m": {"type": "number"},
                        "plate_width_m": {"type": "number"},
                        "plate_thickness_m": {"type": "number"},
                        "cube_length_m": {"type": "number"},
                        "cube_width_m": {"type": "number"},
                        "cube_height_m": {"type": "number"},
                        "cube_size_m": {"type": "number"},
                        "corner_force_n": {"type": "number"},
                        "pressure_pa": {"type": "number"},
                        "material_name": {"type": "string"},
                    },
                    "additionalProperties": False,
                },
                "allow_defaults": {
                    "type": "boolean",
                    "default": False,
                    "description": "If false, missing key physical parameters return needs_confirmation instead of generating a model.",
                },
                "dry_run": {
                    "type": "boolean",
                    "default": False,
                    "description": "Resolve the prompt and return the controlled scene spec without writing project files.",
                },
                "run_lsprepost_validation": {
                    "type": "boolean",
                    "default": False,
                    "description": "Run validate_lsprepost_import after model generation.",
                },
                "export_previews": {
                    "type": "boolean",
                    "default": False,
                    "description": "Export iso/top/front/side preview images after model generation.",
                },
                "export_preview_gif": {
                    "type": "boolean",
                    "default": False,
                    "description": "Export iso/top/front PNG frames and combine them into preview_summary.gif after model generation.",
                },
                "timeout_s": {
                    "type": "number",
                    "default": 45,
                    "description": "Per LS-PrePost automation timeout when validation or preview export is enabled.",
                },
                "if_exists": {
                    "type": "string",
                    "enum": ["error", "overwrite", "archive_then_write", "versioned"],
                    "default": "error",
                },
            },
            "required": ["prompt"],
            "additionalProperties": False,
        },
        tool_generate_scene_from_prompt,
    ),
    "list_materials": (
        "List built-in SI material library entries.",
        {"type": "object", "properties": {}, "additionalProperties": False},
        tool_list_materials,
    ),
    "get_material": (
        "Return one built-in SI material library entry by material_id.",
        {
            "type": "object",
            "properties": {
                "material_id": {"type": "string"},
                "name": {"type": "string"},
            },
            "additionalProperties": False,
        },
        tool_get_material,
    ),
    "validate_model": (
        "Validate a generated or imported project.",
        {"type": "object", "properties": {"project_name": {"type": "string", "default": "plate_demo"}}, "additionalProperties": False},
        tool_validate_model,
    ),
    "model_summary": (
        "Return a concise natural-language summary and structured summary for a project.",
        {"type": "object", "properties": {"project_name": {"type": "string", "default": "generic_plate_demo"}}, "additionalProperties": False},
        tool_model_summary,
    ),
    "list_projects": (
        "List generated, legacy, and archived model projects.",
        {"type": "object", "properties": {"include_archived": {"type": "boolean", "default": True}}, "additionalProperties": False},
        tool_list_projects,
    ),
    "read_project": (
        "Read model.json, checks.json, paths, and summary for a project.",
        {"type": "object", "properties": {"project_name": {"type": "string", "default": "generic_plate_demo"}}, "additionalProperties": False},
        tool_read_project,
    ),
    "archive_project": (
        "Archive an active workspace project. confirm_project_name must exactly match project_name.",
        {
            "type": "object",
            "properties": {
                "project_name": {"type": "string"},
                "confirm_project_name": {"type": "string"},
                "reason": {"type": "string", "default": ""},
            },
            "required": ["project_name", "confirm_project_name"],
            "additionalProperties": False,
        },
        tool_archive_project,
    ),
    "import_keyword": (
        "Import an existing LS-DYNA keyword file into a workspace project and parse basic metadata.",
        {
            "type": "object",
            "properties": {
                "project_name": {"type": "string", "default": "imported_keyword"},
                "keyword_path": {"type": "string"},
                "allow_external": {"type": "boolean", "default": False},
                "max_bytes": {"type": "integer", "default": 10485760},
                "if_exists": {
                    "type": "string",
                    "enum": ["error", "overwrite", "archive_then_write", "versioned"],
                    "default": "error",
                },
            },
            "required": ["keyword_path"],
            "additionalProperties": False,
        },
        tool_import_keyword,
    ),
    "open_in_lsprepost": (
        "Open a generated model.k in LS-PrePost after validating GUI-preview readiness.",
        {
            "type": "object",
            "properties": {
                "project_name": {"type": "string", "default": "plate_demo"},
                "force": {
                    "type": "boolean",
                    "default": False,
                    "description": "Bypass readiness gate; still requires model.k and LS-PrePost executable.",
                },
                "timeout_s": {
                    "type": "number",
                    "default": 0,
                    "description": "Optional wait timeout; 0 starts LS-PrePost and returns after launch.",
                },
            },
            "additionalProperties": False,
        },
        tool_open_in_lsprepost,
    ),
    "export_preview_image": (
        "Open a generated model.k with a server-approved LS-PrePost cfile and export a PNG preview artifact.",
        {
            "type": "object",
            "properties": {
                "project_name": {"type": "string", "default": "plate_demo"},
                "output_filename": {"type": "string", "default": "preview.png"},
                "view": {
                    "type": "string",
                    "enum": ["current", "iso", "top", "front", "side"],
                    "default": "current",
                    "description": "Preview view command. current preserves LS-PrePost default view; other values request a controlled camera orientation.",
                },
                "display_mode": {
                    "type": "string",
                    "enum": ["geometry", "boundary_conditions", "loads_constraints", "sets", "validation"],
                    "default": "geometry",
                    "description": "Controlled LS-PrePost display overlays for preview images.",
                },
                "auto_fit": {
                    "type": "boolean",
                    "default": True,
                    "description": "Run LS-PrePost ac before exporting the PNG.",
                },
                "timeout_s": {
                    "type": "number",
                    "default": 45,
                    "description": "Wait timeout for the LS-PrePost preview export cfile.",
                },
                "if_exists": {
                    "type": "string",
                    "enum": ["error", "overwrite", "versioned"],
                    "default": "overwrite",
                },
            },
            "additionalProperties": False,
        },
        tool_export_preview_image,
    ),
    "export_preview_images": (
        "Export multiple controlled PNG preview views with server-approved LS-PrePost cfiles.",
        {
            "type": "object",
            "properties": {
                "project_name": {"type": "string", "default": "plate_demo"},
                "views": {
                    "type": "array",
                    "items": {"type": "string", "enum": ["current", "iso", "top", "front", "side"]},
                    "default": ["iso", "top", "front", "side"],
                    "description": "Controlled preview views to export. Duplicate views are rejected.",
                },
                "output_prefix": {
                    "type": "string",
                    "default": "preview",
                    "description": "Simple artifact filename prefix. Outputs are named <prefix>_<view>.png.",
                },
                "display_mode": {
                    "type": "string",
                    "enum": ["geometry", "boundary_conditions", "loads_constraints", "sets", "validation"],
                    "default": "geometry",
                    "description": "Controlled LS-PrePost display overlays for preview images.",
                },
                "auto_fit": {
                    "type": "boolean",
                    "default": True,
                    "description": "Run LS-PrePost ac before exporting each PNG.",
                },
                "timeout_s": {
                    "type": "number",
                    "default": 45,
                    "description": "Per-view wait timeout for each LS-PrePost preview export cfile.",
                },
                "if_exists": {
                    "type": "string",
                    "enum": ["error", "overwrite", "versioned"],
                    "default": "overwrite",
                },
            },
            "additionalProperties": False,
        },
        tool_export_preview_images,
    ),
    "export_preview_gif": (
        "Export controlled preview PNG frames and combine them into a GIF preview summary.",
        {
            "type": "object",
            "properties": {
                "project_name": {"type": "string", "default": "plate_demo"},
                "views": {
                    "type": "array",
                    "items": {"type": "string", "enum": ["current", "iso", "top", "front", "side"]},
                    "default": ["iso", "top", "front"],
                    "description": "Controlled preview views to export and combine as GIF frames.",
                },
                "output_filename": {"type": "string", "default": "preview_summary.gif"},
                "output_prefix": {
                    "type": "string",
                    "default": "preview",
                    "description": "Simple artifact filename prefix for PNG frames. Frames are named <prefix>_<view>.png.",
                },
                "duration_ms": {
                    "type": "integer",
                    "default": 900,
                    "description": "Frame duration in milliseconds; must be greater than 0 and at most 10000.",
                },
                "display_mode": {
                    "type": "string",
                    "enum": ["geometry", "boundary_conditions", "loads_constraints", "sets", "validation"],
                    "default": "geometry",
                    "description": "Controlled LS-PrePost display overlays for preview frames.",
                },
                "auto_fit": {
                    "type": "boolean",
                    "default": True,
                    "description": "Run LS-PrePost ac before exporting each PNG frame.",
                },
                "timeout_s": {
                    "type": "number",
                    "default": 45,
                    "description": "Per-frame wait timeout for each LS-PrePost preview export cfile.",
                },
                "if_exists": {
                    "type": "string",
                    "enum": ["error", "overwrite", "versioned"],
                    "default": "overwrite",
                },
            },
            "additionalProperties": False,
        },
        tool_export_preview_gif,
    ),
    "validate_lsprepost_import": (
        "Open model.k in LS-PrePost with a server-approved cfile, save keyword reader messages, export a PNG, and return import validation status.",
        {
            "type": "object",
            "properties": {
                "project_name": {"type": "string", "default": "plate_demo"},
                "output_filename": {"type": "string", "default": "import_validation_iso.png"},
                "view": {
                    "type": "string",
                    "enum": ["current", "iso", "top", "front", "side"],
                    "default": "iso",
                },
                "display_mode": {
                    "type": "string",
                    "enum": ["geometry", "boundary_conditions", "loads_constraints", "sets", "validation"],
                    "default": "validation",
                    "description": "Controlled overlays used for the validation screenshot.",
                },
                "auto_fit": {"type": "boolean", "default": True},
                "timeout_s": {
                    "type": "number",
                    "default": 45,
                    "description": "Wait timeout for the LS-PrePost import validation cfile.",
                },
                "if_exists": {
                    "type": "string",
                    "enum": ["error", "overwrite", "versioned"],
                    "default": "overwrite",
                },
            },
            "additionalProperties": False,
        },
        tool_validate_lsprepost_import,
    ),
    "run_cfile": (
        "Run a manifest-verified server-generated project cfile through LS-PrePost.",
        {
            "type": "object",
            "properties": {
                "project_name": {"type": "string", "default": "plate_demo"},
                "cfile_filename": {"type": "string", "default": "open_model.cfile"},
                "timeout_s": {
                    "type": "number",
                    "default": 45,
                    "description": "Wait timeout for the LS-PrePost cfile; timeout_s must be greater than 0 and the tool returns ok only after successful completion.",
                },
                "allow_multiple": {"type": "boolean", "default": False},
                "manual_ack": {"type": "string", "default": ""},
            },
            "additionalProperties": False,
        },
        tool_run_cfile,
    ),
}


def tool_list() -> JSONDict:
    return {
        "tools": [
            {"name": name, "description": description, "inputSchema": schema}
            for name, (description, schema, _) in TOOLS.items()
        ]
    }
