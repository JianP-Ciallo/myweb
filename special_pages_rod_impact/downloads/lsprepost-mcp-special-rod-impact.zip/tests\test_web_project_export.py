from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from lsprepost_mcp.web.project_export import export_project_copy


class WebProjectExportTests(unittest.TestCase):
    def test_export_project_copy_copies_core_project_files_to_user_directory(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            project = root / "workspace" / "projects" / "demo_project"
            project.mkdir(parents=True)
            (project / "model.k").write_text("*KEYWORD\n*END\n", encoding="utf-8")
            (project / "model.json").write_text('{"project":"demo"}\n', encoding="utf-8")
            (project / "checks.json").write_text('{"ok":true}\n', encoding="utf-8")
            (project / "ignored.tmp").write_text("ignore", encoding="utf-8")

            export_dir = root / "user_exports"
            result = export_project_copy(project, export_dir)

            copied_root = export_dir / "demo_project"
            self.assertEqual(result["project_export_dir"], str(copied_root))
            self.assertTrue((copied_root / "model.k").is_file())
            self.assertTrue((copied_root / "model.json").is_file())
            self.assertTrue((copied_root / "checks.json").is_file())
            self.assertFalse((copied_root / "ignored.tmp").exists())
            manifest = json.loads((copied_root / "export_manifest.json").read_text(encoding="utf-8"))
            self.assertEqual(manifest["source_project_dir"], str(project))
            self.assertEqual(manifest["files"], ["model.k", "model.json", "checks.json"])


if __name__ == "__main__":
    unittest.main()
