# lsprepost-mcp 后续改进意见

本文档用于记录 `lsprepost-mcp` 后续开发方向。当前项目已经完成最小闭环：AI IDE 通过 MCP 调用 `generate_model`，生成结构化 `model.json`、LS-DYNA `model.k`、校验报告 `checks.json`，并可打开到 LS-PrePost。

后续建议围绕“建模能力扩展、物理信息可靠性、LS-PrePost 自动化、工程可用性、多 IDE 分发体验”逐步推进。

## 第一阶段：完善当前最小闭环

优先目标是让当前 `shell_plate` 模型更稳、更容易被研究员使用。

当前状态：已完成。

- 已增加 `docs/GENERATE_MODEL_SCHEMA.zh-CN.md`，明确 `generate_model` 每个字段含义、单位、默认值和限制。
- 已在 `checks.json` 中加入更详细的结构化校验项，包括节点数、单元数、part 数、材料数、截面数、约束数和 node set 数。
- 已增加 `model_summary` 工具，用自然语言返回模型摘要，方便 AI IDE 向用户解释当前模型。
- 已增加 `list_projects` 工具，列出已经生成过的模型项目。
- 已增加 `read_project` 工具，读取某个项目的 `model.json`、`checks.json` 和主要路径。
- 已增加 `archive_project` 工具，要求 `confirm_project_name` 与 `project_name` 完全一致后才归档。
- 已将新的运行时生成模型迁移到 `workspace/projects`，旧 `projects` 目录保留为 legacy 兼容读取位置。

## 第二阶段：扩展基础几何类型

当前只支持矩形壳单元板。下一步建议增加几个常见工程基础模型。

- `solid_block`：实体块，输出 `*ELEMENT_SOLID`。
- `shell_box`：壳单元盒体或开口盒。
- `cylinder_shell`：圆柱壳。
- `cylinder_solid`：实体圆柱。
- `beam_bar`：梁单元或杆单元。
- `import_keyword`：读取已有 `model.k`，提取基本 part/material/section 信息。

建议每种模型都遵循同一结构：

```json
{
  "project_name": "demo",
  "model_type": "solid_block",
  "unit_system": "SI_m_s_kg_N_Pa",
  "geometry": {},
  "mesh": {},
  "material": {},
  "boundary_conditions": [],
  "loads": []
}
```

当前状态：已完成基础版本。

- 已实现 `solid_block`。
- 已实现 `shell_box`。
- 已实现 `cylinder_shell`。
- 已实现 `import_keyword`。
- 已实现 `cylinder_solid`，当前采用规则六面体体素化近似，适合基础实体圆柱预览和 keyword 闭环测试。
- 已实现 `beam_bar`，当前采用细长六面体实体杆近似，不是 `*ELEMENT_BEAM` 梁单元公式。
- `import_keyword` 已从基础数量统计扩展到 part/section/material 引用检查；仍不是完整 LS-DYNA keyword 语义解析器。
- 新增模型统一使用国际单位制 `SI_m_s_kg_N_Pa`。

## 第三阶段：材料库和单位制

物理信息可靠性是这个 MCP 的核心价值之一。材料参数和单位制不能依赖 AI 自由发挥。

- 增加材料库目录，例如 `materials/steel.json`、`materials/aluminum.json`、`materials/rubber.json`。
- 材料库字段应包含名称、来源、单位制、密度、弹性模量、泊松比、屈服强度等。
- 支持通过 `material.name` 引用材料库，而不是每次手写全部参数。
- 对未知材料要求 AI IDE 向用户确认，不直接编造。
- 增加 `list_materials` 工具。
- 增加 `get_material` 工具。
- 增加单位制检查，默认使用国际单位制 `SI_m_s_kg_N_Pa`，避免与旧 mm/MPa 输入混用。
- 在 `model.json` 中记录材料来源和版本。

当前状态：已完成基础版本。

- 已增加 `materials/` 材料库目录。
- 已增加 `mild_steel`、`aluminum_6061_t6`、`rubber_generic` 三个内置材料条目。
- 材料库字段包含名称、来源、单位制、密度、弹性模量、泊松比、屈服强度、版本和复核标记。
- `generate_model` 已支持通过 `material.name` 引用材料库。
- 未知材料默认拒绝；只有显式 `confirmed_by_user: true` 且提供完整参数和 `source` 时才允许作为用户确认材料。
- 已增加 `list_materials` 和 `get_material` 工具。
- 已增加材料单位制检查，材料单位必须为 `SI_m_s_kg_N_Pa`。
- `model.json` 会记录材料来源、版本、来源类型和是否需要项目级复核。
- `checks.json` 会对材料来源、版本、单位制、来源类型和复核需求进行检查。

当前保留限制：

- 内置材料参数是名义工程值，不能作为生产仿真的认证材料卡。
- 还没有接入团队正式材料数据库或外部标准库。
- 仍只支持 `*MAT_ELASTIC`，未进入塑性、超弹性、失效等材料模型。

## 第四阶段：载荷、约束和接触前置校验

当前只支持 `x_min` 固定。后续应逐步支持更常见的工况定义。

- 固定边界：`fixed_edge`、`fixed_node_set`、`fixed_part`。
- 位移边界：`prescribed_displacement`。
- 速度边界：`prescribed_velocity`。
- 集中力：`nodal_force`。
- 压力：`pressure_on_segment_set`。
- 重力：`gravity`。
- 初速度：`initial_velocity`。
- 接触：`automatic_surface_to_surface`、`automatic_single_surface` 暂不开放生成，仅保留为后续受控能力目标。

建议不要一开始支持任意卡片，而是维护一个受控白名单。每一种载荷和接触都应该有：

- 结构化输入 schema
- 目标集合定义
- 单位检查
- 必要参数检查
- keyword 生成器
- 校验项

当前状态：已完成第四阶段受控基础版本。准确边界是：载荷与约束生成能力已开放；接触只完成风险识别、前置校验设计和未受控接触卡阻断策略。

- 已扩展 `fixed_edge`，支持 `x_min`、`x_max`、`y_min`、`y_max`、`z_min`、`z_max`。
- 已实现 `prescribed_displacement`，输出 `*BOUNDARY_PRESCRIBED_MOTION_SET` 和 `*DEFINE_CURVE`。
- 已实现 `prescribed_velocity`，输出 `*BOUNDARY_PRESCRIBED_MOTION_SET`，其中 `vad=0` 表示速度边界。
- 已实现 `nodal_force`，输出 `*LOAD_NODE_SET` 和 `*DEFINE_CURVE`。
- 已实现 `gravity`，输出 `*LOAD_BODY_X/Y/Z` 和 `*DEFINE_CURVE`。
- 已实现 `pressure_on_segment_set`，输出 `*SET_SEGMENT`、`*LOAD_SEGMENT_SET` 和 `*DEFINE_CURVE`。
- 已实现 `initial_velocity`，输出 `*INITIAL_VELOCITY_NODE`。
- 已实现三种曲线策略：`constant`、`ramp`、`table`；旧写法 `value + end_time_s` 仍按线性 ramp 处理。
- 已引入命名集合策略：`node_set`、`part_set`、`segment_set`，并允许载荷/约束通过 `target` 引用。
- 已在 `checks.json` 中增加载荷/约束数量和必要 keyword 卡片检查。
- 已增加第四阶段 smoke test：`scripts/smoke_test_fourth_phase.ps1`。
- 已完成 LS-PrePost GUI 导入截图验证：`phase4_plate_load_demo/model.k` 可被 LS-PrePost 2025 R1 识别，界面树中可见 `Prescribed_Motion`、`Spc`、`Curve`、`Load Body Z` 和 `Load Node Set`。
- 已完成 LS-PrePost GUI 导入截图验证：`phase4_remaining_load_demo/model.k` 可被 LS-PrePost 2025 R1 识别，界面树中可见 `Prescribed_Motion`、`Initial Velocity`、`Load Segment`、`Node Set`、`Part Set`、`Segment Set` 和两条 `Curve`。
- 已完成 UUC 类单实体单元 LS-PrePost GUI 导入截图验证：`uuc_like_single_element_demo/model.k` 可被 LS-PrePost 2025 R1 识别，界面树中可见单实体 Part、`Prescribed_Motion`、多个节点级 `Spc`、两条 `Curve`、3 个 `Load Segment` 和对应 `Node Set`。

当前保留限制：

- `node_set` 已支持边界选择器和显式 `node_ids`；显式节点 ID 主要用于单元级测试和已知拓扑模型，复杂模型仍建议通过命名选择器生成。
- `segment_set` 当前通过外表面/面选择器生成，压力方向和壳单元法向仍需在 LS-PrePost 中复核。
- `part_set` 当前只支持生成模型内的单一 part id `1`，主要为后续接触准备。
- 接触仍未开放。进入接触前必须先增强 part/set/segment 引用校验、段面完整性校验和接触 pair 合法性检查。

## 第五阶段：更严格的模型校验

当前校验只覆盖必要卡片和少量物理参数。后续应逐步接近工程使用。

建议增加：

- 节点 ID、单元 ID、part ID、material ID、section ID 冲突检查。
- 单元面积或体积为零检查。
- 壳单元法向一致性检查。
- 壳厚是否大于网格尺寸的合理比例检查。
- 材料密度、弹性模量、泊松比范围检查。
- 约束是否引用存在的 node set 或 part set。
- 载荷是否引用存在的 set。
- 接触是否引用存在的 part 或 segment set。
- 是否存在未赋材料的 part。
- 是否存在未赋 section 的 part。
- 是否存在孤立节点或孤立单元。
- 模型总质量估算。
- 建议稳定时间步估算。

校验报告建议分级：

```text
error: 阻止生成或阻止打开
warning: 允许生成，但提示工程风险
info: 模型摘要或建议
```

当前状态：已完成第一批静态 keyword 质量校验，并已修复进入第六阶段前的 P0/P1 风险项。

- 已新增 `lsprepost_mcp/keyword_checks.py`，对生成的 `model.k` 做结构化解析。
- 已新增 `quality.id.*`：检查 node、element、part、material、section ID 重复。
- 已新增 `quality.ref.*`：检查 element、part、node set、segment set、直接 `*LOAD_SEGMENT` 和 `*LOAD_SEGMENT_SET` 的引用完整性。
- 已新增 `quality.geometry.*`：检查 shell 面积、shell warpage、shell 长宽比、solid 8 点 Gauss Jacobian、solid 长宽比、`shell_plate` 法向一致性和载荷 segment 局部方向。
- 已新增 `quality.keyword.*`：检查 keyword deck 边界、卡片左对齐、long format ID 风险、include 路径和 parameter 引用。
- 已新增 `quality.unsupported.contact_cards`：识别接触卡并阻断求解草稿状态，避免把未受控接触误认为已支持。
- 已新增 `quality.topology.*`：检查孤立节点、孤立单元，并检查载荷 segment 是否真实匹配 shell 单元面或 solid 外表面。
- 已新增 `quality.shell.thickness_mesh_ratio`：检查壳厚与网格尺寸比例。
- 已新增 `quality.material.*`：检查材料密度、弹性模量和泊松比的宽泛工程范围。
- 已新增 `quality.estimate.mass`：估算模型总质量。
- 已新增 `quality.estimate.stable_timestep`：对弹性材料或提供波速/剪切模量/体积模量的高级材料估算显式稳定时间步。
- 已新增 `checks.readiness`：区分 GUI 预览、求解草稿、正式复核三种状态。
- 已新增 `docs/VALIDATION_PHASE5.zh-CN.md` 说明第五阶段校验项和限制。
- 已新增单元测试 `tests/test_keyword_checks.py`，覆盖质量估算、缺失节点引用和重复 ID 检测。

当前保留限制：
- solid 单元体积已改为 8 点 Gauss Jacobian 检查，可发现反向和严重畸变风险；仍不能替代 LS-DYNA 求解器完整网格质量检查。
- 全局壳法向一致性目前只对 `shell_plate` 启用，圆柱壳和壳盒主要依赖局部 segment 方向检查。
- import keyword 已进入基础质量校验，并增加 include、parameter、long format 的基础检查；但完整 LS-DYNA keyword 语义和复杂材料多行卡仍未完全解析。
- 接触卡会被识别和阻断求解草稿状态，但接触生成能力仍未开放。

## 第 5.1 阶段：组件库与场景装配层

第五阶段已经具备较严格的 keyword 质量校验。进入第六阶段自动化前，应先把“单一模型生成器”升级为“组件库 + 场景装配器 + 受控物理模板”，避免每个新工况都重新编写一套专用生成代码。

核心目标：

- 让 AI 只负责把自然语言需求转换为结构化 `scene spec`，不直接生成任意 LS-DYNA keyword。
- 让 MCP 只能调用白名单组件、白名单材料、白名单载荷/约束/接触模板生成 `model.k`。
- 复用已有几何生成能力，把杆、板、壳、块、球等组件放入统一空间坐标系后装配成工况。
- 每个工况仍生成新的 `model.k`，但不为每个工况新增一套专用模型生成器。

建议架构：

```text
自然语言需求
  -> AI 解析为 scene spec
  -> MCP 校验 scene spec
  -> 组件库生成几何和物理组件
  -> 装配器统一坐标、编号、part/set 关系
  -> 受控模板生成 contact/boundary/load/database
  -> 输出 model.k、model.json、checks.json
```

组件库首批目标：

- `solid_cylinder`：实体圆柱，用于钢筋、冲击杆、落锤杆等。
- `shell_plate`：壳单元钢板。
- `ellipsoid_shell`：椭球帽壳，用于简化头盔。
- `solid_block`：实体块。
- `solid_sphere`：实体球。
- `ground_plane`：地面或刚性支撑定义。

装配层必须提供：

- 全局 node/element/part/section/material/set ID 分配器。
- 平移、旋转、缩放等基础 transform。
- 局部组件坐标到全局空间坐标的转换。
- part、node set、segment set、contact pair 的受控引用。
- 组件 metadata，用于 `checks.json` 和 LS-PrePost GUI 验证。

`scene spec` 约束：

- 只允许引用白名单组件名。
- 所有数值必须有限，单位必须明确，默认使用 `SI_m_s_kg_N_Pa`。
- 材料只能引用材料库或用户显式确认的完整材料参数。
- 接触、约束、载荷和数据库输出只能引用受控模板。
- 禁止用户原始 keyword 直接拼接进生成结果。
- unknown properties 默认拒绝，避免 AI 传入未定义语义。

接触能力阶段边界：

- 早期规划中“第六阶段开放接触”的表述应修正为：第 5.1 阶段开放最小受控接触生成，第六阶段使用并验证该能力。
- 原因是冲击工况没有接触就不具备基本物理语义；钢筋和头盔如果只是两个独立 part，LS-DYNA 不会自动知道二者需要碰撞传力。
- 第 5.1 阶段只开放最小白名单能力：`automatic_surface_to_surface` 和 `automatic_nodes_to_surface`，优先支持 part-to-part 与 node-to-surface 接触。
- 最小接触输入只允许结构化字段，例如 `type`、`slave`、`master`、`friction`，不能接受用户原始 `*CONTACT` keyword。
- 第六阶段仍可继续扩展接触自动化和 GUI 验证，但不应把“第一个可用接触生成器”推迟到第六阶段。

第一条闭环建议：

- 用 `solid_cylinder + shell_plate` 生成“杆撞钢板”模型。
- 验证组件复用、空间装配、ID 分配、材料赋值、固定边界、初速度或重力、基础接触和 `checks.json`。
- 该闭环通过后，再把 `shell_plate` 替换为 `ellipsoid_shell`，形成第六阶段的 `rebar_drop_on_helmet` 验证目标。

阶段验收标准：

- 能通过结构化 `scene spec` 组合至少两个组件生成单个 `model.k`。
- 同一组件能在不同场景中复用，不需要新增专用模型生成器。
- `checks.json` 能识别多 part、多 section、多 material、set 引用和受控接触。
- LS-PrePost 能打开由装配层生成的多组件模型。
- 第六阶段的 `rebar_drop_on_helmet` 必须基于该组件装配能力实现，而不是作为一次性专用模型。

当前状态：已完成 5.1 代码闭环，可进入第六阶段 LS-PrePost 自动化验证。

- 已新增 `assembly_scene` 模型类型，用于组件化装配工况。
- 已新增首批白名单组件：`solid_cylinder`、`shell_plate` 和 `ellipsoid_shell`。
- 已支持组件级平移、中心定位、欧拉角旋转、简单轴向定位、组件级固定面和组件级初始速度。
- 已支持多 part、多 section、多 material 的统一 keyword 输出。
- 已支持最小受控面面接触：`automatic_surface_to_surface`。
- 已支持最小受控点/节点到面接触：`automatic_nodes_to_surface`。
- 已让 keyword 质量检查区分“受控 contact 卡”和“未受控 contact 卡”；受控接触不再被 `quality.unsupported.contact_cards` 阻断。
- 已补充单元测试，覆盖 schema、keyword 生成、项目落盘和受控接触校验。
- 已新增 `rebar_drop_on_helmet` 受控场景模板，生成 `solid_cylinder` 钢筋、`ellipsoid_shell` 椭球帽壳、重力、固定边界、面面接触和 `d3plot` 输出。
- 已生成 `workspace/projects/rebar_drop_on_helmet_demo/model.k`，静态检查 `checks.ok=true`，`checks.readiness.ok_for_solver_draft=true`。

## 第六阶段：LS-PrePost 自动化增强

当前主要通过 `k=model.k` 打开模型。后续可以进一步利用 LS-PrePost 命令文件和录制能力。

第六阶段验证目标新增：基于第 5.1 阶段组件装配能力生成 `rebar_drop_on_helmet` 初始工况模型。

目标场景：

- 生成一个椭球帽壳模型，作为固定在地面上的简化头盔。
- 生成一根实体钢筋，长度 `1.0 m`，保持竖直。
- 钢筋初始位置位于头盔上方 `10.0 m`。
- 钢筋初始速度为 `0`，通过 `*LOAD_BODY_Z` 施加重力，交由 LS-DYNA 计算自由下落和冲击过程。
- 生成钢筋与头盔之间的受控接触定义。
- 生成 `d3plot` 输出控制，便于 LS-PrePost 查看冲击过程。
- 当前目标只生成可交给 LS-DYNA 的初始 keyword 工况；不在 MCP 内自动判断贯穿、不自动求解、不自动做失效结论。

该验证目标进入第六阶段前置门槛：

- `model.k` 必须包含两个受控 part：椭球帽壳和实体钢筋。
- 椭球帽壳必须有 shell section、厚度、材料、边缘固定约束或等效地面固定约束。
- 钢筋必须有 solid section、材料、初始几何位置和自由下落重力载荷。
- 接触卡必须由第 5.1 阶段的受控模板生成，不能接受用户原始 contact keyword。
- `checks.json` 必须能识别该模型为求解草稿状态，并对 part/material/section/contact/load/database 进行基础检查。
- LS-PrePost GUI 验证需确认能打开模型，并能看到两个 part、接触、重力载荷、固定约束和 d3plot 输出设置。

- 已在进入第六阶段前为 `open_in_lsprepost` 增加 GUI 预览 readiness gate：默认只有 `checks.readiness.ok_for_gui_preview=true` 才允许启动 LS-PrePost；必要时可显式传入 `force=true` 覆盖。
- 第六阶段后续工具也必须消费 `checks.readiness`，不能绕过 `validate_model` 结果直接执行 GUI 自动化。
- 当前状态：第六阶段核心验收闭环已完成，已新增 `export_preview_image` 工具，自动用服务端模板生成 cfile、启动 LS-PrePost、导出 PNG 预览、保存 keyword reader XML、检查 keyword reader warnings/errors，并记录验证结果。
- 已新增 `run_cfile` 工具，但只允许运行 manifest/hash 校验通过的服务端生成 cfile；不接受用户原始命令文件内容。该工具为完成型语义，要求 `timeout_s > 0`，只有 LS-PrePost 进程返回码为 `0` 时才返回 `ok=true`。
- 已使用 `templates/cfile/open_keyword.cfile` 和 `templates/cfile/preview_image.cfile` 作为首批受控模板。
- `export_preview_image` 已支持受控视图参数：`current`、`iso`、`top`、`front`、`side`；真实 LS-PrePost integration 已验证多视图 PNG 可导出且图像 hash 不同。
- 已新增 `export_preview_images` 批量多视图工具，默认一次导出 `iso`、`top`、`front`、`side` 四张 PNG，并为每张图保存独立 keyword reader XML，避免多视图结果互相覆盖。
- 已新增 `export_preview_gif` 工具，默认导出 `iso`、`top`、`front` 三视图 PNG，并合成为 `preview_summary.gif`；GIF 会校验 `GIF87a/GIF89a` 文件头并写入验证记录。
- 已新增 `validate_lsprepost_import` 工具，正式执行“打开 `model.k` -> `save kwdmsg` -> 导出 PNG -> 校验 PNG 与 keyword reader XML -> 检查第六阶段必要 keyword 卡片”的导入后截图校验闭环。
- 已增强受控视图控制：`display_mode` 支持 `geometry`、`boundary_conditions`、`loads_constraints`、`sets`、`validation`，并支持 `auto_fit` 自动适配视野；网格线和 part 颜色当前使用 LS-PrePost 默认渲染，不开放未验证 raw UI 命令。
- 已将钢筋冲击头盔作为第六阶段验收案例：静态校验通过、keyword reader 无 warning/error、四视图 PNG 导出成功、导入验证 PNG 导出成功，并检查 part/contact/gravity/fixed constraint/d3plot 必要卡片存在。
- 2026-06-12 已在本机 `LSPP_INTEGRATION=1`、`LSPP_EXE=<LS_PREPOST_EXE>` 下跑通真实 LS-PrePost integration：5 tests OK，未跳过 GUI 测试。
- 后续可继续通过 LS-PrePost 录制更多常用操作，再扩展成参数化模板，例如更精确的 part ID、接触区域和边界条件标注显示。

注意：不建议暴露 `execute_raw_lsprepost_command` 这类工具。原始命令应由模板生成，避免 AI 任意执行危险操作。

## 第七阶段：AI IDE 使用体验

第七阶段目标是把“自然语言工况描述”收束成受控 `scene spec`，再复用前六阶段已经完成的组件库、材料库、接触模板、静态校验和 LS-PrePost 自动化验证。

关键边界：

- AI 或 prompt 解析器可以理解自然语言，但不能直接拼接 LS-DYNA keyword。
- MCP 只允许选择白名单场景模板、白名单组件、白名单材料、白名单载荷/约束/接触。
- 对缺少关键物理参数的 prompt，默认返回 `needs_confirmation=true`，不生成模型。
- 只有用户显式 `allow_defaults=true` 或通过 `parameters` 提供完整参数时，才使用默认值继续生成。

当前状态：第七阶段受控自然语言闭环已完成玩具级版本。

- 已新增 `lsprepost_mcp/scene_prompts.py`，作为自然语言 prompt 到受控场景 spec 的解析层。
- 已新增 `generate_scene_from_prompt` MCP 工具。
- 当前白名单场景包括：
  - `rebar_drop_on_helmet`：钢筋自由落体冲击固定头盔。
  - `rod_impact_plate`：实体圆柱杆以初速度撞击固定钢板。
  - `cube_top_corner_load`：立方体底面固定、顶面四角向下集中载荷。
  - `plate_pressure`：壳板固定边界、板面均布压力。
- 已支持从 prompt 或显式 `parameters` 抽取/覆盖钢筋-头盔场景参数：
  - `rebar_length_m`
  - `rebar_radius_m`
  - `rebar_diameter_m`
  - `drop_height_m`
  - `material_name`
- 已支持从 prompt 或显式 `parameters` 抽取/覆盖杆-板冲击场景参数：
  - `rod_length_m`
  - `rod_radius_m`
  - `rod_diameter_m`
  - `impact_velocity_m_per_s`
  - `plate_length_m`
  - `plate_width_m`
  - `plate_thickness_m`
  - `material_name`
- 已支持从 prompt 或显式 `parameters` 抽取/覆盖立方体四角载荷场景参数：
  - `cube_length_m`
  - `cube_width_m`
  - `cube_height_m`
  - `cube_size_m`
  - `corner_force_n`
  - `material_name`
- 已支持从 prompt 或显式 `parameters` 抽取/覆盖板压力场景参数：
  - `plate_length_m`
  - `plate_width_m`
  - `plate_thickness_m`
  - `pressure_pa`
  - `material_name`
- 已接入完整工具链：
  - 生成 `model.k`、`model.json`、`checks.json`
  - 可选运行 `validate_lsprepost_import`
  - 可选运行 `export_preview_images`
  - 可选运行 `export_preview_gif`，生成三视图 GIF 预览摘要
- 已新增 `dry_run=true`，可只返回解析后的 `resolved_spec`，用于生成前确认，不写入项目文件。
- 已新增 `risk_notes`，对冲击、接触、压力方向、边界条件等高风险设置给出复核提示。
- 已新增 `docs/PROMPTS.zh-CN.md`，记录推荐 prompt 写法、缺参追问规则、默认值规则和能力边界。
- 已补充单元测试和真实 LS-PrePost integration：自然语言钢筋-头盔 prompt 可生成模型、通过导入校验并导出四视图 PNG。

当前保留限制：

- 第七阶段只做受控模板解析，不做开放式任意建模。
- 自然语言解析规则是轻量规则系统，适合玩具级闭环和固定模板演示，不等同于完整 NLP 参数抽取器。
- 冲击、接触、压力和载荷方向仍需要用户在 LS-PrePost/LS-DYNA 中复核；MCP 不自动给出损伤、贯穿或失效结论。

## 第八阶段：分发和安装体验

当前可以压缩分发，但对非开发人员仍然有一定门槛。

建议增加：

- `setup.ps1`：交互式检查 Python、检查 LS-PrePost 路径、生成配置。
- `doctor.ps1`：诊断当前环境是否可用。
- `pack.ps1`：生成干净分发包，排除 `__pycache__`、临时文件和本机运行日志，并在压缩包内写入 `PACKAGE_MANIFEST.txt`。（已完成基础版）
- 每次优化后生成独立 zip，文件名必须包含阶段/优化标签和时间戳，例如 `lsprepost-mcp_phase6-preview-export_YYYYMMDDTHHMMSSZ.zip`，不覆盖旧分发包；出现问题时可停止当前 MCP，重新解压旧 zip 并按旧版本配置启动。
- `install_to_cursor.ps1`：可选，将配置复制到 Cursor 指定位置。
- `install_to_vscode.ps1`：可选，将配置复制到 `.vscode/mcp.json`。
- 发布压缩包时附带 `README.zh-CN.md`、`docs/AI_IDE_COMPAT.zh-CN.md` 和示例配置。

当前状态：已完成第一批分发安装闭环。

- 已新增 `scripts/doctor.ps1`，检查 Python、关键文件、MCP server 导入、cfile 模板、材料库，并可选严格检查 LS-PrePost 路径。
- 已新增 `scripts/setup.ps1`，按本机 LS-PrePost 路径生成 `generated_configs` 下的 AI IDE MCP 配置和本机 env 文件。
- 已新增 `scripts/install_to_cursor.ps1`，将 MCP 配置写入目标项目 `.cursor/mcp.json`，默认不覆盖已有配置。
- 已新增 `scripts/install_to_vscode.ps1`，将 MCP 配置写入目标项目 `.vscode/mcp.json`，默认不覆盖已有配置。
- 已新增 `docs/DISTRIBUTION.zh-CN.md`，说明其他机器上的解压、诊断、配置、smoke test 和旧版本回退流程。
- 已补充单元测试，覆盖 doctor JSON 输出、缺失 LS-PrePost 路径失败、非交互 setup 配置生成、Cursor/VS Code 项目级安装和覆盖保护。
- 继续沿用 `scripts/pack.ps1` 的分发包清理和本机绝对路径门禁。

建议分发包不包含：

- `__pycache__`
- `.git`
- `lspost.msg`
- `lspost.cfile`
- 本机绝对路径生成的临时配置

## 第九阶段：代码结构重构

随着功能增加，原先单文件 `server.py` 已完成第一轮拆分。后续如果继续扩展材料库、载荷和接触，应继续按职责细分。

推荐结构：

```text
lsprepost_mcp/
  server.py
  tools/
    generate_model.py
    validate_model.py
    open_in_lsprepost.py
  model/
    schema.py
    specs.py
    materials.py
  dyna/
    keyword_writer.py
    plate.py
    solid_block.py
    validators.py
  lspp/
    launcher.py
    cfile.py
  utils/
    paths.py
    jsonrpc.py
materials/
templates/
tests/
```

拆分原则：

- MCP 协议处理和工程建模逻辑分开。
- keyword 生成和校验逻辑分开。
- LS-PrePost 启动逻辑单独封装。
- schema 和材料库单独维护。

当前进展：

- 已完成第九阶段第一步低风险拆分：新增 `lsprepost_mcp/tool_helpers.py`，集中放置布尔参数校验、自动化超时校验、预览视图参数、PNG/GIF/XML 校验、LS-PrePost 验证记录等横切 helper。
- `lsprepost_mcp.tools` 仍保留原有导入兼容性，旧代码继续可以从 `tools.py` 引用 `bool_arg`、`automation_timeout`、`verify_png_artifact`、`record_lsprepost_verification` 等 helper。
- 已完成第九阶段第二步低风险拆分：新增 `lsprepost_mcp/tool_lsprepost.py`，集中放置 `open_in_lsprepost`、`export_preview_image(s)`、`export_preview_gif`、`validate_lsprepost_import`、`run_cfile` 等 LS-PrePost 自动化工具实现。
- `lsprepost_mcp.tools` 继续保留这些工具函数的旧导入路径，并保留 `launch_cfile`、`launch_keyword` 旧 patch 点，避免破坏现有测试、脚本和客户端扩展。
- 已完成第九阶段第三步低风险拆分：新增 `lsprepost_mcp/tool_project.py`、`lsprepost_mcp/tool_materials.py`、`lsprepost_mcp/tool_server.py`，分别承载项目管理/导入、材料查询和服务信息工具。
- `lsprepost_mcp.tools` 继续作为 MCP 工具注册表和兼容入口，业务实现逐步迁出，避免一次性改成包结构造成导入路径破坏。
- 已完成第九阶段第四步低风险拆分：新增 `lsprepost_mcp/tool_generation.py`，承载 `generate_model`、`create_plate_demo`、`generate_scene_from_prompt` 三类生成工具。
- 当前 `lsprepost_mcp/tools.py` 已基本收敛为工具注册表、schema 入口和旧导入兼容层，不再承载主要业务实现。
- 暂不把 `tools.py` 直接改成 `tools/` 包，避免破坏现有 MCP 客户端、测试和用户脚本依赖的模块路径。后续若继续拆分单个工具实现，应先建立兼容层，再分批迁移。

## 第十阶段：测试体系

当前已有 smoke test 和标准库 `unittest` 单元测试。后续应继续增加更系统的测试。

- 单元测试：测试 spec 解析、参数校验、网格数量、keyword 输出。
- 快照测试：对生成的 `model.k` 做稳定性比较。
- 错误输入测试：负厚度、非法泊松比、未知单位制、缺失边界条件。
- 工具协议测试：`initialize`、`tools/list`、`tools/call`、`ping`、batch。
- 跨路径测试：项目路径带空格、中文路径、不同盘符。
- LS-PrePost 启动测试：只在本机配置可用时运行。

当前状态：第十阶段默认可运行测试体系已完成。真实 LS-PrePost GUI 集成测试仍作为可选门禁保留。

- 已新增 `scripts/run_test_matrix.ps1`，提供 `default`、`critical`、`packaging`、`snapshots`、`errors`、`paths`、`gui`、`all` 测试分组。
- 已新增 `docs/TESTING_PHASE10.zh-CN.md`，说明每个测试分组的用途、运行方式和 GUI 集成测试边界。
- 已新增 `tests/test_phase10_test_matrix.py`，确保测试矩阵脚本可被分发包用户发现并列出可用分组。
- 已新增 `tests/test_keyword_snapshots.py` 和 `tests/snapshots/keyword_hashes.json`，对基础壳板、实体块和钢筋冲击头盔场景的 `model.k` 输出做 SHA256 快照测试。
- 测试矩阵已新增 `snapshots` 分组，用于单独运行 keyword 快照测试。
- 已新增 `tests/test_phase10_error_inputs.py` 和 `errors` 分组，覆盖非法数值、未知材料、错误自定义材料确认和非法接触类型。
- 已新增 `tests/test_phase10_paths.py` 和 `paths` 分组，覆盖脚本从带空格/中文当前目录调用时仍能定位项目。
- `critical` 分组已纳入生成来源校验、第九阶段兼容入口、错误输入、路径健壮性和打包边界测试。
- 默认测试仍不依赖真实 LS-PrePost GUI；真实 GUI integration 继续通过 `LSPP_INTEGRATION=1` 和 `LSPP_EXE` 显式启用。

建议新增：

```text
tests/
  test_generation.py
  test_schema.py
  test_import_keyword.py
  test_jsonrpc.py
  test_paths.py
```

## 优先级建议

短期优先做：

1. `setup.ps1` 和 `doctor.ps1`
2. 材料库最小版本
3. `solid_block` 模型
4. 更严格的错误输入测试
5. 分发包清理脚本 `pack.ps1`

中期优先做：

1. 载荷和速度边界
2. 接触定义
3. LS-PrePost 截图导出
4. 单元质量检查
5. 项目结构拆分

长期优先做：

1. 更完整的 LS-DYNA keyword 支持
2. 后处理曲线提取
3. 与求解器运行流程打通
4. 工程模板库
5. 团队内部材料库和建模规范集成

## 总体建议

这个 MCP 的价值不在于让 AI “随便操作 LS-PrePost”，而在于把自然语言需求收束成可审查的结构化模型，再由受控编译器生成有物理信息的 LS-DYNA keyword。

后续开发应始终坚持：

- 结构化输入优先
- 单位制明确
- 材料来源可追溯
- 校验报告必须生成
- 高风险工程参数必须确认
- 不执行 AI 直接给出的任意原始命令
