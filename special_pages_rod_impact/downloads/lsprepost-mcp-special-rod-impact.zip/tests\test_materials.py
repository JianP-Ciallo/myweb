from __future__ import annotations

import unittest

from lsprepost_mcp.materials import get_material, list_materials, resolve_material


class MaterialsTests(unittest.TestCase):
    def test_list_materials_has_expected_entries(self) -> None:
        material_ids = {item["id"] for item in list_materials()}
        self.assertIn("mild_steel", material_ids)
        self.assertIn("aluminum_6061_t6", material_ids)
        self.assertIn("rubber_generic", material_ids)

    def test_get_material_returns_source_and_version(self) -> None:
        material = get_material("mild_steel")
        self.assertEqual(material["unit_system"], "SI_m_s_kg_N_Pa")
        self.assertTrue(material["source"])
        self.assertTrue(material["version"])

    def test_resolve_material_rejects_unknown_name(self) -> None:
        with self.assertRaisesRegex(ValueError, "unknown material"):
            resolve_material({"name": "not_in_library"})

    def test_resolve_material_requires_literal_true_confirmation(self) -> None:
        base = {
            "name": "custom_elastic",
            "type": "elastic",
            "density_kg_per_m3": 7800,
            "youngs_pa": 200000000000,
            "poisson": 0.3,
            "source": "unit test",
        }
        for value in ["false", "true", 1]:
            with self.subTest(value=value):
                raw = dict(base)
                raw["confirmed_by_user"] = value
                with self.assertRaisesRegex(ValueError, "confirmed_by_user=true"):
                    resolve_material(raw)

        accepted = dict(base)
        accepted["confirmed_by_user"] = True
        self.assertEqual(resolve_material(accepted)["source_type"], "user_confirmed_custom")


if __name__ == "__main__":
    unittest.main()
