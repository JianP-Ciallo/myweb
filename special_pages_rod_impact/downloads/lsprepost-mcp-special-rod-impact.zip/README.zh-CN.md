# lsprepost-mcp

`lsprepost-mcp` 是一个本地 MCP Server，用于把 Codex、Cursor、Claude Desktop、Windsurf、VS Code、Visual Studio 等 AI IDE 连接到 LS-PrePost，并以受控方式生成 LS-DYNA keyword 模型。

典型流程是：

```text
用户在 AI IDE 中描述工况
  -> AI IDE 调用 lsprepost MCP 工具
  -> MCP Server 校验受控输入
  -> 生成 model.json / model.k / checks.json
  -> LS-PrePost 打开、校验并导出预览
```

这个项目的定位是玩具级到原型级的桥接工具：打通“AI IDE -> MCP -> LS-PrePost”的闭环。它不会开放任意 LS-PrePost 命令，也不会让 AI 直接拼接任意 LS-DYNA keyword。AI 可以理解需求，MCP 只执行白名单工具和受控模板。

## 适用场景

适合用它做：

- 在 AI IDE 中用自然语言生成简单 LS-DYNA keyword 模型。
- 让几何、材料、载荷、约束、接触和预览导出走受控工具。
- 从 AI IDE 中打开 LS-PrePost 查看生成模型。
- 导出 LS-PrePost PNG 预览图或多视图 GIF。
- 打包发给其他 Windows 机器使用，并保留旧 zip 版本用于回退。

## 环境要求

- Windows
- Python 3.10 或更高版本
- 本机已安装 LS-PrePost
- 支持 MCP 的 AI IDE 或 MCP Client
- 可选：Pillow。只有 `export_preview_gif` 需要 Pillow；核心模型生成、校验和 PNG 预览不依赖第三方 Python 包。

每台机器都要使用自己的 LS-PrePost 路径，例如：

```text
<LS_PREPOST_INSTALL_DIR>\lsprepost4.12.exe
```

不要复制开发机器上的绝对路径。不同机器必须设置自己的 `LSPP_EXE`。

## AI IDE 快速接入

最推荐的方式是：把整个项目文件夹交给 AI IDE，然后让 AI IDE 先读取根目录的：

```text
AI_IDE_START_HERE.zh-CN.md
```

这个文件已经写明：

- AI IDE 不得修改项目源代码。
- AI IDE 不得修改 `scripts\`、`templates\`、`materials\`、`tests\`。
- AI IDE 不得直接创建、编辑或覆盖 `.k` / `.key` / `.dyn` 文件。
- AI IDE 只允许运行诊断、生成 `generated_configs\`，以及在用户确认后写入 AI IDE 配置。
- 命令可以使用绝对路径运行，不要求用户手动进入项目目录。

你可以直接把下面这句话发给 AI IDE：

```text
请先阅读本项目根目录的 AI_IDE_START_HERE.zh-CN.md。严格按里面的只读使用流程操作：不要修改项目源代码，不要修改 scripts/templates/materials/tests；不得直接创建、编辑或覆盖任何 .k/.key/.dyn 文件；所有 keyword 文件都必须通过本项目生成流程产生。只允许运行诊断、生成配置、生成模型、校验模型和打开 LS-PrePost。我的 LS-PrePost 路径是：<LS_PREPOST_EXE>。
```

如果你希望手动运行，也可以使用下面的命令。

在项目根目录运行诊断：

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\doctor.ps1 -LsppExe "<LS_PREPOST_INSTALL_DIR>\lsprepost4.12.exe" -RequireLsPrePost
```

生成 AI IDE 配置：

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\setup.ps1 -LsppExe "<LS_PREPOST_INSTALL_DIR>\lsprepost4.12.exe"
```

生成结果位于：

```text
generated_configs\
```

常见输出文件：

- `codex.mcp.json`
- `cursor.mcp.json`
- `claude_desktop_config.fragment.json`
- `windsurf.mcp.json`
- `vscode.mcp.json`
- `visualstudio.mcp.json`

把对应配置复制到 AI IDE 中，然后重启或刷新 AI IDE 的 MCP 工具列表。

Windows 下推荐让 AI IDE 启动这个入口：

```text
cmd /c <PROJECT_DIR>\scripts\start_mcp_server.cmd
```

这个脚本会定位项目根目录并启动：

```text
lsprepost_mcp\server.py
```

## 本地 Web App 入口

第 11 阶段开始，本项目提供本地 Web App 入口。它默认只监听 `127.0.0.1`，用于普通用户选择受控场景、填写参数、生成模型、查看校验和预览。

启动：

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\start_web_app.ps1 -LsppExe $env:LSPP_EXE -OpenBrowser
```

如果没有 Node.js，Web App 会使用内置原生 HTML/CSS/JS 兜底页面。Node.js 只用于开发或重新构建 React/Vite 前端，不是最终用户运行依赖。

## MCP 配置示例

Codex、Cursor、Claude Desktop、Windsurf 常见格式：

```json
{
  "mcpServers": {
    "lsprepost": {
      "command": "cmd",
      "args": [
        "/c",
        "<PROJECT_DIR>\\scripts\\start_mcp_server.cmd"
      ],
      "env": {
        "LSPP_EXE": "<LS_PREPOST_INSTALL_DIR>\\lsprepost4.12.exe"
      }
    }
  }
}
```

VS Code、Visual Studio 常见格式：

```json
{
  "servers": {
    "lsprepost": {
      "type": "stdio",
      "command": "cmd",
      "args": [
        "/c",
        "<PROJECT_DIR>\\scripts\\start_mcp_server.cmd"
      ],
      "env": {
        "LSPP_EXE": "<LS_PREPOST_INSTALL_DIR>\\lsprepost4.12.exe"
      }
    }
  }
}
```

更多说明见：

```text
docs\AI_IDE_COMPAT.zh-CN.md
docs\DISTRIBUTION.zh-CN.md
docs\PROMPTS.zh-CN.md
```

## 在 AI IDE 中怎么提需求

建议把需求说清楚：几何、尺寸、材料、单位、约束、载荷、接触、是否需要 LS-PrePost 校验和预览。

## 统一初始启动词

别人拿到 zip 并用 AI IDE 打开项目文件夹后，建议统一使用下面这段话启动项目：

```text
请把当前文件夹当作一个现成的 LS-PrePost/LS-DYNA keyword 生成工具项目使用。先阅读 AI_IDE_START_HERE.zh-CN.md 和 README.zh-CN.md。不要修改项目源代码，不要修改 scripts/templates/materials/tests，不得直接创建、编辑或覆盖任何 .k/.key/.dyn 文件；所有 keyword 文件必须通过本项目生成流程产生。请先检查 Python 和 LS-PrePost 路径，然后告诉我当前环境是否可用。环境可用后，请先列出当前项目支持的可控场景建模选项，只给出模糊场景和需要我补充的数据项，不要直接编造参数。我的 LS-PrePost 路径是：<LS_PREPOST_EXE>。如果 LS-PrePost 因版本差异无法自动导出 PNG/GIF 预览，请明确告诉我需要自行打开 LS-PrePost 验证，不要把导图失败判断为模型生成失败。
```

如果用户还不知道 LS-PrePost 路径，可以把最后一句改成：

```text
我暂时不知道 LS-PrePost 路径，请先告诉我需要找到哪个 lsprepost*.exe 文件。
```

AI IDE 完成环境检查后，应先给出类似下面的选项：

```text
当前项目支持这些可控场景：

1. 钢筋自由落体冲击头盔
   可填写：钢筋长度/直径、下落高度、头盔尺寸/厚度、材料、是否导出预览。

2. 圆柱杆冲击钢板
   可填写：杆长度/直径、冲击速度、钢板长宽厚、材料、是否导出预览。

3. 立方体顶面四角受压
   可填写：立方体尺寸、四角向下载荷大小、材料、网格尺寸。

4. 壳板受均布压力
   可填写：板长宽厚、压力大小、固定边界、材料、网格尺寸。

请选择一个场景，并补充你已经确定的数据；不确定的数据可以先留空，我会继续追问。
```

示例 1：生成并打开简单钢板

```text
使用 lsprepost MCP 创建一个 0.12 x 0.06 x 0.0015 m 的低碳钢壳单元板。
单位使用 SI_m_s_kg_N_Pa，网格尺寸 0.01 m，固定 x_min 边界。
生成后校验模型，并在 LS-PrePost 中打开。
```

AI IDE 应调用的工具通常是：

```text
generate_model
validate_model
model_summary
open_in_lsprepost
```

示例 2：自然语言受控场景

```text
使用 lsprepost MCP 生成一个钢筋自由落体冲击头盔的场景：
一根 1 m 长的竖直钢筋位于固定椭球头盔壳上方 10 m。
使用重力、受控面面接触和 d3plot 输出。
完成 LS-PrePost 导入校验，并导出三视图 GIF 预览。
```

AI IDE 应调用的工具通常是：

```text
generate_scene_from_prompt
validate_lsprepost_import
export_preview_gif
read_project
```

示例 3：只导出预览

```text
对 rebar_drop_on_helmet_demo 项目导出 iso/top/front 三个视图，
并合成为一个 GIF 预览。
```

AI IDE 应调用的工具通常是：

```text
export_preview_images
export_preview_gif
```

## 主要 MCP 工具

- `server_info`：返回 Server 路径、项目目录、LS-PrePost 路径和运行信息。
- `generate_scene_from_prompt`：把受支持的自然语言工况解析为受控模型 spec，并可选执行校验和预览。
- `generate_model`：根据结构化 `spec` 生成 `model.json`、`model.k`、`open_model.cfile` 和 `checks.json`。
- `create_plate_demo`：早期兼容 demo，生成简单壳板模型。
- `validate_model`：重新校验项目并更新 `checks.json`。
- `model_summary`：返回模型摘要，方便 AI IDE 向用户解释模型。
- `read_project`：读取项目文件、路径和校验结果。
- `list_projects`：列出活动、旧版和归档项目。
- `archive_project`：通过精确项目名确认后归档项目。
- `import_keyword`：把已有 LS-DYNA keyword 文件导入为 workspace 项目。
- `list_materials` / `get_material`：查询内置 SI 材料库。
- `open_in_lsprepost`：通过 readiness 检查后在 LS-PrePost 中打开 `model.k`。
- `validate_lsprepost_import`：打开 `model.k`、保存 keyword reader 信息、导出 PNG 并检查导入状态。
- `export_preview_image`：导出单张受控 LS-PrePost PNG 预览。
- `export_preview_images`：导出多个受控视图。
- `export_preview_gif`：导出多视图并合成为 GIF 预览。
- `run_cfile`：只运行 manifest/hash 校验通过的服务端生成 cfile。

## 当前建模能力

当前项目只支持下面这些受控场景和模型能力。AI IDE 不应承诺开放式任意建模。

当前自然语言场景只支持：

- `rebar_drop_on_helmet`：钢筋自由落体冲击固定椭球头盔壳。
- `rod_impact_plate`：实体圆柱杆以初速度冲击固定钢板。
- `cube_top_corner_load`：立方体底面固定，顶面四角向下集中载荷。
- `plate_pressure`：壳板固定边界，板面均布压力。

当前结构化模型类型只支持：

- `shell_plate`
- `solid_block`
- `shell_box`
- `cylinder_shell`
- `cylinder_solid`
- `beam_bar`
- `single_solid_element_test`
- `assembly_scene`

其他当前受控能力包括：

- 单位制：`SI_m_s_kg_N_Pa`
- 内置材料：`mild_steel`、`aluminum_6061_t6`、`rubber_generic`
- 弹性材料：`*MAT_ELASTIC`
- 受控高级材料/用户自定义材料卡：用于明确确认的测试场景
- 载荷和约束：固定边界、规定运动、节点力、重力、压力、初速度
- 接触：受控面面接触和节点到面接触模板
- LS-PrePost 预览：PNG 和多视图 GIF
- 静态 keyword 检查和 readiness gate：写入 `checks.json`

## 本地 smoke test

不接入 AI IDE，直接生成一个简单模型：

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\smoke_test_generate_model.ps1
```

运行单元测试：

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\run_tests.ps1
```

手动通过 JSON-RPC 打开已有项目：

```powershell
$env:LSPP_EXE = "<LS_PREPOST_INSTALL_DIR>\lsprepost4.12.exe"
@'
{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"open_in_lsprepost","arguments":{"project_name":"generic_plate_demo"}}}
'@ | cmd /c .\scripts\start_mcp_server.cmd
```

`open_in_lsprepost` 默认只有在 `checks.readiness.ok_for_gui_preview=true` 时才会启动 LS-PrePost。除非你明确知道风险，否则不要随意使用 `force: true`。

## 确认 model.k 是否由本项目生成

为了避免 AI IDE 直接手写 `model.k`，本项目提供校验脚本：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File "<PROJECT_DIR>\scripts\verify_generated_k.ps1" -ProjectDir "<PROJECT_DIR>\workspace\projects\<PROJECT_NAME>"
```

这个脚本会检查：

- `model.k` 是否包含本项目生成签名。
- `model.json` 是否存在且不是 `imported_keyword`。
- `checks.json` 是否存在。
- 根据 `model.json` 重新调用本项目生成器生成 keyword，并与磁盘上的 `model.k` 做 SHA256 一致性比较。

只有返回：

```text
"ok": true
"classification": "generated_by_lsprepost_mcp"
```

才能认为该 `model.k` 是本项目生成流程产生的，而不是 AI 手写或外部复制的 keyword。

## 分发与回退

生成干净 zip：

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\pack.ps1 -BuildLabel "phase9-readme-ai-ide"
```

如果要生成“纯净分发包”，不包含历史 demo、生成型 examples、workspace、dist、generated_configs 等中间产物，使用：

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\pack.ps1 -BuildLabel "clean-release" -Pure
```

压缩包输出到：

```text
dist\
```

包名包含优化标签和时间戳，不覆盖旧版本。出现问题时，可以停止当前 MCP，解压旧 zip，并按旧版本 README 重新配置 `LSPP_EXE` 后启动。

其他机器使用流程：

1. 解压 zip 到新目录。
2. 安装 Python 3.10+ 和 LS-PrePost。
3. 用本机 LS-PrePost 路径运行 `doctor.ps1`。
4. 用 `setup.ps1` 生成 AI IDE 配置。
5. 把配置复制到 AI IDE。
6. 重启或刷新 AI IDE。
7. 先调用 `server_info`，或生成一个小 demo 验证闭环。

## 故障排查

如果 AI IDE 看不到 MCP 工具：

- 检查配置外层字段应使用 `mcpServers` 还是 `servers`。
- 检查 `scripts\start_mcp_server.cmd` 路径是否正确。
- 修改配置后重启 AI IDE。
- 在 PowerShell 中先运行 `doctor.ps1`。

如果 LS-PrePost 没有打开：

- 检查 `LSPP_EXE` 是否指向真实存在的 `lsprepost*.exe`。
- 调用 `server_info` 查看 `lspp_doctor`。
- 检查 `checks.readiness.ok_for_gui_preview`。

如果预览导出失败：

- 先调用 `validate_lsprepost_import`。
- 查看项目下的 `artifacts\lspp_verifications.json`。
- 查看项目 artifacts 目录下的 keyword reader XML。
- 如果是 GIF 导出失败，先运行 `doctor.ps1` 查看 `pillow_optional`；需要 GIF 功能时安装 Pillow。
- 不同 LS-PrePost 版本可能存在 cfile 命令或图片导出差异。如果模型已经生成且静态校验通过，但 PNG/GIF 导出失败，应提示用户自行打开 LS-PrePost 验证模型，而不是直接判定模型生成失败。

## 重要限制

- 这不是完整 LS-DYNA 前处理器。
- `checks.ok` 只表示本地静态校验通过，不等同于求解器认证结果。
- 内置材料参数是名义值，真实工程使用前必须复核。
- 自然语言能力是受控模板解析，不是开放式任意建模。
- `cylinder_solid` 和 `beam_bar` 当前是六面体近似。
- 当前 MCP 不负责运行 LS-DYNA 求解器，也不自动判断损伤、贯穿或失效结论。
