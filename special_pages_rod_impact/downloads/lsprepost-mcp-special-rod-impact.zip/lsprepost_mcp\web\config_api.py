from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from lsprepost_mcp.config import JSONDict, LOCAL_WEB_CONFIG_PATH, configured_lspp_exe, load_local_web_config
from lsprepost_mcp.lspp.launcher import doctor_lsprepost_exe
from lsprepost_mcp.web.http_utils import ApiError


def web_config_status() -> JSONDict:
    path, source, configured = configured_lspp_exe()
    export_dir = configured_export_dir()
    return {
        "configured": configured,
        "source": source,
        "lspp_exe": str(path),
        "config_path": str(LOCAL_WEB_CONFIG_PATH),
        "doctor": doctor_lsprepost_exe(path).to_json(),
        "export_dir_configured": export_dir is not None,
        "export_dir": str(export_dir) if export_dir is not None else "",
        "export_dir_exists": export_dir.is_dir() if export_dir is not None else False,
    }


def check_lsprepost_payload(payload: JSONDict) -> JSONDict:
    path = payload_lsprepost_path(payload)
    return {
        "lspp_exe": str(path),
        "doctor": doctor_lsprepost_exe(path).to_json(),
    }


def save_lsprepost_payload(payload: JSONDict) -> JSONDict:
    path = payload_lsprepost_path(payload)
    doctor = doctor_lsprepost_exe(path)
    if not doctor.ok:
        raise ApiError(400, "invalid_lsprepost_path", "LS-PrePost path must be an existing lsprepost*.exe file")

    write_web_config_patch({"lspp_exe": str(path)})
    os.environ["LSPP_EXE"] = str(path)
    status = web_config_status()
    status["source"] = "local_config"
    return status


def select_lsprepost_payload(_: JSONDict) -> JSONDict:
    selected = choose_lsprepost_exe()
    if selected is None:
        raise ApiError(400, "selection_cancelled", "LS-PrePost selection was cancelled")
    return save_lsprepost_payload({"lspp_exe": str(selected)})


def save_export_dir_payload(payload: JSONDict) -> JSONDict:
    path = payload_export_dir(payload)
    write_web_config_patch({"export_dir": str(path)})
    return web_config_status()


def select_export_dir_payload(_: JSONDict) -> JSONDict:
    selected = choose_export_dir()
    if selected is None:
        raise ApiError(400, "selection_cancelled", "export directory selection was cancelled")
    return save_export_dir_payload({"export_dir": str(selected)})


def configured_export_dir() -> Optional[Path]:
    raw = load_local_web_config().get("export_dir")
    if not isinstance(raw, str) or not raw.strip():
        return None
    return Path(raw.strip())


def write_web_config_patch(updates: JSONDict) -> None:
    LOCAL_WEB_CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    data = load_local_web_config()
    data.update(updates)
    data["saved_at_utc"] = datetime.now(timezone.utc).isoformat()
    temp_path = LOCAL_WEB_CONFIG_PATH.with_suffix(".tmp")
    temp_path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temp_path.replace(LOCAL_WEB_CONFIG_PATH)


def choose_lsprepost_exe() -> Optional[Path]:
    try:
        import tkinter as tk
        from tkinter import filedialog
    except Exception:
        return None

    root = tk.Tk()
    root.withdraw()
    try:
        root.attributes("-topmost", True)
        selected = filedialog.askopenfilename(
            title="选择 LS-PrePost 可执行文件",
            filetypes=[
                ("LS-PrePost executable", "lsprepost*.exe"),
                ("Windows executable", "*.exe"),
            ],
        )
    finally:
        root.destroy()
    return Path(selected) if selected else None


def choose_export_dir() -> Optional[Path]:
    try:
        import tkinter as tk
        from tkinter import filedialog
    except Exception:
        return None

    root = tk.Tk()
    root.withdraw()
    try:
        root.attributes("-topmost", True)
        selected = filedialog.askdirectory(title="选择模型保存文件夹")
    finally:
        root.destroy()
    return Path(selected) if selected else None


def payload_lsprepost_path(payload: JSONDict) -> Path:
    raw = payload.get("lspp_exe")
    if not isinstance(raw, str) or not raw.strip():
        raise ApiError(400, "invalid_lsprepost_path", "lspp_exe must be a non-empty string")
    return Path(raw.strip())


def payload_export_dir(payload: JSONDict) -> Path:
    raw = payload.get("export_dir")
    if not isinstance(raw, str) or not raw.strip():
        raise ApiError(400, "invalid_export_dir", "export_dir must be a non-empty string")
    path = Path(raw.strip())
    if path.exists() and not path.is_dir():
        raise ApiError(400, "invalid_export_dir", "export_dir must be a directory")
    if not path.exists():
        try:
            path.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            raise ApiError(400, "invalid_export_dir", "export_dir could not be created") from exc
    return path
