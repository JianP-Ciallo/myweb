from __future__ import annotations

import math

from .config import JSONDict
from .schema import ModelSpec


MAX_AXIS_CELLS = 500
MAX_RING_SEGMENTS = 720
MAX_NODES = 250_000
MAX_ELEMENTS = 200_000
MAX_KEYWORD_BYTES = 80 * 1024 * 1024


def preflight_model_spec(spec: ModelSpec) -> JSONDict:
    estimate = estimate_model_size(spec)
    problems: list[str] = []
    dimensions = estimate["dimensions"]
    for key, value in dimensions.items():
        limit = MAX_RING_SEGMENTS if key == "nt" else MAX_AXIS_CELLS
        if int(value) > limit:
            problems.append(f"{key}={value} exceeds limit {limit}")
    if int(estimate["node_count"]) > MAX_NODES:
        problems.append(f"node_count={estimate['node_count']} exceeds limit {MAX_NODES}")
    if int(estimate["element_count"]) > MAX_ELEMENTS:
        problems.append(f"element_count={estimate['element_count']} exceeds limit {MAX_ELEMENTS}")
    if int(estimate["keyword_bytes"]) > MAX_KEYWORD_BYTES:
        problems.append(f"keyword_bytes={estimate['keyword_bytes']} exceeds limit {MAX_KEYWORD_BYTES}")
    if problems:
        raise ValueError(
            "mesh preflight exceeded safe generation limits: "
            + "; ".join(problems)
            + f"; suggested mesh.size_m >= {estimate['suggested_mesh_size_m']:.9g}"
        )
    return estimate


def estimate_model_size(spec: ModelSpec) -> JSONDict:
    mesh_size = float(spec.mesh["size_m"])
    geometry = spec.geometry
    model_type = spec.model_type

    if model_type == "shell_plate":
        nx = grid_count(float(geometry["length_m"]), mesh_size)
        ny = grid_count(float(geometry["width_m"]), mesh_size)
        nodes = (nx + 1) * (ny + 1)
        elements = nx * ny
        dimensions = {"nx": nx, "ny": ny}
        dimensionality = 2
    elif model_type in {"solid_block", "beam_bar"}:
        nx = grid_count(float(geometry["length_m"]), mesh_size)
        ny = grid_count(float(geometry["width_m"]), mesh_size)
        nz = grid_count(float(geometry["height_m"]), mesh_size)
        nodes = (nx + 1) * (ny + 1) * (nz + 1)
        elements = nx * ny * nz
        dimensions = {"nx": nx, "ny": ny, "nz": nz}
        dimensionality = 3
    elif model_type == "shell_box":
        nx = grid_count(float(geometry["length_m"]), mesh_size)
        ny = grid_count(float(geometry["width_m"]), mesh_size)
        nz = grid_count(float(geometry["height_m"]), mesh_size)
        nodes = 2 * ((nx + 1) * (ny + 1) + (nx + 1) * max(nz - 1, 0) + (ny + 1) * max(nz - 1, 0))
        elements = 2 * (nx * ny + nx * nz + ny * nz)
        dimensions = {"nx": nx, "ny": ny, "nz": nz}
        dimensionality = 2
    elif model_type == "cylinder_shell":
        nt = max(8, round(2 * math.pi * float(geometry["radius_m"]) / mesh_size))
        nz = grid_count(float(geometry["length_m"]), mesh_size)
        nodes = nt * (nz + 1)
        elements = nt * nz
        dimensions = {"nt": nt, "nz": nz}
        dimensionality = 2
    elif model_type == "cylinder_solid":
        nxy = max(4, 2 * grid_count(float(geometry["radius_m"]), mesh_size))
        nz = grid_count(float(geometry["length_m"]), mesh_size)
        nodes = (nxy + 1) * (nxy + 1) * (nz + 1)
        elements = nxy * nxy * nz
        dimensions = {"nxy": nxy, "nz": nz}
        dimensionality = 3
    elif model_type == "single_solid_element_test":
        nodes = 8
        elements = 1
        dimensions = {"nx": 1, "ny": 1, "nz": 1}
        dimensionality = 3
    elif model_type == "assembly_scene":
        nodes = 0
        elements = 0
        dimensionality = 3
        dimensions = {}
        for index, component in enumerate(spec.components):
            template = str(component["template"])
            component_mesh_size = float(component["mesh"]["size_m"])
            geometry = component["geometry"]
            if template == "shell_plate":
                nx = grid_count(float(geometry["length_m"]), component_mesh_size)
                ny = grid_count(float(geometry["width_m"]), component_mesh_size)
                nodes += (nx + 1) * (ny + 1)
                elements += nx * ny
                dimensions[f"c{index}_nx"] = nx
                dimensions[f"c{index}_ny"] = ny
            elif template == "solid_cylinder":
                nxy = max(8, 2 * grid_count(float(geometry["radius_m"]), component_mesh_size))
                nz = grid_count(float(geometry["length_m"]), component_mesh_size)
                nodes += (nxy + 1) * (nxy + 1) * (nz + 1)
                elements += nxy * nxy * nz
                dimensions[f"c{index}_nxy"] = nxy
                dimensions[f"c{index}_nz"] = nz
            elif template == "ellipsoid_shell":
                nt = max(
                    12,
                    round(2.0 * math.pi * max(float(geometry["radius_x_m"]), float(geometry["radius_y_m"])) / component_mesh_size),
                )
                nz = max(3, grid_count(float(geometry["height_m"]), component_mesh_size))
                nodes += nt * nz + 1
                elements += nt * nz
                dimensions[f"c{index}_nt"] = nt
                dimensions[f"c{index}_nz"] = nz
            else:
                raise ValueError(f"unsupported component template for preflight: {template}")
    else:
        raise ValueError(f"unsupported model_type for preflight: {model_type}")

    keyword_bytes = estimate_keyword_bytes(nodes, elements)
    suggested = suggested_mesh_size(mesh_size, dimensions, nodes, elements, keyword_bytes, dimensionality)
    return {
        "model_type": model_type,
        "mesh_size_m": mesh_size,
        "dimensions": dimensions,
        "node_count": nodes,
        "element_count": elements,
        "keyword_bytes": keyword_bytes,
        "suggested_mesh_size_m": suggested,
        "limits": {
            "max_axis_cells": MAX_AXIS_CELLS,
            "max_ring_segments": MAX_RING_SEGMENTS,
            "max_nodes": MAX_NODES,
            "max_elements": MAX_ELEMENTS,
            "max_keyword_bytes": MAX_KEYWORD_BYTES,
        },
    }


def grid_count(size: float, mesh_size: float) -> int:
    return max(1, round(size / mesh_size))


def estimate_keyword_bytes(nodes: int, elements: int) -> int:
    return 8_192 + nodes * 80 + elements * 96


def suggested_mesh_size(
    mesh_size: float,
    dimensions: JSONDict,
    nodes: int,
    elements: int,
    keyword_bytes: int,
    dimensionality: int,
) -> float:
    scale = 1.0
    for key, value in dimensions.items():
        limit = MAX_RING_SEGMENTS if key == "nt" else MAX_AXIS_CELLS
        if int(value) > limit:
            scale = max(scale, int(value) / limit)
    if nodes > MAX_NODES:
        scale = max(scale, (nodes / MAX_NODES) ** (1.0 / max(dimensionality, 1)))
    if elements > MAX_ELEMENTS:
        scale = max(scale, (elements / MAX_ELEMENTS) ** (1.0 / max(dimensionality, 1)))
    if keyword_bytes > MAX_KEYWORD_BYTES:
        scale = max(scale, (keyword_bytes / MAX_KEYWORD_BYTES) ** (1.0 / max(dimensionality, 1)))
    return mesh_size * scale * 1.05
