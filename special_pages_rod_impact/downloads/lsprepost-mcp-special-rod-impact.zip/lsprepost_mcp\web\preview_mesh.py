from __future__ import annotations

from collections import defaultdict
from pathlib import Path

from lsprepost_mcp.config import JSONDict


NODE_CARD = "*NODE"
SHELL_CARD = "*ELEMENT_SHELL"
SOLID_CARD = "*ELEMENT_SOLID"


def build_preview_mesh(project_path: Path) -> JSONDict:
    keyword_path = project_path / "model.k"
    if not keyword_path.is_file():
        raise FileNotFoundError(f"model.k not found: {keyword_path}")
    nodes, shell_elements, solid_elements = parse_keyword_mesh(keyword_path.read_text(encoding="utf-8"))
    parts = []
    for pid in sorted(set(shell_elements) | set(solid_elements)):
        shell_faces = [element[1] for element in shell_elements.get(pid, [])]
        solid_faces = boundary_faces([element[1] for element in solid_elements.get(pid, [])])
        faces = shell_faces + solid_faces
        if not faces:
            continue
        parts.append(part_mesh(pid, "mixed" if shell_faces and solid_faces else ("shell" if shell_faces else "solid"), nodes, faces))
    bounds = mesh_bounds(nodes)
    return {
        "format": "lsprepost_mcp_preview_mesh_v1",
        "project_name": project_path.name,
        "parts": parts,
        "bounds": bounds,
        "node_count": len(nodes),
        "face_count": sum(len(part["faces"]) for part in parts),
        "limitations": [
            "Browser preview is generated from controlled keyword mesh cards and is not a solver result.",
            "Solid elements are displayed by exterior faces only.",
        ],
    }


def parse_keyword_mesh(text: str) -> tuple[dict[int, list[float]], dict[int, list[tuple[int, list[int]]]], dict[int, list[tuple[int, list[int]]]]]:
    nodes: dict[int, list[float]] = {}
    shell_elements: dict[int, list[tuple[int, list[int]]]] = defaultdict(list)
    solid_elements: dict[int, list[tuple[int, list[int]]]] = defaultdict(list)
    current = ""
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("$"):
            continue
        if line.startswith("*"):
            current = line.split()[0].split(",")[0].upper()
            continue
        fields = split_fields(line)
        if current == NODE_CARD and len(fields) >= 4:
            nid = int(float(fields[0]))
            nodes[nid] = [float(fields[1]), float(fields[2]), float(fields[3])]
        elif current == SHELL_CARD and len(fields) >= 6:
            eid = int(float(fields[0]))
            pid = int(float(fields[1]))
            node_ids = [int(float(value)) for value in fields[2:6]]
            shell_elements[pid].append((eid, normalize_shell_face(node_ids)))
        elif current == SOLID_CARD and len(fields) >= 10:
            eid = int(float(fields[0]))
            pid = int(float(fields[1]))
            node_ids = [int(float(value)) for value in fields[2:10]]
            solid_elements[pid].append((eid, node_ids))
    return nodes, dict(shell_elements), dict(solid_elements)


def split_fields(line: str) -> list[str]:
    if "," in line:
        return [field.strip() for field in line.split(",") if field.strip()]
    return line.split()


def normalize_shell_face(node_ids: list[int]) -> list[int]:
    if len(node_ids) == 4 and node_ids[2] == node_ids[3]:
        return node_ids[:3]
    return node_ids


def boundary_faces(elements: list[list[int]]) -> list[list[int]]:
    counts: dict[tuple[int, ...], list[int] | None] = {}
    for n in elements:
        candidates = [
            [n[0], n[1], n[2], n[3]],
            [n[4], n[7], n[6], n[5]],
            [n[0], n[4], n[5], n[1]],
            [n[1], n[5], n[6], n[2]],
            [n[2], n[6], n[7], n[3]],
            [n[3], n[7], n[4], n[0]],
        ]
        for face in candidates:
            key = tuple(sorted(face))
            if key in counts:
                counts[key] = None
            else:
                counts[key] = face
    return [face for face in counts.values() if face is not None]


def part_mesh(pid: int, family: str, all_nodes: dict[int, list[float]], faces_by_node_id: list[list[int]]) -> JSONDict:
    used_node_ids = sorted({nid for face in faces_by_node_id for nid in face})
    local_index = {nid: index for index, nid in enumerate(used_node_ids)}
    nodes = [all_nodes[nid] for nid in used_node_ids if nid in all_nodes]
    faces = [[local_index[nid] for nid in face if nid in local_index] for face in faces_by_node_id]
    faces = [face for face in faces if len(face) >= 3]
    return {
        "part_id": pid,
        "name": f"part_{pid}",
        "element_family": family,
        "color": color_for_part(pid),
        "nodes": nodes,
        "faces": faces,
        "edges": edges_for_faces(faces),
    }


def edges_for_faces(faces: list[list[int]]) -> list[list[int]]:
    edges: set[tuple[int, int]] = set()
    for face in faces:
        for index, start in enumerate(face):
            end = face[(index + 1) % len(face)]
            edges.add(tuple(sorted((start, end))))
    return [list(edge) for edge in sorted(edges)]


def mesh_bounds(nodes: dict[int, list[float]]) -> JSONDict:
    if not nodes:
        return {"min": [0.0, 0.0, 0.0], "max": [0.0, 0.0, 0.0], "center": [0.0, 0.0, 0.0]}
    xs = [point[0] for point in nodes.values()]
    ys = [point[1] for point in nodes.values()]
    zs = [point[2] for point in nodes.values()]
    mn = [min(xs), min(ys), min(zs)]
    mx = [max(xs), max(ys), max(zs)]
    center = [(mn[index] + mx[index]) * 0.5 for index in range(3)]
    return {"min": mn, "max": mx, "center": center}


def color_for_part(pid: int) -> str:
    palette = ["#d94157", "#2f8fcd", "#f0a02f", "#55aa65", "#8b6bd6", "#40a6a6"]
    return palette[(pid - 1) % len(palette)]
