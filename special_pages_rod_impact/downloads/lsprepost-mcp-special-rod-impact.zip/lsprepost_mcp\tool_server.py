from __future__ import annotations

from .config import ARCHIVE_PROJECTS_DIR, JSONDict, LEGACY_PROJECTS_DIR, PROJECTS_DIR, ROOT, lspp_exe
from .lspp.launcher import doctor_lsprepost_exe


def tool_server_info(_: JSONDict) -> JSONDict:
    exe = lspp_exe()
    doctor = doctor_lsprepost_exe(exe).to_json()
    return {
        "name": "lsprepost-mcp",
        "version": "0.2.0",
        "workspace_root": str(ROOT),
        "projects_dir": str(PROJECTS_DIR),
        "legacy_projects_dir": str(LEGACY_PROJECTS_DIR),
        "archive_projects_dir": str(ARCHIVE_PROJECTS_DIR),
        "materials_dir": str(ROOT / "materials"),
        "lspp_exe": str(exe),
        "lspp_exe_exists": exe.exists(),
        "lspp_doctor": doctor,
        "transport": "stdio-jsonrpc-newline",
    }
