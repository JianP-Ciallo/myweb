param(
    [string]$LsppExe = $env:LSPP_EXE,
    [string]$HostName = "127.0.0.1",
    [int]$Port = 8765,
    [switch]$OpenBrowser,
    [switch]$SkipDoctor
)

$ErrorActionPreference = "Stop"
$RootPath = Resolve-Path (Join-Path $PSScriptRoot "..")
$Root = $RootPath.Path

if ($LsppExe) {
    $env:LSPP_EXE = $LsppExe
}

if (-not $SkipDoctor) {
    $doctorArgs = @(
        "-NoProfile",
        "-ExecutionPolicy",
        "Bypass",
        "-File",
        (Join-Path $Root "scripts\doctor.ps1")
    )
    if ($LsppExe) {
        $doctorArgs += @("-LsppExe", $LsppExe)
    }

    & powershell @doctorArgs
    if ($LASTEXITCODE -ne 0) {
        throw "doctor.ps1 failed; Web App startup aborted."
    }
}

Push-Location $Root
try {
    $args = @(
        "-m",
        "lsprepost_mcp.web.app",
        "--host",
        $HostName,
        "--port",
        [string]$Port
    )
    if ($LsppExe) {
        $args += @("--lspp-exe", $LsppExe)
    }
    if ($OpenBrowser) {
        $args += "--open-browser"
    }

    & python @args
    exit $LASTEXITCODE
} finally {
    Pop-Location
}
