param(
    [string]$OutputPath = "",
    [string]$BuildLabel = "",
    [switch]$LatestCopy,
    [switch]$Pure
)

$ErrorActionPreference = "Stop"
$Root = Resolve-Path (Join-Path $PSScriptRoot "..")
$Dist = Join-Path $Root "dist"
$Timestamp = (Get-Date).ToUniversalTime().ToString("yyyyMMddTHHmmssZ")
$SafeLabel = ""
if ($BuildLabel) {
    $SafeLabel = ($BuildLabel -replace "[^A-Za-z0-9_.-]", "-").Trim("-")
}
if (-not $SafeLabel) {
    throw "BuildLabel is required. Use a phase/optimization label such as -BuildLabel phase6-preview-export."
}
$PackageBaseName = "lsprepost-mcp_${SafeLabel}_$Timestamp"
$StageRoot = Join-Path $Dist ".pack"
$Stage = Join-Path $StageRoot $PackageBaseName

if (-not $OutputPath) {
    $OutputPath = Join-Path $Dist "$PackageBaseName.zip"
}

New-Item -ItemType Directory -Path $Dist -Force | Out-Null
if (Test-Path $StageRoot) {
    Remove-Item -LiteralPath $StageRoot -Recurse -Force
}
New-Item -ItemType Directory -Path $StageRoot -Force | Out-Null
if (Test-Path $Stage) {
    Remove-Item -LiteralPath $Stage -Recurse -Force
}
New-Item -ItemType Directory -Path $Stage | Out-Null

$excludedDirs = @(
    ".git",
    "__pycache__",
    ".pytest_cache",
    "dist",
    "workspace",
    "projects",
    "generated_configs",
    "internal_docs"
)
if ($Pure) {
    $excludedDirs += "demo"
}
$excludedFilePatterns = @(
    "*.pyc",
    "lspost.cfile",
    "lspost.msg"
)

Get-ChildItem -Path $Root -Force | ForEach-Object {
    if ($excludedDirs -contains $_.Name) {
        return
    }
    if ($_.PSIsContainer) {
        $target = Join-Path $Stage $_.Name
        Copy-Item -LiteralPath $_.FullName -Destination $target -Recurse -Force
    } else {
        foreach ($pattern in $excludedFilePatterns) {
            if ($_.Name -like $pattern) {
                return
            }
        }
        Copy-Item -LiteralPath $_.FullName -Destination $Stage -Force
    }
}

Get-ChildItem -Path $Stage -Recurse -Force -Directory -Filter "__pycache__" | Remove-Item -Recurse -Force
Get-ChildItem -Path $Stage -Recurse -Force -File -Include $excludedFilePatterns | Remove-Item -Force
if ($Pure) {
    $docsDir = Join-Path $Stage "docs"
    if (Test-Path $docsDir) {
        Get-ChildItem -LiteralPath $docsDir -Directory | Remove-Item -Recurse -Force
    }
    $examplesDir = Join-Path $Stage "examples"
    if (Test-Path $examplesDir) {
        Get-ChildItem -LiteralPath $examplesDir -Directory | Where-Object {
            $_.Name -like "phase*"
        } | Remove-Item -Recurse -Force
    }
}
$forbidden = Get-ChildItem -Path $Stage -Recurse -Force | Where-Object {
    $_.Name -eq "__pycache__" -or
    $_.Name -like "*.pyc" -or
    $_.Name -eq "lspost.cfile" -or
    $_.Name -eq "lspost.msg" -or
    $_.FullName -like "*\workspace\*" -or
    $_.FullName -like "*\projects\*"
}
if ($forbidden) {
    $forbidden | Select-Object -ExpandProperty FullName
    throw "Package contains forbidden runtime artifacts."
}

$localPathHits = Get-ChildItem -Path $Stage -Recurse -Force -File | Where-Object {
    $_.Extension -notin @(".png", ".jpg", ".jpeg", ".gif", ".zip", ".pyc")
} | Select-String -Pattern '[A-Za-z]:\\|workplace' -List | Where-Object {
    $relativePath = $_.Path.Substring($Stage.Length).TrimStart("\", "/").Replace("\", "/")
    -not $relativePath.StartsWith("tests/") -and
    -not $relativePath.EndsWith("scripts/pack.ps1")
}
if ($localPathHits) {
    $localPathHits | ForEach-Object { "$($_.Path):$($_.LineNumber): $($_.Line.Trim())" }
    throw "Package contains local absolute path examples. Replace them with placeholders before distribution."
}

$manifestPath = Join-Path $Stage "PACKAGE_MANIFEST.txt"
$manifestLines = @(
    "lsprepost-mcp package manifest",
    "PackageName=$([System.IO.Path]::GetFileName($OutputPath))",
    "BuildLabel=$BuildLabel",
    "GeneratedAtUtc=$((Get-Date).ToUniversalTime().ToString('o'))",
    "ImmutablePackage=true",
    "PurePackage=$([bool]$Pure)",
    ""
)
$files = Get-ChildItem -Path $Stage -Recurse -Force -File | Sort-Object FullName
foreach ($file in $files) {
    $relative = $file.FullName.Substring($Stage.Length).TrimStart("\", "/").Replace("\", "/")
    $hash = (Get-FileHash -Algorithm SHA256 -LiteralPath $file.FullName).Hash
    $manifestLines += "$hash  $relative"
}
$manifestLines | Set-Content -LiteralPath $manifestPath -Encoding UTF8

if (Test-Path $OutputPath) {
    throw "Refusing to overwrite existing package: $OutputPath"
}
Compress-Archive -Path (Join-Path $Stage "*") -DestinationPath $OutputPath
Remove-Item -LiteralPath $Stage -Recurse -Force

if ($LatestCopy) {
    $latestPath = Join-Path $Dist "lsprepost-mcp_latest.zip"
    Copy-Item -LiteralPath $OutputPath -Destination $latestPath -Force
    Write-Output "Updated latest package copy: $latestPath"
}

Write-Output "Created package: $OutputPath"
