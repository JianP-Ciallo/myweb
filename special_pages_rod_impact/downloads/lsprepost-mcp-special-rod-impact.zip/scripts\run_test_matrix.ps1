param(
    [ValidateSet("default", "critical", "packaging", "snapshots", "errors", "paths", "gui", "web", "all")]
    [string]$Group = "default",
    [switch]$List
)

$ErrorActionPreference = "Stop"
$Root = Resolve-Path (Join-Path $PSScriptRoot "..")

$groups = [ordered]@{
    default = @{
        description = "All default unittest tests. GUI integration remains skipped unless LSPP_INTEGRATION=1."
        command = @("python", "-m", "unittest", "discover", "-s", "tests")
    }
    critical = @{
        description = "Critical regression tests for JSON-RPC, tools, provenance, phase 9 refactor, and packaging boundaries."
        command = @(
            "python", "-m", "unittest",
            "tests.test_jsonrpc",
            "tests.test_tools",
            "tests.test_generated_keyword_provenance",
            "tests.test_phase9_refactor",
            "tests.test_phase10_error_inputs",
            "tests.test_phase10_paths",
            "tests.test_packaging_and_integration_boundaries"
        )
    }
    packaging = @{
        description = "Distribution and installer boundary tests."
        command = @(
            "python", "-m", "unittest",
            "tests.test_packaging_and_integration_boundaries",
            "tests.test_phase8_distribution"
        )
    }
    snapshots = @{
        description = "Stable keyword snapshot hash tests for representative generated decks."
        command = @("python", "-m", "unittest", "tests.test_keyword_snapshots")
    }
    errors = @{
        description = "Focused invalid-input tests for schema, materials, contacts, and numeric guards."
        command = @("python", "-m", "unittest", "tests.test_phase10_error_inputs")
    }
    paths = @{
        description = "Path robustness tests for script entry points from directories with spaces and Unicode."
        command = @("python", "-m", "unittest", "tests.test_phase10_paths")
    }
    gui = @{
        description = "Real LS-PrePost GUI integration tests. Requires LSPP_INTEGRATION=1 and LSPP_EXE."
        command = @("python", "-m", "unittest", "tests.test_integration_lsprepost")
    }
    web = @{
        description = "Local Web App API, static UI, and startup tests."
        command = @(
            "python", "-m", "unittest",
            "tests.test_web_api",
            "tests.test_web_static",
            "tests.test_web_startup"
        )
    }
    all = @{
        description = "Alias for default plus compileall."
        command = @("python", "-m", "unittest", "discover", "-s", "tests")
    }
}

if ($List) {
    foreach ($name in $groups.Keys) {
        Write-Output ("{0}: {1}" -f $name, $groups[$name].description)
    }
    exit 0
}

Set-Location $Root
$env:PYTHONDONTWRITEBYTECODE = "1"

$selected = $groups[$Group]
Write-Output ("Running test matrix group: {0}" -f $Group)
Write-Output ($selected.description)
& $selected.command[0] $selected.command[1..($selected.command.Count - 1)]
if ($LASTEXITCODE -ne 0) {
    exit $LASTEXITCODE
}

if ($Group -eq "all") {
    python -m compileall -q .\lsprepost_mcp
    if ($LASTEXITCODE -ne 0) {
        exit $LASTEXITCODE
    }
}
