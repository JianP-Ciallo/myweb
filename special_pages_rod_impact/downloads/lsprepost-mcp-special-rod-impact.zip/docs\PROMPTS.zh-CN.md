# 自然语言工况提示词说明

本文档说明 `generate_scene_from_prompt` 的第七阶段能力边界。

## 基本原则

本项目不是开放式任意建模系统。AI IDE 可以用自然语言描述工况，但 MCP 只会把 prompt 解析为白名单场景模板，再由受控组件库、材料库、接触模板、载荷模板和校验器生成 `model.k`。

不支持的 prompt 会返回 `unsupported_scene_prompt`，不会拼接用户原始 LS-DYNA keyword。

## 支持场景

### rebar_drop_on_helmet

用途：钢筋从头盔上方自由落体，冲击固定头盔。

示例：

```text
生成一根1米长、半径12毫米的钢筋，从头盔上方10米自由落体，撞击固定在地面上的头盔
```

关键参数：

- `rebar_length_m`
- `rebar_radius_m` 或 `rebar_diameter_m`
- `drop_height_m`
- `material_name`

### rod_impact_plate

用途：实体圆柱杆以初速度撞击固定钢板。

示例：

```text
生成一根长0.5米半径20毫米的圆柱杆，以12m/s向下撞击固定钢板，钢板长0.8米宽0.6米厚4毫米
```

关键参数：

- `rod_length_m`
- `rod_radius_m` 或 `rod_diameter_m`
- `impact_velocity_m_per_s`
- `plate_length_m`
- `plate_width_m`
- `plate_thickness_m`
- `material_name`

### cube_top_corner_load

用途：实体立方体底面固定，顶面四角向下施加集中力。

示例：

```text
生成2x2x2米低碳钢立方体，底面固定，顶面四个角向下各施加1000N载荷
```

关键参数：

- `cube_length_m`
- `cube_width_m`
- `cube_height_m`
- `corner_force_n`
- `material_name`

### plate_pressure

用途：壳板固定边界，板面施加均布压力。

示例：

```text
生成长1米宽0.5米厚3毫米的钢板，左边固定，在板面施加20000Pa均布压力
```

关键参数：

- `plate_length_m`
- `plate_width_m`
- `plate_thickness_m`
- `pressure_pa`
- `material_name`

## 缺参规则

默认 `allow_defaults=false`。如果 prompt 命中了受控场景，但缺少关键物理参数，工具会返回：

- `needs_confirmation=true`
- `missing_parameters`
- `suggested_defaults`

此时不会写入项目文件。

如果用户明确允许默认值，可以传入 `allow_defaults=true`。

## 生成前预览

传入 `dry_run=true` 时，工具只返回解析后的 `resolved_spec`，不会写入 `workspace/projects`。

这适合 AI IDE 先把结构化工况展示给用户确认，再正式生成模型。

## 高风险提示

涉及冲击、接触、压力方向、边界条件的场景会返回 `risk_notes`。这些提示不是求解结果，只说明该模型需要用户或工程师在 LS-PrePost/LS-DYNA 中复核。

当前 MCP 只生成初始工况和预览校验，不自动判断损伤、贯穿或失效结论。
