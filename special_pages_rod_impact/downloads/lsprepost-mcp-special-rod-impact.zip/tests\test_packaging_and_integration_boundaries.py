from __future__ import annotations

import shutil
import subprocess
import unittest
import zipfile
import re
from pathlib import Path

from lsprepost_mcp.config import ROOT


class PackagingAndIntegrationBoundaryTests(unittest.TestCase):
    def test_pack_rejects_single_backslash_windows_paths(self) -> None:
        probe = ROOT / "pack_local_path_probe.txt"
        dist_pack = ROOT / "dist" / ".pack"
        drive = "E:"
        probe.write_text(f"local path example: {drive}\\Temp\\lspp\\model.k\n", encoding="utf-8")
        try:
            result = subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-ExecutionPolicy",
                    "Bypass",
                    "-File",
                    str(ROOT / "scripts" / "pack.ps1"),
                    "-BuildLabel",
                    "unit-local-path-probe",
                ],
                cwd=str(ROOT),
                text=True,
                capture_output=True,
                timeout=60,
            )
            combined = result.stdout + result.stderr
            self.assertNotEqual(result.returncode, 0, combined)
            self.assertIn("Package contains local absolute path examples", combined)
        finally:
            if probe.exists():
                probe.unlink()
            if dist_pack.exists():
                shutil.rmtree(dist_pack)

    def test_integration_smoke_uses_managed_cfile_tools(self) -> None:
        source = (ROOT / "tests" / "test_integration_lsprepost.py").read_text(encoding="utf-8")
        self.assertNotIn("subprocess.run", source)
        self.assertNotIn("write_text('open keyword", source)
        self.assertIn("tool_validate_lsprepost_import", source)

    def test_pure_package_excludes_intermediate_artifacts(self) -> None:
        output = ROOT / "dist" / "unit-pure-package.zip"
        dist_pack = ROOT / "dist" / ".pack"
        if output.exists():
            output.unlink()
        try:
            result = subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-ExecutionPolicy",
                    "Bypass",
                    "-File",
                    str(ROOT / "scripts" / "pack.ps1"),
                    "-BuildLabel",
                    "unit-pure-package",
                    "-OutputPath",
                    str(output),
                    "-Pure",
                ],
                cwd=str(ROOT),
                text=True,
                capture_output=True,
                timeout=60,
            )
            combined = result.stdout + result.stderr
            self.assertEqual(result.returncode, 0, combined)
            with zipfile.ZipFile(output) as archive:
                names = [name.replace("\\", "/") for name in archive.namelist()]
            forbidden_prefixes = [
                "demo/",
                "dist/",
                "workspace/",
                "generated_configs/",
                "examples/phase",
                "docs/钢筋冲击钢盔_真实生成讲解/",
            ]
            for prefix in forbidden_prefixes:
                self.assertFalse(any(name.startswith(prefix) for name in names), prefix)
            self.assertIn("README.zh-CN.md", names)
            self.assertIn("start_web_app.cmd", names)
            self.assertIn("lsprepost_mcp/server.py", names)
            self.assertIn("scripts/start_web_app.ps1", names)
            self.assertIn("lsprepost_mcp/web/app.py", names)
            self.assertIn("lsprepost_mcp/web/static/index.html", names)
            self.assertIn("examples/generate_model.jsonl", names)
            windows_path_re = re.compile(r"[A-Za-z]:\\")
            with zipfile.ZipFile(output) as archive:
                text_hits = []
                for info in archive.infolist():
                    name = info.filename.replace("\\", "/")
                    if name == "scripts/pack.ps1":
                        continue
                    if not name.endswith((".py", ".ps1", ".md", ".json", ".jsonl", ".txt", ".cmd", ".sh", ".cfile")):
                        continue
                    text = archive.read(info).decode("utf-8", errors="ignore")
                    if windows_path_re.search(text):
                        text_hits.append(name)
            self.assertEqual([], text_hits)
        finally:
            if output.exists():
                output.unlink()
            if dist_pack.exists():
                shutil.rmtree(dist_pack)


if __name__ == "__main__":
    unittest.main()
