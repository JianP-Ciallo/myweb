import React from "react";

export function App() {
  return (
    <main style={{ fontFamily: "Arial, sans-serif", padding: 24 }}>
      <h1>lsprepost-mcp Web App</h1>
      <p>
        React/Vite build entry. The runtime server uses this build when web/dist/index.html exists;
        otherwise it serves the built-in fallback UI.
      </p>
    </main>
  );
}
