# 分发、安装和回退说明

本文档面向拿到 zip 包的使用者。

## 1. 解压

把 `lsprepost-mcp_*.zip` 解压到本机任意目录，例如：

```text
<INSTALL_DIR>\lsprepost-mcp
```

目录路径可以不同，不需要保持开发机路径。

## 2. 检查环境

在项目根目录运行：

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\doctor.ps1
```

这会检查：

- Python 是否可用
- MCP server 是否可导入
- 启动脚本是否存在
- cfile 模板是否存在
- 材料库是否存在

如果要同时检查 LS-PrePost 路径：

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\doctor.ps1 -LsppExe "<LS_PREPOST_EXE>" -RequireLsPrePost
```

`<LS_PREPOST_EXE>` 应替换为本机真实的 `lsprepost*.exe`。

## 3. 生成 AI IDE 配置

运行：

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\setup.ps1 -LsppExe "<LS_PREPOST_EXE>"
```

生成结果位于：

```text
generated_configs\
```

其中包含：

- `codex.mcp.json`
- `cursor.mcp.json`
- `claude_desktop_config.fragment.json`
- `windsurf.mcp.json`
- `vscode.mcp.json`
- `visualstudio.mcp.json`
- `lsprepost_mcp.local.env.ps1`

把对应 JSON 合并到目标 AI IDE 的 MCP 配置中。

## 4. 直接安装到项目级配置

如果目标项目使用 Cursor，可以在 MCP 项目根目录运行：

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\install_to_cursor.ps1 -TargetDir "<TARGET_PROJECT_DIR>" -LsppExe "<LS_PREPOST_EXE>"
```

这会写入：

```text
<TARGET_PROJECT_DIR>\.cursor\mcp.json
```

如果目标项目使用 VS Code，可以运行：

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\install_to_vscode.ps1 -TargetDir "<TARGET_PROJECT_DIR>" -LsppExe "<LS_PREPOST_EXE>"
```

这会写入：

```text
<TARGET_PROJECT_DIR>\.vscode\mcp.json
```

默认不会覆盖已有配置。确实要覆盖时，显式增加 `-Force`。

## 5. 本地 smoke test

先运行：

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\smoke_test_generate_model.ps1
```

如果输出包含：

```json
"ok": true
```

说明 MCP 生成模型闭环可用。

## 6. 回退旧版本

每次优化都会生成独立 zip，不覆盖旧包。出现问题时：

1. 停止当前 AI IDE 中正在运行的 MCP。
2. 解压旧版本 zip 到新的目录。
3. 在旧版本目录运行 `scripts\doctor.ps1`。
4. 重新运行 `scripts\setup.ps1 -LsppExe "<LS_PREPOST_EXE>"`。
5. 把 AI IDE MCP 配置中的脚本路径改回旧版本目录下的 `scripts\start_mcp_server.cmd`。

不建议在旧目录上直接覆盖解压新版本；保留多个独立目录更容易回退。

## 7. 分发包边界

分发包不包含：

- `.git`
- `workspace`
- `projects`
- `generated_configs`
- `__pycache__`
- `lspost.cfile`
- `lspost.msg`
- 本机绝对路径示例

本机配置应由 `setup.ps1` 在使用者机器上重新生成。
