from __future__ import annotations

import json
import http.client
import threading
import unittest
from contextlib import contextmanager
from pathlib import Path

from lsprepost_mcp.config import ROOT as PROJECT_ROOT
from lsprepost_mcp.web.app import create_server


ROOT = Path(__file__).resolve().parents[1]
APP_JS = ROOT / "lsprepost_mcp" / "web" / "static" / "app.js"
PACKAGE_JSON = ROOT / "web" / "package.json"


@contextmanager
def web_test_server():
    server = create_server("127.0.0.1", 0, open_browser=False)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield server.server_address
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)


def request_raw(address, path: str):
    conn = http.client.HTTPConnection(address[0], address[1], timeout=10)
    conn.request("GET", path)
    response = conn.getresponse()
    data = response.read()
    headers = dict(response.getheaders())
    conn.close()
    return response.status, headers, data


class WebStaticFallbackTests(unittest.TestCase):
    def test_root_serves_fallback_html(self) -> None:
        with web_test_server() as address:
            status, headers, data = request_raw(address, "/")

        text = data.decode("utf-8")
        self.assertEqual(status, 200)
        self.assertIn("text/html", headers["Content-Type"])
        self.assertIn("lsprepost-mcp 本地建模工作台", text)
        self.assertIn("app.js", text)

    def test_app_js_contains_scene_loader(self) -> None:
        with web_test_server() as address:
            status, headers, data = request_raw(address, "/app.js")

        text = data.decode("utf-8")
        self.assertEqual(status, 200)
        self.assertIn("javascript", headers["Content-Type"])
        self.assertIn("loadScenes", text)

    def test_static_ui_contains_lsprepost_path_configuration_controls(self) -> None:
        html = (ROOT / "lsprepost_mcp" / "web" / "static" / "index.html").read_text(encoding="utf-8")
        js = APP_JS.read_text(encoding="utf-8")

        self.assertIn('id="lsppExe"', html)
        self.assertIn('id="importLspp"', html)
        self.assertIn('id="saveLspp"', html)
        self.assertIn("/api/config/select-lsprepost", js)
        self.assertIn("/api/config/check-lsprepost", js)
        self.assertIn("/api/config/lsprepost", js)

    def test_static_ui_contains_user_export_directory_controls(self) -> None:
        html = (ROOT / "lsprepost_mcp" / "web" / "static" / "index.html").read_text(encoding="utf-8")
        js = APP_JS.read_text(encoding="utf-8")

        self.assertIn('id="exportDirStatus"', html)
        self.assertIn('id="selectExportDir"', html)
        self.assertIn('id="exportDir"', html)
        self.assertIn('id="saveExportDir"', html)
        self.assertIn("/api/config/select-export-dir", js)
        self.assertIn("/api/config/export-dir", js)

    def test_static_ui_contains_complete_model_package_import_controls(self) -> None:
        html = (ROOT / "lsprepost_mcp" / "web" / "static" / "index.html").read_text(encoding="utf-8")
        js = APP_JS.read_text(encoding="utf-8")

        self.assertIn('id="importPackageStatus"', html)
        self.assertIn('id="selectImportPackageDir"', html)
        self.assertIn('id="importPackageDir"', html)
        self.assertIn('id="importPackageProjectName"', html)
        self.assertIn('id="importPackage"', html)
        self.assertIn("/api/project/select-import-package", js)
        self.assertIn("/api/project/import-package", js)

    def test_static_ui_is_chinese_workbench_with_center_viewport(self) -> None:
        html = (ROOT / "lsprepost_mcp" / "web" / "static" / "index.html").read_text(encoding="utf-8")

        self.assertIn('lang="zh-CN"', html)
        self.assertIn("本地建模工作台", html)
        self.assertIn('id="leftWorkbench"', html)
        self.assertIn('id="modelViewport"', html)
        self.assertIn('id="rightInspector"', html)
        self.assertIn("三维视窗", html)
        self.assertIn("导入 LS-PrePost", html)
        self.assertNotIn(">Check Path<", html)
        self.assertNotIn(">Save Path<", html)
        self.assertNotIn(">Projects<", html)
        self.assertNotIn(">Use<", html)

    def test_static_ui_contains_interactive_canvas_viewer(self) -> None:
        html = (ROOT / "lsprepost_mcp" / "web" / "static" / "index.html").read_text(encoding="utf-8")
        js = APP_JS.read_text(encoding="utf-8")

        self.assertIn('id="modelCanvas"', html)
        self.assertIn('id="viewerHint"', html)
        self.assertIn("/api/project/preview-mesh", js)
        self.assertIn("renderInteractiveMesh", js)
        self.assertIn("pointerdown", js)
        self.assertIn("wheel", js)

    def test_canvas_viewer_uses_world_grid_and_rotating_axis_widget(self) -> None:
        js = APP_JS.read_text(encoding="utf-8")
        css = (ROOT / "lsprepost_mcp" / "web" / "static" / "styles.css").read_text(encoding="utf-8")

        self.assertIn("function drawWorldGrid", js)
        self.assertIn("function drawRotatingAxes", js)
        self.assertIn("function projectWorldPoint", js)
        self.assertIn("function rotateViewVector", js)
        self.assertNotIn("for (let x = 0; x <= width; x += 44)", js)
        self.assertIn(".viewport-grid", css)
        self.assertIn("display: none", css)

    def test_preview_button_refreshes_interactive_mesh_not_gif_overlay(self) -> None:
        text = APP_JS.read_text(encoding="utf-8")

        self.assertIn("async function previewInteractiveModel()", text)
        self.assertIn('byId("preview").addEventListener("click", previewInteractiveModel)', text)
        self.assertNotIn('byId("preview").addEventListener("click", previewGif)', text)

    def test_static_js_filters_unnamed_projects_and_limits_sidebar(self) -> None:
        text = APP_JS.read_text(encoding="utf-8")

        self.assertIn("有效项目", text)
        self.assertIn(".filter((project)", text)
        self.assertIn("project.name", text)
        self.assertIn(".slice(0, 5)", text)
        self.assertIn('button.textContent = "使用"', text)

    def test_app_js_updates_project_name_from_generation_result(self) -> None:
        text = APP_JS.read_text(encoding="utf-8")

        self.assertIn("result.write_result.project", text)
        self.assertIn('byId("projectName").value = generatedProjectName', text)
        self.assertIn("lastProjectName = generatedProjectName", text)

    def test_app_js_replaces_existing_controlled_scene_project_name_when_scene_changes(self) -> None:
        text = APP_JS.read_text(encoding="utf-8")
        start = text.index("function updateProjectNameForScene")
        end = text.index("function renderFields")
        function_text = text[start:end]

        self.assertIn("controlledScenePrefix", text)
        self.assertIn("currentStartsWithControlledPrefix", text)
        self.assertIn("input.value = `web_${scene.id}`", function_text)

    def test_app_js_refreshes_projects_inside_generate_action(self) -> None:
        text = APP_JS.read_text(encoding="utf-8")
        start = text.index("async function generateScene()")
        end = text.index("async function previewInteractiveModel()")
        generate_scene = text[start:end]

        self.assertIn("await loadProjects();", generate_scene)
        self.assertLess(generate_scene.index("await loadProjects();"), generate_scene.index("return result;"))
        self.assertNotIn("if (result) await loadProjects();", generate_scene)

    def test_app_js_renders_user_friendly_operation_summary(self) -> None:
        text = APP_JS.read_text(encoding="utf-8")

        self.assertIn("function showOperationSummary", text)
        self.assertIn("function summarizeResult", text)
        self.assertIn("查看详细信息", text)
        self.assertNotIn("showResult(result);", text)

    def test_static_ui_contains_workflow_reliability_panels(self) -> None:
        html = (ROOT / "lsprepost_mcp" / "web" / "static" / "index.html").read_text(encoding="utf-8")
        css = (ROOT / "lsprepost_mcp" / "web" / "static" / "styles.css").read_text(encoding="utf-8")

        self.assertIn('id="contextStatus"', html)
        self.assertIn('id="partLegend"', html)
        self.assertIn("context-status", css)
        self.assertIn("part-legend", css)

    def test_app_js_confirms_generation_and_tracks_current_context(self) -> None:
        text = APP_JS.read_text(encoding="utf-8")
        start = text.index("async function generateScene()")
        end = text.index("async function previewInteractiveModel()")
        generate_scene = text[start:end]

        self.assertIn("function buildGenerationConfirmationSummary", text)
        self.assertIn("function confirmGeneration", text)
        self.assertIn("window.confirm", text)
        self.assertIn("if (!confirmGeneration())", generate_scene)
        self.assertIn("function updateContextStatus", text)
        self.assertIn("viewer.projectName", text)

    def test_app_js_renders_part_legend_and_filters_hidden_parts(self) -> None:
        text = APP_JS.read_text(encoding="utf-8")

        self.assertIn("hiddenParts: new Set()", text)
        self.assertIn("function renderPartLegend", text)
        self.assertIn("function togglePartVisibility", text)
        self.assertIn("viewer.hiddenParts.has(String(part.part_id))", text)


class WebVitePackageTests(unittest.TestCase):
    def test_package_scripts_include_named_vite_commands(self) -> None:
        package = json.loads(PACKAGE_JSON.read_text(encoding="utf-8"))
        scripts = package["scripts"]

        self.assertEqual(scripts["dev:vite"], "vite")
        self.assertEqual(scripts["build:vite"], "vite build")
        self.assertEqual(scripts.get("dev"), "vite")
        self.assertEqual(scripts.get("build"), "vite build")


class WebBuildSelectionTests(unittest.TestCase):
    def test_static_root_prefers_dist_when_built_index_exists(self) -> None:
        from lsprepost_mcp.web.app import static_root

        dist = PROJECT_ROOT / "web" / "dist"
        index = dist / "index.html"
        had_dist = dist.exists()
        original = index.read_text(encoding="utf-8") if index.exists() else None

        dist.mkdir(parents=True, exist_ok=True)
        index.write_text("<!doctype html><title>built</title>", encoding="utf-8")
        try:
            self.assertEqual(static_root(), dist)
        finally:
            if original is None:
                index.unlink(missing_ok=True)
            else:
                index.write_text(original, encoding="utf-8")
            if not had_dist:
                try:
                    dist.rmdir()
                except OSError:
                    pass


if __name__ == "__main__":
    unittest.main()
