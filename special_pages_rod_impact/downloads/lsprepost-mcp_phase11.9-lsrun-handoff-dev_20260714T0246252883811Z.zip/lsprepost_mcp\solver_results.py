from __future__ import annotations

import math
import re

from .config import JSONDict


NUMBER_PATTERN = r"[+-]?(?:(?:\d+(?:\.\d*)?|\.\d+)(?:[EeDd][+-]?\d+)?|NaN|Inf(?:inity)?)"
ENERGY_PATTERNS = {
    "kinetic_energy": rf"^\s*kinetic\s+energy\s*\.*\s*({NUMBER_PATTERN})\s*$",
    "internal_energy": rf"^\s*internal\s+energy\s*\.*\s*({NUMBER_PATTERN})\s*$",
    "hourglass_energy": rf"^\s*hourglass\s+energy\s*\.*\s*({NUMBER_PATTERN})\s*$",
    "total_energy": rf"^\s*total\s+energy\s*\.*\s*({NUMBER_PATTERN})\s*$",
    "total_initial_ratio": rf"^\s*total\s+energy\s*/\s*initial\s+energy\s*\.*\s*({NUMBER_PATTERN})\s*$",
}


def parse_d3hsp(text: str) -> JSONDict:
    if not isinstance(text, str):
        raise TypeError("d3hsp text must be a string")
    lower_text = text.lower()
    normal_marker = "termination time reached" in lower_text or "normal termination" in lower_text
    error_marker = bool(
        re.search(
            r"(?im)^\s*(?:\*+\s*)?(?:error|e\s+r\s+r\s+o\s+r)\s+"
            r"(?:termination|t\s+e\s+r\s+m\s+i\s+n\s+a\s+t\s+i\s+o\s+n)\b",
            text,
        )
    )

    series: JSONDict = {}
    for name, pattern in ENERGY_PATTERNS.items():
        series[name] = [
            _parse_number(match.group(1))
            for match in re.finditer(pattern, text, flags=re.IGNORECASE | re.MULTILINE)
        ]

    all_values = [value for values in series.values() for value in values]
    finite = bool(all_values) and all(math.isfinite(value) for value in all_values)
    final = {name: values[-1] for name, values in series.items() if values}
    max_abs = {
        name: max((abs(value) for value in values if math.isfinite(value)), default=0.0)
        for name, values in series.items()
    }
    return {
        "terminated_normally": normal_marker and not error_marker,
        "termination_marker": "error" if error_marker else "normal" if normal_marker else "missing",
        "finite": finite,
        "series": series,
        "final": final,
        "max_abs": max_abs,
    }


def evaluate_solver_result(text: str, mode: str) -> JSONDict:
    if mode not in {"impact", "quasi_static"}:
        raise ValueError("mode must be impact or quasi_static")
    parsed = parse_d3hsp(text)
    checks: list[JSONDict] = []

    def add(check_id: str, ok: bool, actual: object, limit: object | None = None) -> None:
        check: JSONDict = {"id": check_id, "ok": bool(ok), "actual": actual}
        if limit is not None:
            check["limit"] = limit
        checks.append(check)

    add("normal_termination", bool(parsed["terminated_normally"]), parsed["termination_marker"])
    add("finite_energies", bool(parsed["finite"]), parsed["finite"])

    internal_values = parsed["series"]["internal_energy"]
    finite_internal = [value for value in internal_values if math.isfinite(value)]
    internal_scale = max((abs(value) for value in finite_internal), default=0.0)
    negative_tolerance = max(1.0e-12, internal_scale * 1.0e-9)
    internal_nonnegative = bool(finite_internal) and len(finite_internal) == len(internal_values) and min(finite_internal) >= -negative_tolerance
    add(
        "internal_energy_nonnegative",
        internal_nonnegative,
        min(finite_internal) if finite_internal else None,
        {"minimum": -negative_tolerance},
    )

    max_hourglass = float(parsed["max_abs"].get("hourglass_energy", 0.0))
    if mode == "impact":
        energy_scale = float(parsed["max_abs"].get("total_energy", 0.0))
        if energy_scale <= 0.0:
            energy_scale = float(parsed["max_abs"].get("kinetic_energy", 0.0)) + internal_scale
    else:
        energy_scale = internal_scale
    hourglass_ratio = _safe_ratio(max_hourglass, energy_scale)
    add("hourglass_energy_ratio", math.isfinite(hourglass_ratio) and hourglass_ratio <= 0.1, hourglass_ratio, {"maximum": 0.1})

    metrics: JSONDict = {"hourglass_ratio": hourglass_ratio}
    if mode == "impact":
        final_ratio = parsed["final"].get("total_initial_ratio")
        ratio_ok = isinstance(final_ratio, float) and math.isfinite(final_ratio) and 0.9 <= final_ratio <= 1.1
        add("impact_total_energy_ratio", ratio_ok, final_ratio, {"minimum": 0.9, "maximum": 1.1})
        metrics["total_initial_ratio"] = final_ratio
    else:
        final_kinetic = parsed["final"].get("kinetic_energy")
        final_internal = parsed["final"].get("internal_energy")
        kinetic_internal_ratio = (
            _safe_ratio(abs(float(final_kinetic)), abs(float(final_internal)))
            if isinstance(final_kinetic, float) and isinstance(final_internal, float)
            else math.inf
        )
        add(
            "quasi_static_kinetic_internal_ratio",
            math.isfinite(kinetic_internal_ratio) and kinetic_internal_ratio <= 0.1,
            kinetic_internal_ratio,
            {"maximum": 0.1},
        )
        metrics["kinetic_internal_ratio"] = kinetic_internal_ratio

    return {
        "ok": all(check["ok"] for check in checks),
        "mode": mode,
        "checks": checks,
        "metrics": metrics,
        "parsed": parsed,
    }


def _parse_number(value: str) -> float:
    return float(value.replace("D", "E").replace("d", "e"))


def _safe_ratio(numerator: float, denominator: float) -> float:
    if not math.isfinite(numerator) or not math.isfinite(denominator):
        return math.inf
    if denominator <= 1.0e-30:
        return 0.0 if numerator <= 1.0e-30 else math.inf
    return numerator / denominator
