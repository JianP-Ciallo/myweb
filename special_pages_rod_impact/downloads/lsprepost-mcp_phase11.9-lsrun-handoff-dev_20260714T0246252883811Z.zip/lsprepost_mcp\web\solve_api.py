from __future__ import annotations

import subprocess
from datetime import datetime, timezone
from pathlib import Path

from lsprepost_mcp.config import JSONDict
from lsprepost_mcp.paths import find_project_dir
from lsprepost_mcp.web.config_api import configured_lsdyna_exe, configured_lsrun_exe, doctor_named_exe
from lsprepost_mcp.web.http_utils import ApiError


def open_lsrun_payload(payload: JSONDict) -> JSONDict:
    project_name = payload_project_name(payload)
    project = find_project_dir(project_name)
    model = project / "model.k"
    if not model.is_file():
        raise ApiError(400, "missing_model", "current project does not contain model.k")

    lsrun = configured_lsrun_exe()
    if lsrun is None:
        raise ApiError(400, "lsrun_not_configured", "LS-Run executable is not configured")
    doctor = doctor_named_exe(lsrun, ("lsrun",), require_name=True)
    if not doctor.ok:
        raise ApiError(400, "invalid_lsrun_path", "LS-Run path must be an existing lsrun*.exe file")

    lsdyna = configured_lsdyna_exe()
    command_preview = build_command_preview(model, lsdyna)
    record = launch_lsrun_handoff(project, model, lsrun)
    record.update(
        {
            "operation": "open_lsrun",
            "project_name": project.name,
            "input": str(model),
            "workdir": str(project),
            "lsrun_exe": str(lsrun),
            "lsdyna_exe": str(lsdyna) if lsdyna else "",
            "command_preview": command_preview,
        }
    )
    return record


def launch_lsrun_handoff(project: Path, model: Path, lsrun: Path) -> JSONDict:
    proc = subprocess.Popen(
        [str(lsrun)],
        cwd=str(project),
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        creationflags=getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0),
    )
    return {
        "pid": proc.pid,
        "started_at": datetime.now(timezone.utc).isoformat(),
    }


def build_command_preview(model: Path, lsdyna: Path | None) -> str:
    solver = str(lsdyna) if lsdyna else "<LS_DYNA_SOLVER_EXE>"
    return f'"{solver}" i="{model}" ncpu=4 memory=20m'


def payload_project_name(payload: JSONDict) -> str:
    raw = payload.get("project_name")
    if not isinstance(raw, str) or not raw.strip():
        raise ApiError(400, "invalid_project_name", "project_name must be a non-empty string")
    return raw.strip()
