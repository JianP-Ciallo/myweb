# 第七阶段示例：自然语言生成钢筋冲击头盔模型

本目录展示 `generate_scene_from_prompt` 的第一条闭环：用户输入自然语言工况，MCP 解析为受控 `rebar_drop_on_helmet` scene spec，生成 LS-DYNA `model.k`，并执行 LS-PrePost 导入校验和四视图导出。

## 输入 prompt

```text
生成一根1米长、半径12毫米的钢筋，从头盔上方10米自由落体，撞击固定在地面上的头盔
```

## 输出文件

- `model.k`：生成的 LS-DYNA keyword。
- `model.json`：解析后的结构化模型 spec。
- `checks.json`：静态校验结果。
- `phase7_scene_prompt_summary.json`：自然语言解析与验证摘要。
- `import_validation_iso.png`：导入后校验截图。
- `preview_summary.gif`：由 `iso/top/front` 三视图 PNG 合成的 GIF 预览摘要。
- `preview_iso.png`、`preview_top.png`、`preview_front.png`、`preview_side.png`：四视图预览。
- `keyword_reader_messages_*.xml`：LS-PrePost keyword reader 消息，当前 warnings/errors 均为空。

## 复现命令

```powershell
$env:LSPP_EXE = "<LS_PREPOST_EXE>"
@'
from lsprepost_mcp.tools import tool_generate_scene_from_prompt

tool_generate_scene_from_prompt({
    "project_name": "phase7_scene_prompt_rebar_helmet",
    "prompt": "生成一根1米长、半径12毫米的钢筋，从头盔上方10米自由落体，撞击固定在地面上的头盔",
    "run_lsprepost_validation": True,
    "export_previews": True,
    "export_preview_gif": True,
    "timeout_s": 45.0,
    "if_exists": "overwrite",
})
'@ | python -
```
