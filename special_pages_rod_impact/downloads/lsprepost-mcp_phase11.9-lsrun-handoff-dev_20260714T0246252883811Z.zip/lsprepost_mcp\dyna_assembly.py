from __future__ import annotations

from dataclasses import replace
import math

from .config import JSONDict
from .dyna_cards import common_header, database_lines, hourglass_lines, material_lines
from .dyna_common import Segment
from .dyna_conditions import boundary_and_load_lines
from .dyna_selectors import node_set_lines, part_set_lines, solid_segments_from_elements
from .preflight import grid_count
from .schema import ModelSpec


Node = tuple[int, float, float, float]
ShellElement = tuple[int, int, int, int, int, int]
SolidElement = tuple[int, int, int, int, int, int, int, int, int, int]


def build_assembly_scene(spec: ModelSpec) -> tuple[str, JSONDict]:
    parts: list[JSONDict] = []
    all_nodes: list[Node] = []
    shell_elements: list[ShellElement] = []
    solid_elements: list[SolidElement] = []
    section_lines: list[str] = []
    material_card_lines: list[str] = []
    set_and_condition_lines: list[str] = []
    contact_lines: list[str] = []

    next_node_id = 1
    next_shell_element_id = 1
    next_solid_element_id = 1
    next_part_id = 1
    next_section_id = 1
    next_material_id = 1
    next_set_id = 1001
    next_contact_id = 1

    component_nodes: dict[str, list[Node]] = {}
    component_part_sets: dict[str, int] = {}
    component_part_ids: dict[str, int] = {}
    component_element_family: dict[str, str] = {}

    for component in spec.components:
        component_id = str(component["id"])
        template = str(component["template"])
        pid = next_part_id
        secid = next_section_id
        mid = next_material_id
        next_part_id += 1
        next_section_id += 1
        next_material_id += 1

        local_nodes, local_shells, local_solids, section = build_component_geometry(component, pid)
        transformed_nodes = apply_transform(local_nodes, component)
        node_map = {old_nid: next_node_id + index for index, (old_nid, _, _, _) in enumerate(transformed_nodes)}
        nodes = [(node_map[nid], x, y, z) for nid, x, y, z in transformed_nodes]
        all_nodes.extend(nodes)
        component_nodes[component_id] = nodes

        if local_shells:
            for element in local_shells:
                shell_elements.append((next_shell_element_id, pid, *(node_map[nid] for nid in element[2:6])))
                next_shell_element_id += 1
            component_element_family[component_id] = "shell"
        if local_solids:
            for element in local_solids:
                solid_elements.append((next_solid_element_id, pid, *(node_map[nid] for nid in element[2:10])))
                next_solid_element_id += 1
            component_element_family[component_id] = "solid"
        next_node_id += len(nodes)

        title = f"{component_id}_{template}"
        part_metadata: JSONDict = {
            "id": component_id,
            "template": template,
            "part_id": pid,
            "section_id": secid,
            "material_id": mid,
            "element_family": component_element_family[component_id],
            "node_count": len(nodes),
            "node_ids": [nid for nid, _, _, _ in nodes],
            "node_id_range": [min(node_map.values()), max(node_map.values())],
            "mesh_size_m": float(component["mesh"]["size_m"]),
            "fixed_node_ids": [],
        }
        if section.get("type") == "shell":
            part_metadata["shell_thickness_m"] = float(section["thickness_m"])
        parts.append(part_metadata)
        section_lines.extend(part_lines(title, pid, secid, mid))
        section_lines.extend(section_lines_for_component(section, secid))
        component_spec = replace(spec, material={**component["material"], "id": mid})
        material_card_lines.extend(material_lines(component_spec))

        part_set_id = next_set_id
        next_set_id += 1
        set_and_condition_lines.extend(part_set_lines(part_set_id, f"component {component_id}", [pid]))
        component_part_sets[component_id] = part_set_id
        component_part_ids[component_id] = pid

        fixed_node_ids: set[int] = set()
        for face in component.get("fixed_faces", []):
            node_ids = nodes_for_component_face(nodes, str(face))
            fixed_node_ids.update(node_ids)
            nsid = next_set_id
            next_set_id += 1
            set_and_condition_lines.extend(node_set_lines(nsid, f"{component_id} fixed {face}", node_ids))
            set_and_condition_lines.extend(
                [
                    "*BOUNDARY_SPC_SET",
                    "$#  nsid       cid      dofx      dofy      dofz     dofrx     dofry     dofrz",
                    f"{nsid},0,1,1,1,1,1,1",
                ]
            )
        part_metadata["fixed_node_ids"] = sorted(fixed_node_ids)

        if "initial_velocity_m_per_s" in component:
            vx, vy, vz = [float(value) for value in component["initial_velocity_m_per_s"]]
            set_and_condition_lines.extend(
                [
                    "*INITIAL_VELOCITY_NODE",
                    "$#   nid        vx        vy        vz       vxr       vyr       vzr",
                ]
            )
            set_and_condition_lines.extend(f"{nid},{vx:.9g},{vy:.9g},{vz:.9g},0.0,0.0,0.0" for nid, _, _, _ in nodes)

    controlled_contacts: list[str] = []
    for contact in spec.contacts:
        slave = str(contact["slave"])
        master = str(contact["master"])
        contact_type = str(contact["type"])
        friction = float(contact.get("friction", 0.0))
        if contact_type == "automatic_nodes_to_surface":
            card = "*CONTACT_AUTOMATIC_NODES_TO_SURFACE"
            slave_face = str(contact.get("slave_face", "z_min"))
            slave_node_ids = nodes_for_component_face(component_nodes[slave], slave_face)
            slave_node_set = next_set_id
            next_set_id += 1
            contact_lines.extend(node_set_lines(slave_node_set, f"contact slave {slave} {slave_face}", slave_node_ids))
            contact_lines.extend(
                [
                    card,
                    f"$ controlled contact {next_contact_id}: {slave} nodes -> {master} surface",
                    "$#   ssid      msid     sstyp     mstyp    sboxid    mboxid      spr      mpr",
                    f"{slave_node_set},{component_part_sets[master]},4,2,0,0,0,0",
                    "$#     fs        fd        dc        vc       vdc    penchk        bt        dt",
                    f"{friction:.9g},{friction:.9g},0.0,0.0,0.0,0,0.0,0.0",
                    "$#    sfs       sfm       sst       mst      sfst      sfmt       fsf       vsf",
                    "1.0,1.0,0.0,0.0,1.0,1.0,1.0,1.0",
                ]
            )
        else:
            card = "*CONTACT_AUTOMATIC_SURFACE_TO_SURFACE"
            contact_lines.extend(
                [
                    card,
                    f"$ controlled contact {next_contact_id}: {slave} -> {master}",
                    "$#   ssid      msid     sstyp     mstyp    sboxid    mboxid      spr      mpr",
                    f"{component_part_sets[slave]},{component_part_sets[master]},2,2,0,0,0,0",
                    "$#     fs        fd        dc        vc       vdc    penchk        bt        dt",
                    f"{friction:.9g},{friction:.9g},0.0,0.0,0.0,0,0.0,0.0",
                    "$#    sfs       sfm       sst       mst      sfst      sfmt       fsf       vsf",
                    "1.0,1.0,0.0,0.0,1.0,1.0,1.0,1.0",
                ]
            )
        controlled_contacts.append(card)
        next_contact_id += 1

    lines = common_header(spec)
    lines.extend(["*NODE", "$#   nid               x               y               z"])
    lines.extend(f"{nid},{x:.9g},{y:.9g},{z:.9g}" for nid, x, y, z in all_nodes)
    if shell_elements:
        lines.extend(["*ELEMENT_SHELL", "$#   eid     pid      n1      n2      n3      n4"])
        lines.extend(",".join(str(value) for value in element) for element in shell_elements)
    if solid_elements:
        lines.extend(["*ELEMENT_SOLID", "$#   eid     pid      n1      n2      n3      n4      n5      n6      n7      n8"])
        lines.extend(",".join(str(value) for value in element) for element in solid_elements)
    lines.extend(section_lines)
    lines.extend(hourglass_lines(spec))
    lines.extend(material_card_lines)
    lines.extend(set_and_condition_lines)
    if spec.loads:
        condition_lines, condition_metadata = boundary_and_load_lines(spec, all_nodes, all_segments(shell_elements, solid_elements))
        lines.extend(condition_lines)
    else:
        condition_metadata = empty_condition_metadata()
    lines.extend(contact_lines)
    lines.append("*END")

    fixed_count = sum(len(component.get("fixed_faces", [])) for component in spec.components)
    contact_node_set_count = sum(1 for contact in spec.contacts if contact.get("type") == "automatic_nodes_to_surface")
    initial_velocity_count = sum(1 for component in spec.components if "initial_velocity_m_per_s" in component)
    metadata = {
        "unit_system": spec.unit_system,
        "model_type": spec.model_type,
        "element_family": "mixed" if shell_elements and solid_elements else ("shell" if shell_elements else "solid"),
        "node_count": len(all_nodes),
        "element_count": len(shell_elements) + len(solid_elements),
        "shell_element_count": len(shell_elements),
        "solid_element_count": len(solid_elements),
        "part_count": len(parts),
        "material_count": len(parts),
        "section_count": len(parts),
        "constraint_count": fixed_count + int(condition_metadata.get("constraint_count", 0)),
        "node_set_count": fixed_count + contact_node_set_count + int(condition_metadata.get("node_set_count", 0)),
        "part_set_count": len(component_part_sets) + int(condition_metadata.get("part_set_count", 0)),
        "segment_set_count": int(condition_metadata.get("segment_set_count", 0)),
        "load_count": int(condition_metadata.get("load_count", 0)),
        "initial_condition_count": initial_velocity_count + int(condition_metadata.get("initial_condition_count", 0)),
        "curve_count": int(condition_metadata.get("curve_count", 0)),
        "hourglass_count": 1 if spec.hourglass else 0,
        "control_count": 1 + sum(1 for key in ["energy", "shell", "timestep"] if isinstance(spec.analysis_control.get(key), dict)),
        "database_count": 1 + int("d3thdt_dt_s" in spec.database) + int(isinstance(spec.database.get("extent_binary"), dict)) + int("format" in spec.database),
        "contact_count": len(spec.contacts),
        "controlled_contact_cards": sorted(set(controlled_contacts)),
        "components": parts,
    }
    return "\n".join(lines) + "\n", metadata


def build_component_geometry(component: JSONDict, pid: int) -> tuple[list[Node], list[ShellElement], list[SolidElement], JSONDict]:
    template = str(component["template"])
    if template == "shell_plate":
        return build_shell_plate_component(component, pid)
    if template == "solid_cylinder":
        return build_solid_cylinder_component(component, pid)
    if template == "ellipsoid_shell":
        return build_ellipsoid_shell_component(component, pid)
    raise ValueError(f"unsupported component template: {template}")


def build_shell_plate_component(component: JSONDict, pid: int) -> tuple[list[Node], list[ShellElement], list[SolidElement], JSONDict]:
    geometry = component["geometry"]
    mesh = component["mesh"]
    length = float(geometry["length_m"])
    width = float(geometry["width_m"])
    thickness = float(geometry["thickness_m"])
    mesh_size = float(mesh["size_m"])
    nx = grid_count(length, mesh_size)
    ny = grid_count(width, mesh_size)
    dx = length / nx
    dy = width / ny
    nodes = [(iy * (nx + 1) + ix + 1, ix * dx, iy * dy, 0.0) for iy in range(ny + 1) for ix in range(nx + 1)]
    elements: list[ShellElement] = []
    eid = 1
    for iy in range(ny):
        for ix in range(nx):
            n1 = iy * (nx + 1) + ix + 1
            elements.append((eid, pid, n1, n1 + 1, n1 + nx + 2, n1 + nx + 1))
            eid += 1
    return nodes, elements, [], {"type": "shell", "thickness_m": thickness}


def build_solid_cylinder_component(component: JSONDict, pid: int) -> tuple[list[Node], list[ShellElement], list[SolidElement], JSONDict]:
    geometry = component["geometry"]
    mesh = component["mesh"]
    radius = float(geometry["radius_m"])
    length = float(geometry["length_m"])
    mesh_size = float(mesh["size_m"])
    nxy = max(8, 2 * grid_count(radius, mesh_size))
    nz = grid_count(length, mesh_size)
    dz = length / nz

    nodes: list[Node] = []

    def get_node(ix: int, iy: int, iz: int) -> int:
        return iz * (nxy + 1) * (nxy + 1) + iy * (nxy + 1) + ix + 1

    for iz in range(nz + 1):
        z = iz * dz
        for iy in range(nxy + 1):
            v = -1.0 + 2.0 * iy / nxy
            for ix in range(nxy + 1):
                u = -1.0 + 2.0 * ix / nxy
                x, y = square_to_disk(radius, u, v)
                nodes.append((get_node(ix, iy, iz), x, y, z))

    elements: list[SolidElement] = []
    for iz in range(nz):
        for iy in range(nxy):
            for ix in range(nxy):
                elements.append(
                    (
                        len(elements) + 1,
                        pid,
                        get_node(ix, iy, iz),
                        get_node(ix + 1, iy, iz),
                        get_node(ix + 1, iy + 1, iz),
                        get_node(ix, iy + 1, iz),
                        get_node(ix, iy, iz + 1),
                        get_node(ix + 1, iy, iz + 1),
                        get_node(ix + 1, iy + 1, iz + 1),
                        get_node(ix, iy + 1, iz + 1),
                    )
                )
    return nodes, [], elements, {"type": "solid", "mesh_method": "mapped_square_to_disk_hexa_cylinder", "nxy": nxy, "nz": nz}


def square_to_disk(radius: float, u: float, v: float) -> tuple[float, float]:
    x = radius * u * math.sqrt(max(0.0, 1.0 - 0.5 * v * v))
    y = radius * v * math.sqrt(max(0.0, 1.0 - 0.5 * u * u))
    return x, y


def build_ellipsoid_shell_component(component: JSONDict, pid: int) -> tuple[list[Node], list[ShellElement], list[SolidElement], JSONDict]:
    geometry = component["geometry"]
    mesh = component["mesh"]
    rx = float(geometry["radius_x_m"])
    ry = float(geometry["radius_y_m"])
    height = float(geometry["height_m"])
    thickness = float(geometry["thickness_m"])
    mesh_size = float(mesh["size_m"])
    nt = max(12, round(2.0 * math.pi * max(rx, ry) / mesh_size))
    nz = max(3, grid_count(height, mesh_size))

    nodes: list[Node] = []
    for iz in range(nz):
        t = iz / nz
        z = height * t
        scale = math.sqrt(max(1.0 - t * t, 0.0))
        for it in range(nt):
            angle = 2.0 * math.pi * it / nt
            nodes.append((iz * nt + it + 1, rx * scale * math.cos(angle), ry * scale * math.sin(angle), z))
    top_node = len(nodes) + 1
    nodes.append((top_node, 0.0, 0.0, height))

    elements: list[ShellElement] = []
    eid = 1
    for iz in range(nz - 1):
        for it in range(nt):
            n1 = iz * nt + it + 1
            n2 = iz * nt + ((it + 1) % nt) + 1
            n3 = (iz + 1) * nt + ((it + 1) % nt) + 1
            n4 = (iz + 1) * nt + it + 1
            elements.append((eid, pid, n1, n2, n3, n4))
            eid += 1
    last_ring = (nz - 1) * nt
    for it in range(nt):
        n1 = last_ring + it + 1
        n2 = last_ring + ((it + 1) % nt) + 1
        elements.append((eid, pid, n1, n2, top_node, top_node))
        eid += 1
    return nodes, elements, [], {"type": "shell", "thickness_m": thickness}


def apply_transform(nodes: list[Node], component: JSONDict) -> list[Node]:
    transform = component.get("transform", {})
    oriented = [apply_orientation_to_node(node, str(transform.get("orientation", "vertical_z"))) for node in nodes]
    rotated = [apply_euler_rotation_to_node(node, transform.get("rotate_deg", [0.0, 0.0, 0.0])) for node in oriented]
    positioned = apply_centering(rotated, transform.get("center_m"))
    tx, ty, tz = [float(value) for value in transform.get("translate_m", [0.0, 0.0, 0.0])]
    return [(nid, x + tx, y + ty, z + tz) for nid, x, y, z in positioned]


def apply_orientation_to_node(node: Node, orientation: str) -> Node:
    nid, x, y, z = node
    if orientation == "vertical_x":
        return nid, z, y, -x
    if orientation == "vertical_y":
        return nid, x, z, -y
    return node


def apply_euler_rotation_to_node(node: Node, rotate_deg: object) -> Node:
    nid, x, y, z = node
    if not isinstance(rotate_deg, list | tuple) or len(rotate_deg) != 3:
        return node
    rx, ry, rz = [math.radians(float(value)) for value in rotate_deg]
    cy, sy = math.cos(rx), math.sin(rx)
    y, z = y * cy - z * sy, y * sy + z * cy
    cy, sy = math.cos(ry), math.sin(ry)
    x, z = x * cy + z * sy, -x * sy + z * cy
    cy, sy = math.cos(rz), math.sin(rz)
    x, y = x * cy - y * sy, x * sy + y * cy
    return nid, x, y, z


def apply_centering(nodes: list[Node], center_m: object) -> list[Node]:
    if not isinstance(center_m, list | tuple) or len(center_m) != 3:
        return nodes
    min_x, max_x, min_y, max_y, min_z, max_z = bounds(nodes)
    cx, cy, cz = (0.5 * (min_x + max_x), 0.5 * (min_y + max_y), 0.5 * (min_z + max_z))
    target_x, target_y, target_z = [float(value) for value in center_m]
    dx, dy, dz = target_x - cx, target_y - cy, target_z - cz
    return [(nid, x + dx, y + dy, z + dz) for nid, x, y, z in nodes]


def bounds(nodes: list[Node]) -> tuple[float, float, float, float, float, float]:
    xs = [x for _, x, _, _ in nodes]
    ys = [y for _, _, y, _ in nodes]
    zs = [z for _, _, _, z in nodes]
    return min(xs), max(xs), min(ys), max(ys), min(zs), max(zs)


def nodes_for_component_face(nodes: list[Node], face: str) -> list[int]:
    axis_map = {"x": 1, "y": 2, "z": 3}
    axis_name, side = face.split("_", 1)
    axis = axis_map[axis_name]
    values = [node[axis] for node in nodes]
    target = min(values) if side == "min" else max(values)
    span = max(values) - min(values)
    tol = max(abs(span) * 1e-9, 1e-12)
    selected = [nid for nid, x, y, z in nodes if abs((x, y, z)[axis - 1] - target) <= tol]
    if not selected:
        raise ValueError(f"component face {face} selected no nodes")
    return selected


def part_lines(title: str, pid: int, secid: int, mid: int) -> list[str]:
    return [
        "*PART",
        title,
        "$#   pid     secid       mid     eosid      hgid      grav    adpopt      tmid",
        f"{pid},{secid},{mid},0,0,0,0,0",
    ]


def section_lines_for_component(section: JSONDict, secid: int) -> list[str]:
    if section["type"] == "shell":
        thickness = float(section["thickness_m"])
        return [
            "*SECTION_SHELL",
            "$# secid    elform      shrf       nip     propt   qr/irid     icomp     setyp",
            f"{secid},2,0.833000,5,1.0,0,0,0",
            "$#     t1        t2        t3        t4      nloc     marea",
            f"{thickness:.9g},{thickness:.9g},{thickness:.9g},{thickness:.9g},0.0,0.0",
        ]
    return [
        "*SECTION_SOLID",
        "$# secid    elform",
        f"{secid},1",
    ]


def all_segments(shell_elements: list[ShellElement], solid_elements: list[SolidElement]) -> list[Segment]:
    shell_segments = [(n1, n2, n3, n4) for _, _, n1, n2, n3, n4 in shell_elements]
    return shell_segments + solid_segments_from_elements(solid_elements)


def empty_condition_metadata() -> JSONDict:
    return {
        "constraint_count": 0,
        "node_set_count": 0,
        "part_set_count": 0,
        "segment_set_count": 0,
        "load_count": 0,
        "initial_condition_count": 0,
        "curve_count": 0,
    }
