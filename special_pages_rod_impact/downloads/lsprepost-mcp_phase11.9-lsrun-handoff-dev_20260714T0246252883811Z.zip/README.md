# lsprepost-mcp

`lsprepost-mcp` 是一个本地运行的 LS-PrePost / LS-DYNA keyword 受控建模工具。它提供 Web App 和 MCP 两种入口，用项目内白名单场景、模板和校验流程生成 `model.k`，并支持三维预览、LS-PrePost 复核及 LS-Run 交接。

它不是完整的 LS-DYNA 前处理器，也不支持开放式任意建模。真实工程使用前，仍需由具备经验的人员检查单位、材料、网格、接触、约束、载荷和求解设置。

## 一键启动

环境要求：

- Windows 10/11。
- Python 3.10 或更高版本，且 `python` 命令可用。
- 建议安装 LS-PrePost；需要求解交接时再准备 LS-Run 和 LS-DYNA 求解器。
- 可选安装 Pillow；只有 GIF 合成功能需要它。

解压后双击根目录中的：

```text
start_web_app.cmd
```

浏览器将打开：

```text
http://127.0.0.1:8765/
```

这个地址只供当前电脑访问，不需要把项目部署到互联网。关闭启动命令窗口后，Web App 也会停止。

## Web App 使用流程

1. 在左侧点击“导入 LS-PrePost”，选择本机真实存在的 `lsprepost*.exe`。
2. 选择受控场景，填写尺寸、材料、网格、载荷或冲击速度。
3. 先确认生成摘要，再点击“生成模型”。
4. 在中央三维视窗中拖动、缩放、切换视角和显示部件。
5. 查看校验摘要；需要时保存模型副本或打开 LS-PrePost 人工复核。
6. 需要求解交接时，在右侧点击“导入 LS-Run”和“导入 LS-DYNA 求解器”，再点击“送入 LS-Run”。

本机程序路径只写入：

```text
generated_configs\web_app.local.json
```

该文件不应随压缩包分发。

每个生成项目通常包含：

```text
model.k
model.json
checks.json
open_model.cfile
```

导出到用户指定目录时，还会生成 `export_manifest.json`。

## 当前受控场景

- 钢筋以给定初速度冲击固定椭球头盔壳：可填写钢筋尺寸、初始间距、冲击速度、头盔尺寸和材料。
- 圆柱杆以给定初速度冲击固定钢板：可填写杆件、钢板、材料、网格和冲击速度。
- 立方体底部固定、顶面四角向下受载：可填写尺寸、材料、网格和集中载荷。
- 壳板固定边界、承受均布压力：可填写板长宽厚、材料、网格、压力和固定边界。

以上场景生成的是受控模板模型，不应被描述为任意几何或任意工况生成能力。

## LS-Run 交接边界

当前 Web App 会校验并保存本机 `lsrun.exe` 与 LS-DYNA 求解器路径，然后打开 LS-Run。使用者仍需在 LS-Run 中核对 `model.k`、求解器、CPU、内存和工作目录后手动启动任务。

当前能力不自动把所有字段填入 LS-Run，不自动提交 LS-DYNA 求解，不自动监控任务，也不自动判断应力、损伤、贯穿或失效结果。求解完成后，应在 LS-PrePost 中打开 `d3plot` 等结果文件进行检查。

## AI IDE / MCP

把项目交给 Codex、Cursor、VS Code 等 AI IDE 时，先让它阅读：

```text
AI_IDE_START_HERE.zh-CN.md
README.zh-CN.md
```

AI IDE 必须遵守：

- 不修改项目源代码、脚本、模板、材料库和测试。
- 不直接手写、编辑或覆盖 `.k`、`.key`、`.dyn` 文件。
- 所有 keyword 文件都必须由本项目的受控生成流程产生。
- 只调用项目提供的生成、校验、预览和打开工具。

MCP 配置、统一启动词和工具说明见 [README.zh-CN.md](README.zh-CN.md)。

## 开发与复核

运行完整测试：

```powershell
python -m unittest discover -s tests
```

检查 Python 文件：

```powershell
python -m compileall -q .\lsprepost_mcp
```

生成带测试和开发文档的审查包：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\pack.ps1 -BuildLabel "phase11.9-lsrun-handoff-dev"
```

输出位于 `dist\`。包名带时间戳，不覆盖旧版本；`PACKAGE_MANIFEST.txt` 记录包内文件的 SHA256。

## 重要限制

- `checks.ok` 只表示本项目静态校验通过，不代表 LS-DYNA 求解成功。
- 内置材料参数是名义值，正式分析前必须复核材料模型和参数来源。
- 自动 PNG/GIF 预览受 LS-PrePost 版本影响；导图失败不等于 `model.k` 生成失败。
- Web 三维视窗用于生成前后检查几何和部件，不替代 LS-PrePost 的 keyword、接触、边界条件和结果复核。
- 当前 LS-Run 功能是本地交接入口，不是求解队列管理器或结果分析器。

更多分发、测试和兼容说明见 `docs\`。
