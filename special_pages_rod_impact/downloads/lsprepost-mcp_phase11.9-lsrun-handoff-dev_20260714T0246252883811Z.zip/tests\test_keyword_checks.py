from __future__ import annotations

import unittest
import tempfile

from lsprepost_mcp.dyna_keyword import build_keyword
from lsprepost_mcp.keyword_checks import keyword_quality_checks
from lsprepost_mcp.schema import default_model_spec, parse_model_spec, rod_impact_plate_spec


class KeywordQualityTests(unittest.TestCase):
    def test_generated_shell_plate_has_quality_estimates(self) -> None:
        raw = default_model_spec("quality_plate", "shell_plate")
        keyword, metadata = build_keyword(parse_model_spec(raw))
        checks = keyword_quality_checks(keyword, raw, metadata)
        by_id = {item["id"]: item for item in checks}
        self.assertTrue(by_id["quality.geometry.shell_area"]["ok"])
        self.assertTrue(by_id["quality.geometry.shell_normals"]["ok"])
        self.assertTrue(by_id["quality.topology.orphan_nodes"]["ok"])
        self.assertTrue(by_id["quality.estimate.mass"]["ok"])
        self.assertTrue(by_id["quality.estimate.stable_timestep"]["ok"])
        self.assertGreater(by_id["quality.estimate.mass"]["actual"]["mass_kg"], 0.0)
        self.assertGreater(by_id["quality.estimate.stable_timestep"]["actual"]["stable_dt_s"], 0.0)

    def test_assembly_shell_thickness_ratio_uses_component_mesh(self) -> None:
        spec = parse_model_spec(rod_impact_plate_spec("quality_rod_plate_ratio"))
        keyword, metadata = build_keyword(spec)
        checks = keyword_quality_checks(keyword, spec.__dict__, metadata)
        by_id = {item["id"]: item for item in checks}
        ratio = by_id["quality.shell.component.plate.thickness_mesh_ratio"]
        self.assertTrue(ratio["ok"])
        self.assertAlmostEqual(ratio["actual"], 0.08)

    def test_assembly_check_rejects_fully_fixed_shell_component(self) -> None:
        raw = rod_impact_plate_spec("quality_fully_fixed_plate")
        plate = next(component for component in raw["components"] if component["id"] == "plate")
        plate["fixed_faces"] = ["z_min"]
        spec = parse_model_spec(raw)
        keyword, metadata = build_keyword(spec)
        checks = keyword_quality_checks(keyword, spec.__dict__, metadata)
        by_id = {item["id"]: item for item in checks}
        result = by_id["quality.assembly.component.plate.deformable_nodes"]
        self.assertFalse(result["ok"])
        self.assertEqual(result["actual"]["fixed_node_count"], result["actual"]["node_count"])

    def test_detects_missing_node_reference_and_duplicate_node_id(self) -> None:
        keyword = """*KEYWORD
*NODE
1,0,0,0
1,1,0,0
2,1,1,0
3,0,1,0
*ELEMENT_SHELL
1,1,1,2,3,99
*PART
part
1,1,1,0,0,0,0,0
*SECTION_SHELL
1,2
0.001,0.001,0.001,0.001
*MAT_ELASTIC
1,7850,2.1e11,0.3
*END
"""
        checks = keyword_quality_checks(keyword, {"model_type": "shell_plate", "mesh": {"size_m": 0.01}}, {})
        by_id = {item["id"]: item for item in checks}
        self.assertFalse(by_id["quality.id.nodes_unique"]["ok"])
        self.assertFalse(by_id["quality.ref.element_nodes"]["ok"])

    def test_rejects_embedded_end_before_final_end(self) -> None:
        keyword = """*KEYWORD
*NODE
1,0,0,0
*END
*MAT_ELASTIC
1,7850,2.1e11,0.3
*END
"""
        checks = keyword_quality_checks(keyword, {"model_type": "imported_keyword"}, {})
        by_id = {item["id"]: item for item in checks}
        self.assertFalse(by_id["quality.keyword.boundary"]["ok"])

    def test_rejects_fake_keyword_and_end_cards(self) -> None:
        keyword = """*KEYWORD_NOT_REAL
*NODE
1,0,0,0
*END_NOT_REAL
"""
        checks = keyword_quality_checks(keyword, {"model_type": "imported_keyword"}, {})
        by_id = {item["id"]: item for item in checks}
        self.assertFalse(by_id["quality.keyword.boundary"]["ok"])

    def test_detects_direct_load_segment_that_is_not_an_element_face(self) -> None:
        keyword = """*KEYWORD
*NODE
1,0,0,0
2,1,0,0
3,1,1,0
4,0,1,0
5,0,0,1
6,1,0,1
7,1,1,1
8,0,1,1
*ELEMENT_SOLID
1,1,1,2,3,4,5,6,7,8
*PART
part
1,1,1,0,0,0,0,0
*SECTION_SOLID
1,1
*MAT_ELASTIC
1,7850,2.1e11,0.3
*LOAD_SEGMENT
1,1.0,0.0,1,2,3,5
*END
"""
        checks = keyword_quality_checks(keyword, {"model_type": "solid_block"}, {})
        by_id = {item["id"]: item for item in checks}
        self.assertFalse(by_id["quality.topology.load_segments_on_faces"]["ok"])

    def test_detects_inverted_solid_center_jacobian(self) -> None:
        keyword = """*KEYWORD
*NODE
1,0,0,0
2,1,0,0
3,1,1,0
4,0,1,0
5,0,0,1
6,1,0,1
7,1,1,1
8,0,1,1
*ELEMENT_SOLID
1,1,1,4,3,2,5,8,7,6
*PART
part
1,1,1,0,0,0,0,0
*SECTION_SOLID
1,1
*MAT_ELASTIC
1,7850,2.1e11,0.3
*END
"""
        checks = keyword_quality_checks(keyword, {"model_type": "solid_block"}, {})
        by_id = {item["id"]: item for item in checks}
        self.assertFalse(by_id["quality.geometry.solid_volume"]["ok"])

    def test_detects_high_solid_aspect_ratio(self) -> None:
        keyword = """*KEYWORD
*NODE
1,0,0,0
2,20,0,0
3,20,1,0
4,0,1,0
5,0,0,1
6,20,0,1
7,20,1,1
8,0,1,1
*ELEMENT_SOLID
1,1,1,2,3,4,5,6,7,8
*PART
part
1,1,1,0,0,0,0,0
*SECTION_SOLID
1,1
*MAT_ELASTIC
1,7850,2.1e11,0.3
*END
"""
        checks = keyword_quality_checks(keyword, {"model_type": "solid_block"}, {})
        by_id = {item["id"]: item for item in checks}
        self.assertTrue(by_id["quality.geometry.solid_volume"]["ok"])
        self.assertFalse(by_id["quality.geometry.solid_aspect_ratio"]["ok"])

    def test_detects_shell_warpage_and_aspect_ratio(self) -> None:
        keyword = """*KEYWORD
*NODE
1,0,0,0
2,20,0,0
3,20,1,1
4,0,1,0
*ELEMENT_SHELL
1,1,1,2,3,4
*PART
part
1,1,1,0,0,0,0,0
*SECTION_SHELL
1,2
0.001,0.001,0.001,0.001
*MAT_ELASTIC
1,7850,2.1e11,0.3
*END
"""
        checks = keyword_quality_checks(keyword, {"model_type": "shell_plate", "mesh": {"size_m": 1.0}}, {})
        by_id = {item["id"]: item for item in checks}
        self.assertFalse(by_id["quality.geometry.shell_warpage"]["ok"])
        self.assertFalse(by_id["quality.geometry.shell_aspect_ratio"]["ok"])

    def test_estimates_timestep_from_advanced_material_wave_speed(self) -> None:
        raw = default_model_spec("quality_concrete", "single_solid_element_test")
        raw["material"] = {
            "name": "confirmed_concrete",
            "type": "cscm_concrete",
            "density_kg_per_m3": 2300.0,
            "fpc_pa": 50000000.0,
            "wave_speed_m_per_s": 4200.0,
            "source": "unit test",
            "confirmed_by_user": True,
        }
        raw["boundary_conditions"] = [{"type": "spc_node_set", "node_ids": [1], "dofs": ["x", "y", "z"]}]
        spec = parse_model_spec(raw)
        keyword, metadata = build_keyword(spec)
        checks = keyword_quality_checks(keyword, spec.__dict__, metadata)
        by_id = {item["id"]: item for item in checks}
        self.assertTrue(by_id["quality.estimate.stable_timestep"]["ok"])
        self.assertGreater(by_id["quality.estimate.stable_timestep"]["actual"]["stable_dt_s"], 0.0)

    def test_detects_missing_include_parameter_and_contact_cards(self) -> None:
        keyword = """*KEYWORD
*INCLUDE
missing_mesh.k
*PARAMETER
R defined_value 1.0
*NODE
1,0,0,&missing_value
2,1,0,0
3,1,1,0
4,0,1,0
*ELEMENT_SHELL
1,1,1,2,3,4
*PART
part
1,1,1,0,0,0,0,0
*SECTION_SHELL
1,2
0.001,0.001,0.001,0.001
*MAT_ELASTIC
1,7850,2.1e11,0.3
*CONTACT_AUTOMATIC_SINGLE_SURFACE
*END
"""
        with tempfile.TemporaryDirectory() as tmp:
            checks = keyword_quality_checks(keyword, {"model_type": "imported_keyword"}, {"_project_dir": tmp})
        by_id = {item["id"]: item for item in checks}
        self.assertFalse(by_id["quality.keyword.include_paths"]["ok"])
        self.assertFalse(by_id["quality.keyword.parameters"]["ok"])
        self.assertFalse(by_id["quality.unsupported.contact_cards"]["ok"])

    def test_allows_generator_controlled_contact_cards(self) -> None:
        keyword = """*KEYWORD
*NODE
1,0,0,0
2,1,0,0
3,1,1,0
4,0,1,0
*ELEMENT_SHELL
1,1,1,2,3,4
*PART
plate
1,1,1,0,0,0,0,0
*SECTION_SHELL
1,2,0.833,5,1,0,0,0
0.001,0.001,0.001,0.001,0,0
*MAT_ELASTIC
1,7850,2.1e11,0.3
*CONTACT_AUTOMATIC_SURFACE_TO_SURFACE
1001,1002,2,2,0,0,0,0
0.2,0.2,0,0,0,0,0,0
*END
"""
        checks = keyword_quality_checks(
            keyword,
            {"model_type": "assembly_scene", "mesh": {"size_m": 0.01}},
            {"controlled_contact_cards": ["*CONTACT_AUTOMATIC_SURFACE_TO_SURFACE"]},
        )
        by_id = {item["id"]: item for item in checks}
        self.assertTrue(by_id["quality.unsupported.contact_cards"]["ok"])


if __name__ == "__main__":
    unittest.main()
