# 第一到第六阶段能力示例：钢筋自由落体冲击椭球头盔

本目录保存一个完整示例，用于展示 `lsprepost-mcp` 从结构化建模、静态校验到 LS-PrePost 自动预览导出的阶段能力。

## 案例目标

生成一根实体钢筋和一个固定在地面上的简化椭球壳头盔：

- 钢筋：实体圆柱，长度 `1.0 m`，半径 `0.012 m`。
- 钢筋网格：使用圆边界映射六面体实体网格，不再使用体素化小方块近似。
- 初始位置：钢筋位于头盔上方约 `10 m`，保持竖直。
- 头盔：椭球壳，带 shell 厚度，顶部封闭。
- 工况：头盔固定，钢筋初始速度为 `0`，通过 `*LOAD_BODY_Z` 施加重力，由 LS-DYNA 后续求解自由下落和冲击。
- 接触：钢筋与头盔之间使用受控面面接触。
- 输出：包含 `d3plot` 输出控制，便于后续在 LS-PrePost 查看。

当前示例只展示建模、校验和 LS-PrePost 预览导出闭环；不自动运行 LS-DYNA，不自动判断是否贯穿。

## 阶段能力映射

| 阶段 | 本案例体现 |
|---|---|
| 第一阶段 | 生成项目文件：`model.json`、`model.k`、`checks.json` |
| 第二阶段 | 使用几何生成能力：实体圆柱钢筋、椭球壳头盔 |
| 第三阶段 | 使用材料库和统一 SI 单位制 |
| 第四阶段 | 添加重力、固定约束、输出控制等物理信息 |
| 第五阶段 | 运行静态 keyword 校验，生成结构化检查结果 |
| 第 5.1 阶段 | 使用组件装配层生成多 part 场景，并加入受控接触 |
| 第六阶段 | 通过受控 LS-PrePost cfile 完成导入校验、keyword reader 检查、单图与批量多视图 PNG 导出 |

## 文件清单

- `model.k`：生成的 LS-DYNA keyword 文件。
- `model.json`：结构化模型 spec 和生成 metadata。
- `checks.json`：静态校验结果，当前 `ok=true`，`readiness.ok_for_solver_draft=true`。
- `preview.png`：默认等轴测预览图。
- `preview_iso.png`、`preview_top.png`、`preview_front.png`、`preview_side.png`：由 `export_preview_images` 批量导出的四个受控视图。
- `import_validation_iso.png`：由 `validate_lsprepost_import` 导出的导入后验收截图。
- `keyword_reader_messages_preview_*.xml`：每张预览图对应的 LS-PrePost keyword reader 消息，当前 `Warnings` 和 `Errors` 均为空。
- `keyword_reader_messages_import_validation_iso.xml`：导入后验收截图对应的 keyword reader 消息。
- `summary.json`：模型摘要。
- `cfiles.json`：服务端生成 cfile 的 manifest/provenance。
- `lspp_verifications.json`：LS-PrePost 自动化验证记录。

## 复现实例

在项目根目录运行：

```powershell
$env:LSPP_EXE = "<LS_PREPOST_EXE>"
@'
from lsprepost_mcp.project_store import write_model_project
from lsprepost_mcp.schema import parse_model_spec, rebar_drop_on_helmet_spec
from lsprepost_mcp.tools import tool_export_preview_images, tool_validate_lsprepost_import

name = "case_phase1_to_phase6_rebar_helmet"
write_model_project(parse_model_spec(rebar_drop_on_helmet_spec(name)), if_exists="overwrite")
tool_export_preview_images({"project_name": name, "timeout_s": 45.0})
tool_validate_lsprepost_import({"project_name": name, "timeout_s": 45.0})
'@ | python -
```

也可以通过 MCP 工具执行同等流程。
