from __future__ import annotations

import unittest

from lsprepost_mcp.solver_results import evaluate_solver_result, parse_d3hsp


def d3hsp_block(
    *,
    kinetic: str = "2.0",
    internal: str = "100.0",
    hourglass: str = "3.0",
    total: str = "105.0",
    ratio: str = "1.0",
    terminated: bool = True,
) -> str:
    termination = "*** termination time reached ***" if terminated else ""
    return f"""
 kinetic energy.................   {kinetic}
 internal energy................   {internal}
 hourglass energy ..............   {hourglass}
 total energy...................   {total}
 total energy / initial energy..   {ratio}
 {termination}
"""


class SolverResultTests(unittest.TestCase):
    def test_parse_d3hsp_extracts_final_and_max_energy(self) -> None:
        text = d3hsp_block(internal="50.0", hourglass="2.0") + d3hsp_block(internal="100.0", hourglass="7.0")
        parsed = parse_d3hsp(text)
        self.assertTrue(parsed["terminated_normally"])
        self.assertEqual(parsed["final"]["internal_energy"], 100.0)
        self.assertEqual(parsed["max_abs"]["hourglass_energy"], 7.0)
        self.assertTrue(parsed["finite"])

    def test_accepts_valid_impact_result(self) -> None:
        result = evaluate_solver_result(
            d3hsp_block(kinetic="80.0", internal="15.0", hourglass="5.0", total="100.0", ratio="1.01"),
            "impact",
        )
        self.assertTrue(result["ok"])
        self.assertLessEqual(result["metrics"]["hourglass_ratio"], 0.1)

    def test_accepts_valid_quasi_static_result(self) -> None:
        result = evaluate_solver_result(d3hsp_block(), "quasi_static")
        self.assertTrue(result["ok"])
        self.assertEqual(result["metrics"]["kinetic_internal_ratio"], 0.02)

    def test_rejects_negative_internal_energy_despite_normal_termination(self) -> None:
        result = evaluate_solver_result(d3hsp_block(internal="-3.15E+08", hourglass="5.0E+07"), "quasi_static")
        self.assertFalse(result["ok"])
        by_id = {check["id"]: check for check in result["checks"]}
        self.assertFalse(by_id["internal_energy_nonnegative"]["ok"])

    def test_rejects_excessive_hourglass_energy(self) -> None:
        result = evaluate_solver_result(d3hsp_block(internal="100", hourglass="30"), "quasi_static")
        self.assertFalse(result["ok"])
        by_id = {check["id"]: check for check in result["checks"]}
        self.assertFalse(by_id["hourglass_energy_ratio"]["ok"])

    def test_rejects_nonfinite_energy_and_missing_termination(self) -> None:
        result = evaluate_solver_result(d3hsp_block(internal="NaN", terminated=False), "impact")
        self.assertFalse(result["ok"])
        by_id = {check["id"]: check for check in result["checks"]}
        self.assertFalse(by_id["normal_termination"]["ok"])
        self.assertFalse(by_id["finite_energies"]["ok"])

    def test_error_termination_configuration_text_is_not_an_error_marker(self) -> None:
        text = "eq.1: yes (error termination if detected)\n" + d3hsp_block()
        self.assertTrue(parse_d3hsp(text)["terminated_normally"])


if __name__ == "__main__":
    unittest.main()
