# 第七阶段完成示例

本目录展示 `generate_scene_from_prompt` 的受控自然语言模板能力。

每个子目录包含：

- `model.k`
- `model.json`
- `checks.json`
- `open_model.cfile`
- `summary.json`

## rod_impact_plate

Prompt：

```text
生成一根长0.5米半径20毫米的圆柱杆，以12m/s向下撞击固定钢板，钢板长0.8米宽0.6米厚4毫米
```

生成能力：

- `solid_cylinder` 圆柱杆
- `shell_plate` 固定钢板
- `automatic_surface_to_surface` 受控面面接触
- 杆初速度 `-12 m/s`

## cube_top_corner_load

Prompt：

```text
生成2x2x2米低碳钢立方体，底面固定，顶面四个角向下各施加1000N载荷
```

生成能力：

- `solid_block` 实体立方体
- 底面固定
- 顶面四角节点集合
- 向下集中载荷

## plate_pressure

Prompt：

```text
生成长1米宽0.5米厚3毫米的钢板，左边固定，在板面施加20000Pa均布压力
```

生成能力：

- `shell_plate` 壳板
- 左边固定
- 全壳面 segment set
- `pressure_on_segment_set` 均布压力

## 边界

这些示例只证明“自然语言 -> 受控 scene spec -> K 文件 -> 静态校验”的闭环。是否损伤、是否贯穿、结果是否可信，仍必须交给 LS-DYNA 求解并由用户复核。
